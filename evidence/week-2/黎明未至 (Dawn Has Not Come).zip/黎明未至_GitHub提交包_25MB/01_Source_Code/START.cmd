@echo off
REM ---------------------------------------------------------------------------
REM  ASCII ONLY. cmd.exe reads .cmd using the system ANSI codepage (GBK on a
REM  Chinese Windows), not UTF-8. A UTF-8 Chinese line decodes to garbage and
REM  cmd tries to EXECUTE that garbage -- the script dies on line one and a
REM  double-click looks like nothing happened at all.
REM
REM  黎明未至 · 启动（带黑框，出问题看这里）
REM  平时用「启动游戏.vbs」，那个不弹黑框。
REM ---------------------------------------------------------------------------
chcp 65001 >nul
title LIMING WEIZHI
cd /d "%~dp0"

"%~dp0node.exe" "%~dp0prototypes\turtle-soup\launch.mjs"
if errorlevel 1 goto failed
exit /b 0

:failed
echo.
echo   Launch failed.
echo   See prototypes\turtle-soup\launch-log.txt for details.
echo.
pause
exit /b 1
