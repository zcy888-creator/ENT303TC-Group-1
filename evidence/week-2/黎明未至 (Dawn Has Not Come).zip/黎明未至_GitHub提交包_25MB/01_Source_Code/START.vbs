' ---------------------------------------------------------------------------
'  ASCII ONLY -- Windows Script Host reads .vbs with the system ANSI codepage.
'
'  LIMING WEIZHI -- silent launcher.
'  Runs the bundled node.exe with no console window, so the player sees an
'  application window, not a command prompt. Use launcher.cmd instead when
'  something goes wrong and you need to read the error.
'
'  0 = hidden window, False = do not wait (launch.mjs owns the lifetime:
'  it exits when the game window closes).
' ---------------------------------------------------------------------------
Set sh  = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
base = fso.GetParentFolderName(WScript.ScriptFullName)
sh.CurrentDirectory = base
sh.Run """" & base & "\node.exe"" """ & base & "\prototypes\turtle-soup\launch.mjs""", 0, False
