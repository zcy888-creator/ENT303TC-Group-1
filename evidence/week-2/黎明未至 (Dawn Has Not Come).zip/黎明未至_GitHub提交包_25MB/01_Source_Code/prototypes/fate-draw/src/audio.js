/**
 * Audio bus.
 *
 * The brief allows a silent placeholder rather than shipping music with unclear
 * licensing, so this is exactly that: a named cue interface with no assets and
 * no downloads. Every call is a no-op until `attach()` is given real files.
 *
 * Dropping in real audio later needs no changes anywhere else:
 *
 *   audio.attach({
 *     ambient_loop: "/audio/ambient.ogg",   // loops
 *     shuffle:      "/audio/shuffle.ogg",
 *     fate_lock:    "/audio/lock.ogg",
 *     card_flip:    "/audio/flip.ogg",
 *     character_reveal: "/audio/reveal.ogg",
 *     card_spawn:   "/audio/spawn.ogg",
 *     button_hover: "/audio/hover.ogg",
 *     button_click: "/audio/click.ogg",
 *   });
 *   audio.unmute();
 *
 * Cues used by the timeline: ambient_loop, card_spawn, shuffle, fate_lock,
 * card_flip, character_reveal, button_hover, button_click.
 */
export function createAudio() {
  const CUES = [
    "ambient_loop", "card_spawn", "shuffle", "fate_lock",
    "card_flip", "character_reveal", "button_hover", "button_click",
  ];

  const buffers = new Map();
  const pool = new Map();
  let ctx = null;
  let master = null;
  let attached = false;
  let muted = true;

  function ensureCtx() {
    if (ctx) return ctx;
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return null;
    ctx = new AC();
    master = ctx.createGain();
    master.gain.value = muted ? 0 : 0.85;
    master.connect(ctx.destination);
    return ctx;
  }

  return {
    cues: CUES,
    get attached() { return attached; },
    get muted() { return muted; },

    /** Register real assets. Looping cues get loop = true. */
    async attach(map) {
      const c = ensureCtx();
      if (!c) return false;
      const entries = Object.entries(map).filter(([k]) => CUES.includes(k));
      await Promise.all(entries.map(async ([k, url]) => {
        try {
          const buf = await (await fetch(url)).arrayBuffer();
          const decoded = await c.decodeAudioData(buf);
          buffers.set(k, decoded);
          if (k === "ambient_loop") {
            const src = c.createBufferSource();
            src.buffer = decoded; src.loop = true;
            src.connect(master); src.start();
            pool.set(k, src);
          }
        } catch { /* a missing file must not break the ritual */ }
      }));
      attached = buffers.size > 0;
      return attached;
    },

    unmute() {
      muted = false;
      if (master) master.gain.value = 0.85;
      if (ctx?.state === "suspended") ctx.resume();
    },
    mute() { muted = true; if (master) master.gain.value = 0; },

    /** Fire a cue. Safe to call with no assets registered. */
    play(name, { gain = 1, rate = 1 } = {}) {
      if (muted || !buffers.has(name)) return;
      const c = ensureCtx();
      const buf = buffers.get(name);
      const src = c.createBufferSource();
      src.buffer = buf; src.playbackRate.value = rate;
      const g = c.createGain(); g.gain.value = gain;
      src.connect(g); g.connect(master);
      src.start();
    },

    stop(name) {
      const s = pool.get(name);
      if (s) { try { s.stop(); } catch {} pool.delete(name); }
    },
  };
}
