/**
 * The five-card deck.
 *
 * Geometry is rebuilt here rather than imported from Blender's card.glb, so the
 * UV contract the RuiC shaders expect is explicit and auditable:
 *
 *   uv = (x / CARD_W + 0.5, y / CARD_H + 0.5)
 *
 * which is exactly what RuiC's build_card.py writes into the plane's UV layer.
 * The card is authored in the XY plane with thickness along Z, so in a Y-up
 * three.js scene it already stands upright facing +Z - no compensating rotation.
 *
 * Texture budget: during the shuffle every card is face-down, so only ONE back
 * texture is needed for all five. Only the card that fate selects ever receives
 * a character's four layers. That keeps peak texture memory at one character
 * (~100 MB at 2048x3072) instead of five (~500 MB).
 */
import * as THREE from "three";
import { VERT, FRONT, EDGE, BACK, applyRuicUv } from "./ruicShaders.js";

export const CARD_W = 1.05;
export const CARD_H = 1.575;
export const CARD_T = 0.014;

/** Rounded-rectangle outline, shared by the face and the wall strip. */
function roundedRectPoints(w, h, r, seg = 8) {
  const pts = [];
  const hw = w / 2 - r, hh = h / 2 - r;
  const corners = [
    [hw, hh, 0],
    [-hw, hh, Math.PI / 2],
    [-hw, -hh, Math.PI],
    [hw, -hh, -Math.PI / 2],
  ];
  for (const [cx, cy, a0] of corners) {
    for (let i = 0; i <= seg; i++) {
      const a = a0 + (i / seg) * (Math.PI / 2);
      pts.push(new THREE.Vector2(cx + Math.cos(a) * r, cy + Math.sin(a) * r));
    }
  }
  return pts;
}

function faceGeometry(points) {
  const shape = new THREE.Shape(points);
  const geo = new THREE.ShapeGeometry(shape, 12);
  // Shared RuiC UV contract (see ruicShaders.applyRuicUv). Pre-inverting V here
  // cancels the shader's own `1.0 - uv.y`.
  //
  // This was originally found the hard way: with a naive (y/H + 0.5) UV the
  // artwork rendered mirrored vertically - correlating the frame against a
  // composite built in Python matched only against its flipV form (+0.468 vs
  // +0.019 against the card back). The same mistake then reappeared in
  // revealFigure.js, which is why the convention now lives in one helper.
  return applyRuicUv(geo, CARD_W, CARD_H);
}

function wallGeometry(points, thickness) {
  const n = points.length;
  const verts = [];
  const uvs = [];
  const idx = [];
  const hz = thickness / 2;
  for (let i = 0; i < n; i++) {
    const p = points[i];
    verts.push(p.x, p.y, hz);
    verts.push(p.x, p.y, -hz);
    const u = i / n;
    uvs.push(u, 1, u, 0);
  }
  for (let i = 0; i < n; i++) {
    const a = i * 2, b = i * 2 + 1;
    const c = ((i + 1) % n) * 2, d = ((i + 1) % n) * 2 + 1;
    idx.push(a, c, b, b, c, d);
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute("position", new THREE.Float32BufferAttribute(verts, 3));
  geo.setAttribute("uv", new THREE.Float32BufferAttribute(uvs, 2));
  geo.setIndex(idx);
  geo.computeVertexNormals();
  return geo;
}

function baseUniforms(backTexture, tintColor) {
  return {
    uTime: { value: 0 },
    uFoil: { value: 0.65 },
    uScale: { value: 1.25 },
    uDepth: { value: 0.28 },
    uBgDepth: { value: -0.2 },
    uFinish: { value: 1 },
    uHasLine: { value: 1 },
    uOpacity: { value: 1 },
    uView: { value: new THREE.Vector3(0, 0, 1) },
    tSubject: { value: null },
    tBackground: { value: null },
    tText: { value: null },
    tLine: { value: null },
    tBack: { value: backTexture },
    // THREE.Color stores r/g/b; THREE.Vector3.copy() reads x/y/z. Copying a
    // Color with Vector3.copy() therefore wrote (undefined, undefined,
    // undefined) into this uniform, so `col *= uBackTint` in the BACK shader
    // multiplied every card by NaN and clamped to black. The deck back has
    // never rendered - which is why the five cards read as black rectangles
    // through the whole shuffle, and why changing the tint or the artwork made
    // no difference at all: the multiplier was garbage either way.
    uBackTint: { value: new THREE.Vector3(tintColor.r, tintColor.g, tintColor.b) },
  };
}

function shader(uniforms, fragment) {
  return new THREE.ShaderMaterial({
    uniforms,
    vertexShader: VERT,
    fragmentShader: fragment,
    transparent: true,
    side: THREE.FrontSide,
    toneMapped: false,
  });
}

export function createDeck({ scene, count = 5, backTexture, tintHex = 0x6a5aa8 }) {
  const points = roundedRectPoints(CARD_W, CARD_H, 0.075);
  const frontGeo = faceGeometry(points);
  const backGeo = faceGeometry(points);
  const wallGeo = wallGeometry(points, CARD_T);

  const cards = [];
  const tint = new THREE.Color(tintHex);

  for (let i = 0; i < count; i++) {
    const group = new THREE.Group();
    group.name = `card-${i}`;

    // Every card shares one back texture; the tint is per-card so the deck
    // still reads as part of the ritual.
    const bu = baseUniforms(backTexture, tint);
    const backMat = shader(bu, BACK);

    // front uniforms start empty - a card that is never drawn never needs them
    const fu = baseUniforms(backTexture, tint);
    fu.uOpacity.value = 0;
    const frontMat = shader(fu, FRONT);

    const eu = baseUniforms(backTexture, tint);
    const edgeMat = shader(eu, EDGE);

    const frontMesh = new THREE.Mesh(frontGeo, frontMat);
    frontMesh.position.z = CARD_T / 2 + 0.0006;
    frontMesh.visible = false;               // hidden until it is turned over

    /**
     * 牌背图案，贴在 +Z 那一侧。
     *
     * frontMesh 在揭示之前是 visible=false，所以任何转到 +Z 朝向相机的牌就只剩
     * 一圈薄薄的侧壁 —— 画面上读成"一张空白的牌"。而洗牌时整副牌在翻滚，几乎每一
     * 帧都有几张牌正好处在这个角度，整副牌因此看起来是空的。
     *
     * 翻过来的那一面本来也该是牌背（牌面朝下嘛），所以这一层常驻，随 faceK 交叉
     * 淡出：揭示时牌背淡出、人物淡入，正好是一次溶解。BACK 着色器只用 uv 和
     * uView，不读法线，因此不需要为了朝向做任何补偿。
     */
    const du = baseUniforms(backTexture, tint);
    const downMat = shader(du, BACK);
    const downMesh = new THREE.Mesh(frontGeo, downMat);
    downMesh.position.z = CARD_T / 2 + 0.0006;

    const backMesh = new THREE.Mesh(backGeo, backMat);
    backMesh.position.z = -CARD_T / 2 - 0.0006;
    backMesh.rotation.y = Math.PI;           // faces -Z

    const wallMesh = new THREE.Mesh(wallGeo, edgeMat);

    /**
     * 技能面：-Z 那一侧（牌的背面），揭示之后点卡面翻过来看到的就是它。
     *
     * 常驻 invisible，只有抽中的那张在揭示之后才由 setSkillFace 打开 —— 否则
     * 洗牌时整副牌还扣着，这张牌就会把技能写在脸上。
     * 位置比 backMesh 再往外一点点，翻过来时它挡住牌背图案。
     * 用普通 MeshBasicMaterial（贴图是 sRGB），所以它和人物立绘走同一条颜色路径，
     * 也就自动被调色的"主角豁免区"保护。
     */
    const skillMat = new THREE.MeshBasicMaterial({ transparent: true, opacity: 0 });
    // 技能面用**自己的一张 PlaneGeometry**，而不是复用 frontGeo。
    //
    // frontGeo 走的是 RuiC 的 UV 约定（applyRuicUv 把 V 预先反转，用来抵消着色器里的
    // 1.0 - uv.y）。那套只对 ShaderMaterial 成立；MeshBasicMaterial 不会抵消它，于是
    // 贴图上下颠倒 —— 我在那儿来回试了三次镜像组合才对上。用一张 UV 干净的平面，
    // 朝向就只由 rotation.y 决定，是能算清楚的：绕 Y 转 180° 会让观察者左右反过来，
    // 所以只需要在贴图上翻一次 X。
    const skillGeo = new THREE.PlaneGeometry(CARD_W, CARD_H);
    const skillMesh = new THREE.Mesh(skillGeo, skillMat);
    skillMesh.position.z = -CARD_T / 2 - 0.0014;
    skillMesh.rotation.y = Math.PI;           // faces -Z, same as backMesh
    skillMesh.visible = false;

    group.add(frontMesh, downMesh, backMesh, skillMesh, wallMesh);
    scene.add(group);

    cards.push({
      index: i,
      group,
      frontMesh,
      downMesh,
      backMesh,
      skillMesh,
      wallMesh,
      frontMat,
      downMat,
      backMat,
      skillMat,
      edgeMat,
      uniforms: [fu, bu, eu, du],
      /**
       * 0 = the face is staged but not shown, 1 = fully revealed.
       *
       * This exists so the character's four 2048x3072 layers can be assigned
       * and uploaded while the card is still face-down. Doing that work at the
       * moment of the reveal cost a shader compile plus ~15 MB of texture
       * upload in a single frame - and the reveal is exactly when the exposure
       * dips, so the frozen frame landed on the darkest point of the ritual and
       * read as a black flash. The front material is multiplied by this in the
       * per-frame pass.
       */
      faceK: 0,
      /** home transform captured by the layout code */
      home: { pos: new THREE.Vector3(), rot: new THREE.Euler() },
      hasCharacter: false,
    });
  }

  return {
    cards,
    frontGeo,
    backGeo,
    wallGeo,

    /**
     * Attach a character's four layers to one card and make the face mesh live.
     * `textures` is { subject, background, lineart, text }.
     *
     * Deliberately does NOT reveal anything: the mesh becomes visible at
     * opacity 0 so the shader compiles and the textures upload during the
     * shuffle, and the caller raises `faceK` when the ritual actually turns the
     * card over. See the faceK note above.
     */
    setCharacter(card, textures) {
      const u = card.frontMat.uniforms;
      u.tSubject.value = textures.subject;
      u.tBackground.value = textures.background;
      u.tLine.value = textures.lineart;
      u.tText.value = textures.text;
      u.uHasLine.value = textures.lineart ? 1 : 0;
      card.hasCharacter = true;
      card.frontMesh.visible = true;   // live, but still multiplied by faceK
      card.frontMat.needsUpdate = true;
      // downMesh deliberately stays visible: it is what the card looks like from
      // its +Z side until the reveal fades it out. See the note in the deck loop.
    },

    /**
     * 把技能面贴到这张牌的背面并让它可见。
     *
     * 只能在揭示之后调用 —— 翻过来的那一面是这一局的答案，洗牌时露出来就没有
     * "抽"这件事了。
     */
    setSkillFace(card, texture) {
      card.skillMat.map = texture;
      card.skillMat.opacity = 1;
      card.skillMat.needsUpdate = true;
      card.skillMesh.visible = true;
    },

    setFinish(v) {
      for (const c of cards) for (const u of c.uniforms) u.uFinish.value = v;
    },
    setFoil(v) {
      for (const c of cards) for (const u of c.uniforms) u.uFoil.value = v;
    },

    /**
     * Per-card view vector. The camera position is pulled into each card's own
     * local space; this is what makes the parallax and the foil phase differ
     * between cards instead of the whole deck sharing one sheen.
     *
     * Every material owns its own uniform object (front / back / edge), so all
     * three have to be written - not just the front.
     */
    updateView(camera, t) {
      for (const c of cards) {
        c.group.updateMatrixWorld();
        const inv = _m.copy(c.group.matrixWorld).invert();
        for (const u of c.uniforms) {
          u.uView.value.copy(camera.position).applyMatrix4(inv).normalize();
          u.uTime.value = t;
        }
      }
    },

    dispose() {
      for (const c of cards) {
        scene.remove(c.group);
        c.frontMat.dispose();
        c.downMat.dispose();
        c.backMat.dispose();
        c.skillMat.dispose();
        c.edgeMat.dispose();
      }
      frontGeo.dispose();
      backGeo.dispose();
      wallGeo.dispose();
    },
  };
}

const _m = new THREE.Matrix4();
