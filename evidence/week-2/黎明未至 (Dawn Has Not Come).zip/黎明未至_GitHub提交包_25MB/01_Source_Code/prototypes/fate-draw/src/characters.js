/**
 * The five fates.
 *
 * Each entry drives EVERYTHING that differs per character: the scene light
 * colour, the aura behind the card, which particle behaviour plays, the reveal
 * flare tint, and the copy that staggers in.
 *
 * IMPORTANT - two things here are provisional and should be corrected by the
 * user rather than trusted:
 *
 *  1. `card` maps a character onto one of the five uploaded art pairs
 *     (identity-cards/card-0N). The uploads were named role1..role5 with no
 *     characters attached, so this is the order the characters were listed in
 *     the brief. If a name sits over the wrong artwork, change the number here
 *     and re-run `node tools/sync-text.mjs` - nothing else needs touching.
 *
 *  2. `skillCn` / `skillEn` are placeholders. Only THE MEDIUM's 亡灵低语 was
 *     actually designed. These names MUST stay in sync with IDENTITIES in
 *     turtle-soup/server/abilities.mjs - the card you draw promises what the
 *     case then actually gives you, and a mismatch makes the ritual a lie.
 *     THE DETECTIVE's is deliberately a RESOURCE change (+10 questions) rather
 *     than an information handout, so the identity alters how long you play.
 *
 *  3. `skillDesc` / `skillNote` are the text printed on the card's SKILL FACE
 *     (the back, revealed by clicking the card after the ritual). They are
 *     written from the actual switch in server/abilities.mjs, one branch each -
 *     not from the name. If you change an ability there, change it here too,
 *     otherwise the card promises a mechanic the case does not implement.
 */

export const CHARACTERS = [
  {
    id: "medium",
    card: 1,
    nameEn: "THE MEDIUM",
    nameCn: "灵媒",
    skillCn: "亡灵低语",
    skillEn: "WHISPER OF THE DEAD",
    // abilities.mjs · case "witness"
    skillDesc: [
      "指名案卷里的一个角色，",
      "问他一个问题。",
      "他只会用第一人称，说出",
      "他所知道的那一部分；",
      "他不知道的，就是不知道。",
    ],
    skillNote: "你听到的是一段视角，不是真相。",
    skillProvisional: false,
    line: "The dead leave echoes.",
    // Deep Violet + Moonlight Silver
    palette: {
      primary: 0x7b5bd6,
      secondary: 0xc9d3e6,
      accent: 0xb98cff,
      aura: 0x4a2f96,
      light: 0x8f7bff,
      fog: 0x2a1c52,
    },
    vfx: "mist",
  },
  {
    id: "detective",
    card: 2,
    nameEn: "THE DETECTIVE",
    nameCn: "侦探",
    skillCn: "延长审讯",
    skillEn: "EXTENDED INTERROGATION",
    // abilities.mjs · case "extra_questions" —— 唯一改的是"你能玩多久"
    skillDesc: [
      "立刻获得 10 次",
      "额外的提问机会。",
      "",
      "别的能力给你一条线索，",
      "它给你更多时间。",
    ],
    skillNote: "这一局，你会比别人问得更久。",
    skillProvisional: true,
    line: "Nothing is hidden. Only unread.",
    // Charcoal Black + Antique Gold + Cold Grey
    palette: {
      primary: 0x3a3a3f,
      secondary: 0xb99a4e,
      accent: 0xd9c07a,
      aura: 0x2b2b30,
      light: 0xd8c58a,
      fog: 0x1c1c20,
    },
    vfx: "rain",
  },
  {
    id: "physician",
    card: 3,
    nameEn: "THE PHYSICIAN",
    nameCn: "医师",
    skillCn: "冷光解剖",
    skillEn: "COLD LIGHT AUTOPSY",
    // abilities.mjs · case "evidence"
    skillDesc: [
      "从案卷的物证里，",
      "取出一条物理事实，",
      "直接摆在你面前。",
      "",
      "给的是你还没问过的那一件。",
    ],
    skillNote: "尸体不会说谎，物证也不会。",
    skillProvisional: true,
    line: "The body never lies.",
    // Ivory + Dark Crimson + Muted Emerald
    palette: {
      primary: 0xe8e2d4,
      secondary: 0x8e1f2c,
      accent: 0x4f7f6a,
      aura: 0x5a2630,
      light: 0xf0e6da,
      fog: 0x2a1a1e,
    },
    vfx: "petal",
  },
  {
    id: "astrologer",
    card: 4,
    nameEn: "THE ASTROLOGER",
    nameCn: "占星师",
    skillCn: "三星定向",
    skillEn: "THREE BEARINGS",
    // abilities.mjs · case "directions" —— 给的是话题，不是答案
    skillDesc: [
      "给出三个方向：",
      "三个你还没有碰过的",
      "关键事实的开头几个字。",
      "",
      "是方向，不是答案。",
    ],
    skillNote: "去想它们背后各自藏着什么。",
    skillProvisional: true,
    line: "Every fate was written before you arrived.",
    // Midnight Blue + Cobalt + Silver
    palette: {
      primary: 0x1f3a7a,
      secondary: 0x3f7bd6,
      accent: 0xcfe0ff,
      aura: 0x16294f,
      light: 0x6fa8ff,
      fog: 0x101f3d,
    },
    vfx: "orbit",
  },
  {
    id: "chronicler",
    card: 5,
    nameEn: "THE CHRONICLER",
    nameCn: "记录者",
    skillCn: "残章折角",
    skillEn: "DOG-EARED PAGES",
    // abilities.mjs · case "recall" —— 不给新信息，把旧的还给你
    skillDesc: [
      "在你已经问过的问题里，",
      "折出真正推动了案件的",
      "那三条。",
      "",
      "长局里你会忘记自己学到过什么。",
    ],
    skillNote: "它把这个还给你。",
    skillProvisional: true,
    line: "I write what the world forgets.",
    // Burgundy + Old Gold + Warm Sepia
    palette: {
      primary: 0x6d1f2e,
      secondary: 0xa8802f,
      accent: 0xe0c489,
      aura: 0x4a1a22,
      light: 0xe8c98f,
      fog: 0x2b1c16,
    },
    vfx: "page",
  },
];

export const byId = (id) => CHARACTERS.find((c) => c.id === id);

/** Where a character's four RuiC layers live. Served by server.mjs. */
export function layerUrls(card) {
  const n = String(card).padStart(2, "0");
  const base = `/card-layers/card-${n}`;
  return {
    subject: `${base}/subject.png`,
    background: `${base}/background.png`,
    lineart: `${base}/lineart.png`,
    text: `${base}/text.png`,
  };
}
