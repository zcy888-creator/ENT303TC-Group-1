/**
 * The ritual circle: a single shader-driven disc lying on the dais.
 *
 * It is "asleep" (intensity 0) for act one and wakes when INVOKE FATE is
 * pressed. Its colour is retinted to the drawn character during the reveal, so
 * the whole floor changes allegiance at the moment of fate-lock.
 *
 * One draw call, no textures: rings, rune ticks, a heptagram and radial spokes
 * are all computed analytically in polar space.
 */
import * as THREE from "three";

const FRAG = /* glsl */ `
precision highp float;
varying vec2 vUv;
uniform float uTime, uIntensity, uRot, uSlow;
uniform vec3 uColorA, uColorB;

float ring(float r, float target, float w) {
  return smoothstep(w, 0.0, abs(r - target));
}
float band(float r, float a, float b) {
  return smoothstep(a - 0.006, a + 0.006, r) * (1.0 - smoothstep(b - 0.006, b + 0.006, r));
}
float marks(float ang, float n, float w) {
  float f = fract(ang / 6.28318 * n);
  return smoothstep(w, 0.0, abs(f - 0.5));
}
float segDist(vec2 p, vec2 a, vec2 b) {
  vec2 pa = p - a, ba = b - a;
  float h = clamp(dot(pa, ba) / dot(ba, ba), 0.0, 1.0);
  return length(pa - ba * h);
}

void main() {
  vec2 p = (vUv - 0.5) * 2.0;
  float r = length(p);
  if (r > 1.0) discard;
  float a = atan(p.y, p.x);

  float m = 0.0;
  // concentric rings
  m += ring(r, 0.300, 0.0045) * 0.95;
  m += ring(r, 0.336, 0.0022) * 0.45;
  m += ring(r, 0.620, 0.0050) * 0.85;
  m += ring(r, 0.660, 0.0022) * 0.40;
  m += ring(r, 0.905, 0.0045) * 0.75;
  m += ring(r, 0.952, 0.0022) * 0.38;

  // rune ticks, counter-rotating
  m += marks(a + uRot, 72.0, 0.34) * band(r, 0.680, 0.885) * 0.55;
  m += marks(a - uSlow, 24.0, 0.30) * band(r, 0.345, 0.612) * 0.40;
  // long cardinal ticks
  m += marks(a + uRot * 0.5, 8.0, 0.16) * band(r, 0.905, 0.985) * 1.15;

  // heptagram, slowly rotating
  float R = 0.60;
  for (int i = 0; i < 7; i++) {
    float a1 = uSlow * 0.35 + 6.28318 * float(i) / 7.0;
    float a2 = uSlow * 0.35 + 6.28318 * float((i + 3) % 7) / 7.0;
    vec2 q1 = vec2(cos(a1), sin(a1)) * R;
    vec2 q2 = vec2(cos(a2), sin(a2)) * R;
    m += smoothstep(0.006, 0.0, segDist(p, q1, q2)) * 0.75;
  }

  // inner septagon vertices
  for (int i = 0; i < 7; i++) {
    float a1 = uSlow * 0.35 + 6.28318 * float(i) / 7.0;
    vec2 q = vec2(cos(a1), sin(a1)) * R;
    m += smoothstep(0.020, 0.0, length(p - q)) * 1.1;
  }

  // radial spokes in the outer band
  m += marks(a + uRot * 1.6, 96.0, 0.06) * band(r, 0.905, 0.985) * 0.26;
  // centre sigil
  m += smoothstep(0.055, 0.0, r) * 0.8;
  m += ring(r, 0.055, 0.006) * 1.2;

  // slow breathing pulse
  float pulse = 0.86 + 0.14 * sin(uTime * 0.9);
  vec3 col = mix(uColorA, uColorB, clamp(r * 1.15, 0.0, 1.0));
  // The flat fill had to shrink. At 0.16 across the whole disc it added a uniform
  // wash over the dais, and the dais - not the floor - is what read as "a flat
  // pale plate" in every screenshot. 0.05 with a tighter falloff keeps a soft
  // pool of light under the sigil without repainting the stone.
  float glow = smoothstep(0.72, 0.0, r) * 0.05;

  // Additive blending means outA is really the gain of the whole pass. The mask m
  // stacks - rings + rune ticks + spokes + heptagram can reach ~2.8 where they
  // overlap, and this disc was tuned while it was buried inside the dais (see
  // main.js), so nobody had ever seen the result: it clipped to a white chrome
  // platter, the brightest thing on screen at luminance 212. 0.40 total gain
  // lands the engraved band near 1.0 and lets the stone stay dark.
  float outA = (m * pulse + glow) * uIntensity * 0.40;
  if (outA < 0.002) discard;
  gl_FragColor = vec4(col * (0.9 + m * 0.5), outA);
}
`;

export function buildMagicCircle(scene, y = 0.36) {
  const uniforms = {
    uTime: { value: 0 },
    uIntensity: { value: 0 },
    uRot: { value: 0 },
    uSlow: { value: 0 },
    uColorA: { value: new THREE.Color(0x8f7bff) },
    uColorB: { value: new THREE.Color(0xa99bff) },
  };

  const geo = new THREE.CircleGeometry(4.1, 96);
  const mat = new THREE.ShaderMaterial({
    uniforms,
    vertexShader: `varying vec2 vUv; void main(){ vUv=uv; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);} `,
    fragmentShader: FRAG,
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
    side: THREE.DoubleSide,
  });

  const mesh = new THREE.Mesh(geo, mat);
  mesh.rotation.x = -Math.PI / 2;
  mesh.position.y = y;
  scene.add(mesh);

  return {
    mesh,
    uniforms,
    setColor(primary, accent) {
      uniforms.uColorA.value.setHex(primary);
      uniforms.uColorB.value.setHex(accent);
    },
    update(t) {
      uniforms.uTime.value = t;
      uniforms.uRot.value = t * 0.11;
      uniforms.uSlow.value = t * 0.045;
    },
    dispose() {
      scene.remove(mesh);
      geo.dispose();
      mat.dispose();
    },
  };
}
