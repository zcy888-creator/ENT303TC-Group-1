/**
 * FATE DRAW - bootstrap.
 *
 * Wires the hall, the deck, the particles, the post stack and the GSAP ritual
 * together, and owns the single apply pass that turns plain state objects into
 * Three.js transforms and shader uniforms.
 *
 * Debug / verification harness (see the brief's requirement to force-test all
 * five reveals):
 *
 *   ?t=4.8          freeze the ritual at 4.8s, render exactly one frame, stop.
 *                   Deterministic: the RNG is seeded and the sim is driven off
 *                   the seek time, so the same t always gives the same pixels.
 *   ?char=3         force character 3 (1..5) instead of drawing at random
 *   ?seed=99        reseed the draw
 *   ?quality=0.4    scale particle counts (mobile / low-end)
 *   ?nofx=1         skip the post stack (isolates shader problems)
 *
 * window.__fate exposes { tl, ready, fps, selected, characters, seek(t) } so a
 * headless browser can drive and inspect it.
 */
import * as THREE from "three";
import { gsap } from "gsap";
import {
  EffectComposer, RenderPass, EffectPass, BloomEffect, VignetteEffect,
  ChromaticAberrationEffect, ToneMappingEffect, ToneMappingMode,
  DepthOfFieldEffect, Effect, BlendFunction,
} from "postprocessing";

import { buildTemple } from "./temple.js";
import { buildMagicCircle } from "./magicCircle.js";
import { createDeck, CARD_W, CARD_H } from "./cards.js";
import { makeSkillFace } from "./skillFace.js";
import { createCharacterVfx } from "./vfx.js";
import { createRevealFigure } from "./revealFigure.js";
import { createMotes, mulberry32 } from "./particles.js";
import { CHARACTERS, layerUrls } from "./characters.js";
import { createTimeline, ACTS, RITUAL_END, arcPose, shufflePose } from "./timeline.js";
import { createAudio } from "./audio.js";
import { createUi } from "./ui.js";
import { stampScroll, unfurlScroll } from "/scroll.js";

const params = new URLSearchParams(location.search);
const num = (k, d) => (params.has(k) ? Number(params.get(k)) : d);

/**
 * 启动期耗时账本。
 *
 * 点下 INVOKE FATE 之后有一次 1.3 秒的停顿。它可能是三种完全不同的东西 ——
 * PNG 解码、显存上传、着色器编译 —— 而三者的修法毫无共通之处。不量就只能猜，
 * 所以这里把每一段都记下来，通过 window.__fate.timings 交给
 * tools/probe-ritual.mjs 打印。
 */
const BOOT_T = performance.now();
const timings = {};
const mark = (k, t0) => { timings[k] = +(performance.now() - t0).toFixed(1); };

// The ritual is a fixed-length cinematic: 6.8 seconds means 6.8 seconds.
// GSAP's default lag smoothing clamps any frame longer than 500 ms down to
// 33 ms, so on a slow/software renderer the timeline crawls - measured at
// ~0.77 s of timeline after 9 s of wall clock under SwiftShader. Disabling it
// keeps the choreography tied to real time; on a slow machine frames get
// chunkier rather than the whole ceremony stretching out.
gsap.ticker.lagSmoothing(0);

const SEEK_T = params.has("t") ? Number(params.get("t")) : null;
// 截图用：把技能面固定翻到位（0..1）。见 apply()。
const FLIP_FIXED = params.has("flip") ? Number(params.get("flip")) : null;
// The frame counter is a debug readout; it is hidden unless explicitly asked
// for, so it never sits in the corner of a finished-looking ritual.
if (params.has("fps")) document.body.dataset.fps = "1";
const FORCE_CHAR = params.has("char") ? Number(params.get("char")) : null;
// The seed MUST vary per load. It used to default to a fixed constant, so
// drawRng()'s first output - and therefore the drawn character - was identical
// on every single visit: the ritual could never actually reroll.
// `?seed=N` still pins it, which the ?t= screenshot harness relies on.
const SEED = params.has("seed") ? Number(params.get("seed")) : (Math.random() * 1e9) | 0;
const QUALITY = params.has("quality") ? Number(params.get("quality")) : (matchMedia("(max-width: 760px)").matches ? 0.5 : 1);
const NO_FX = params.get("nofx") === "1";
// 调试开关：单独关掉光环，用来确认画面上那圈亮环到底是谁画的。
const NO_AURA = params.get("noaura") === "1";

/**
 * ?bg=1 —— **纯背景模式**。
 *
 * 卷宗墙要垫在这座殿堂里。与其另起炉灶画一片 2D 的天（那两边就不像同一个
 * 地方了），不如**直接把殿堂本身当背景**：同一个场景、同一套光、同一批柱子。
 *
 * 做法：进这个模式就永远停在开场那圈镜头漂移上（introDrift 不放开），
 * 并且把整层 UI 藏掉 —— 玩家看到的只有殿堂。
 */
const BG_MODE = params.get("bg") === "1";

// ---------------------------------------------------------------- renderer --
const canvas = document.getElementById("stage");
const renderer = new THREE.WebGLRenderer({
  canvas, antialias: true, alpha: false, powerPreference: "high-performance",
});
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
renderer.setSize(window.innerWidth, window.innerHeight);
// Deliberately NOT pure black. The ritual dips exposure to 0.34 at fate-lock
// and the vignette darkens with it, so a pure-black clear meant that any frame
// landing at the bottom of that dip - or any frame where the geometry briefly
// failed to cover the viewport - read as the screen cutting to black. A very
// dark plum keeps the dip reading as "the hall goes dim" instead.
renderer.setClearColor(0x08060e, 1);
renderer.toneMapping = NO_FX ? THREE.ACESFilmicToneMapping : THREE.NoToneMapping;
renderer.toneMappingExposure = 1.0;

// Contact shadows. The previous pass had NO shadow map at all - the temple's own
// comment admitted it - so nothing in the hall was grounded and the pillars read
// as flat cutouts. PCFSoft at 1024 is the cheap end that still lands a soft
// contact under the columns; the shadow camera is deliberately tight (32 units)
// so the texel density stays useful.
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;

const scene = new THREE.Scene();
// The fog used to be 0.052, which is 66% opacity at 20 units and 91% at 30. The
// far ambulatory (15.6) and the wall behind it (18.6) were therefore faded most
// of the way to the fog colour, and the "background" was not architecture at
// all - it was the fog itself. Pixel probe of the old build: the whole upper
// frame measured #050011..#1d0b34, luminance 3..21. That is the flat wall
// everyone kept seeing. 0.030 leaves ~30% at 15 units and ~46% at the wall, so
// distance still reads as depth but the stone survives it.
scene.fog = new THREE.FogExp2(0x0a0818, 0.030);

// FOV 38 was too tight: the hall's vault sits at y≈10.8 and the frame only
// reached y≈6 at the ring radius, so the ceiling never appeared and the
// background read as a flat purple void. 48 lets the colonnade and the vault
// ribbing into the frame, which is what makes it read as an interior.
const camera = new THREE.PerspectiveCamera(48, window.innerWidth / window.innerHeight, 0.1, 140);
camera.position.set(0, 1.72, 7.6);
camera.lookAt(0, 1.2, 0);

// --------------------------------------------------------------------- post --

/**
 * 电影调色（film grade）。
 *
 * 这条链上原来只有 bloom + 暗角 + 色差 —— 那些是**特效**，不是**调色**。大厂画面
 * 和小作坊 WebGL demo 最大的差别通常不在模型量，而在有没有这一级：lift/gamma/gain、
 * S 曲线、暗部与亮部的分色调、以及胶片颗粒。
 *
 * 顺序按调色台的惯例：对比 → lift/gain → gamma → 分色调 → 饱和度 → 颗粒。
 * 分色调的方向是这幅画本来就定好的"紫墨与烛"：暗部推冷紫，亮部推暖金。
 */
const GRADE_FRAG = /* glsl */`
uniform float uTime;
uniform float uAmount;
uniform float uContrast;
uniform float uGamma;
uniform vec3 uLift;
uniform vec3 uGain;
uniform vec3 uShadowTint;
uniform vec3 uHighlightTint;
uniform float uSaturation;
uniform float uGrain;
uniform vec2 uHeroXY;
uniform vec2 uHeroR;
uniform float uHeroK;

// "Hash without Sine"（Dave Hoskins）。不能用 sin(dot(p,k)) 那一套：颗粒的采样点
// 是整数像素坐标，而 127.1 这种常数的小数部分会让相邻像素高度相关 —— 结果不是
// 随机颗粒，而是一层规则的网格花纹铺满全屏。
float hash(vec2 p) {
  vec3 p3 = fract(vec3(p.xyx) * 0.1031);
  p3 += dot(p3, p3.yzx + 33.33);
  return fract((p3.x + p3.y) * p3.z);
}

// 关于色调映射，这里踩过一个值得记下来的坑。
//
// 卡面着色器最后是 pow(clamp(col,0,1), vec3(2.2)) —— 这个幂是**压暗**，也就是把
// 计算结果转成线性的，再由后期链统一编码一次。所以我一度以为"卡面被二次处理了"，
// 把 NEUTRAL 色调映射整个从主角区域去掉。结果是暗卡（侦探）一下子通了，但亮卡
// （医师）整张发灰发平。
//
// 真正的原因在 NEUTRAL 的第一行：
//     float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
// 它会把**最深的那一档再往下压**。对殿堂（线性 HDR、暗部本来就是 0.01~0.05）这是
// 对的；对一张本来就画得很暗的立绘，这一压就把人压没了。
//
// 但反过来整个拿掉，亮卡的高光就没人收了。所以现在的结论是：色调映射保留给全画面，
// 卡面靠"逐卡 gamma"去补——这也是实测唯一同时对两端都成立的组合。

void mainImage(const in vec4 inputColor, const in vec2 uv, out vec4 outputColor) {
  vec3 o = inputColor.rgb;

  // ---- 主角豁免区 ----------------------------------------------------------
  //
  // 主角区里**整条调色都不作用**，卡面原样通过。
  //
  // 这里绕了很久，把结论写下来免得再走一遍：先试过"只豁免 lift/分色调"，再试过
  // "连色调映射一起豁免"，还试过"逐卡 gamma 补偿" —— 全都是在治标。卡面着色器
  // 是 RuiC 那套，本身就是按"直接显示"画的（参考查看器里 renderer.toneMapping
  // 是 NoToneMapping、整条后期都不存在），所以对它的正确处理不是"少调一点"，
  // 而是**完全不调**。
  //
  // 范围是**椭圆**，跟着卡面自己的长宽比走。第一版用的是一个圆、半径按 0.80×卡高算、
  // 衰减到 1.3 倍 —— 那个圆盖住了屏幕高度的七成，等于把大半个殿堂的调色也一起关掉了
  //（墙 25→8、38→26）。豁免区必须紧贴主角。
  vec2 hd = (uv - uHeroXY) / max(uHeroR, vec2(1e-4));
  float protect = (1.0 - smoothstep(0.92, 1.12, length(hd))) * uHeroK;

  // ---- 殿堂：电影调色 ------------------------------------------------------
  vec3 g = clamp((o - 0.5) * uContrast + 0.5, 0.0, 1.0);
  g = mix(g, g * g * (3.0 - 2.0 * g), 0.35);

  g = max(uLift + g * (uGain - uLift), 0.0);
  g = pow(g, vec3(1.0 / uGamma));

  float gl = dot(g, vec3(0.2126, 0.7152, 0.0722));
  g += uShadowTint * (1.0 - gl) * 0.55;
  g += uHighlightTint * smoothstep(0.45, 1.0, gl) * 0.40;

  g = mix(vec3(dot(g, vec3(0.2126, 0.7152, 0.0722))), g, uSaturation);

  // 颗粒也只在殿堂这一支里 —— 原版卡面没有颗粒，加了就是"和原来不一样"。
  //
  // 采样点必须用 gl_FragCoord（每像素一格），不能拿 uv 乘一个大数：uv 是 0..1，
  // 乘 1400 之后每个像素跨不到一格，低于 Nyquist，噪声会折叠成规则的花纹 ——
  // 实测结果就是整幅画面上铺满一层斜条纹，看起来像雨丝或者贴图错误。
  float gr = hash(gl_FragCoord.xy + vec2(uTime * 61.0, uTime * 37.0)) - 0.5;
  g += gr * uGrain * (1.0 - smoothstep(0.0, 0.7, gl));

  // protect = 1 → 完全原样；protect = 0 → 完全调色过的殿堂。
  vec3 c = mix(g, o, protect);

  outputColor = vec4(mix(o, max(c, 0.0), uAmount), inputColor.a);
}
`;

let composer = null, bloom = null, vignette = null, chroma = null, toneMap = null;
let dof = null, grade = null;
if (!NO_FX) {
  composer = new EffectComposer(renderer);
  composer.addPass(new RenderPass(scene, camera));
  bloom = new BloomEffect({
    intensity: 0.62, luminanceThreshold: 0.30, luminanceSmoothing: 0.35,
    mipmapBlur: true, radius: 0.62,
  });
  // 景深。相机固定在 (0,1.72,7.6)，基座中心到相机 7.8 —— 焦平面就放在那里，
  // 因为揭示时那张牌正好停在基座上，它就是主角。
  //
  // focusRange 的语义要小心，它是**从焦平面起算的 CoC 斜坡长度**，不是对称的 ± 带：
  //   magnitude = smoothstep(0.0, focusRange, abs(distance - focusDistance))
  // 我一开始按"± 带"理解，写了 focusDistance 13 / focusRange 18，于是距离 7.8 的
  // 卡面拿到 smoothstep(0,18,5.2) = 0.21 —— 卡面被 21% 混进了背后明亮的蓝厅，
  // 实测暗部从 #150100（亮度 7）抬到 #211a36（亮度 31）。那层"雾"就是这么来的。
  //
  // 现在焦平面落在卡面上（|Δ|≈0.2 → CoC≈0.005，等于全清晰），远处的外墙和拱廊
  // 才散开。
  //
  // focusRange 给得**宽**是刻意的：它是 CoC 从 0 涨到 1 的斜坡长度，给窄的话
  // 外墙/拱廊会落到 magnitude=1 的**全模糊**区，而 bokeh 那一遍在半径很大时会掉
  // 能量 —— 实测背景被压黑（墙 25→8、38→26），整帧平均从 42 掉到 34。
  // 26 的斜坡让远景停在 0.65~0.78 的**部分**模糊，既读得出前后景分离，又保住了
  // 亮度。焦平面仍然压在卡面上（|Δ|≈0 → CoC≈0，全清晰）。
  // 想完全关掉：?dof=0
  dof = params.get("dof") === "0" ? null : new DepthOfFieldEffect(camera, {
    focusDistance: 7.8, focusRange: 26.0, bokehScale: 0.6, resolutionScale: 0.4,
  });
  grade = params.get("grade") === "0" ? null : new Effect("FilmGrade", GRADE_FRAG, {
    blendFunction: BlendFunction.NORMAL,
    uniforms: new Map([
      ["uTime", { value: 0 }],
      ["uAmount", { value: 1 }],
      ["uContrast", { value: 1.10 }],
      ["uGamma", { value: 1.06 }],
      // 殿堂的抬黑与冷紫分色调恢复到"好看的那一档"：卡面由 uHeroK 豁免，
      // 所以这里可以给足，不必再为卡面妥协。
      ["uLift", { value: new THREE.Vector3(0.005, 0.004, 0.013) }],
      ["uGain", { value: new THREE.Vector3(1.02, 0.995, 1.0) }],
      ["uShadowTint", { value: new THREE.Vector3(0.011, 0.005, 0.032) }],
      ["uHighlightTint", { value: new THREE.Vector3(0.028, 0.019, 0.005) }],
      ["uSaturation", { value: 1.12 }],
      ["uGrain", { value: 0.016 }],
      // 主角豁免区（每帧由 apply() 写入）。uHeroR 是椭圆的两个半轴，以 uv 为单位。
      ["uHeroXY", { value: new THREE.Vector2(0.5, 0.5) }],
      ["uHeroR", { value: new THREE.Vector2(0.5, 0.5) }],
      ["uHeroK", { value: 0 }],
    ]),
  });
  vignette = new VignetteEffect({ offset: 0.30, darkness: 0.62 });
  chroma = new ChromaticAberrationEffect({
    offset: new THREE.Vector2(0.0004, 0.0004),
    radialModulation: true, modulationOffset: 0.35,
  });
  // Film tone mapping is deliberately NEUTRAL, not ACES.
  //
  // RuiC's card shader already does its own `pow(col, 2.2)` plus
  // `#include <colorspace_fragment>`, so it emits display-ready sRGB. Stacking
  // ACES on top applied a second, much heavier curve: it crushed the card's
  // midtones and desaturated the art, which is exactly what made the reveal
  // read as muddy and cheap. NEUTRAL only clamps HDR back into range without
  // re-grading what the card shader produced.
  //
  // NEUTRAL 同时会把最深的一档再往下压（offset = x - 6.25x²），这一条对暗卡是伤害，
  // 但整个拿掉会让亮卡发灰。卡面那边用 cardGamma 单独补，见 characters.js。
  toneMap = new ToneMappingEffect({ mode: ToneMappingMode.NEUTRAL });
  // 顺序：发光 → 景深 → 色调映射 → 调色 → 暗角 → 色差。
  // 色调映射必须排在调色之前（它负责把 HDR 收进 0..1），色差是镜头效应所以最后。
  // filter(Boolean)：dof 可以被 ?dof=0 关掉，而 EffectPass 不该收到 null。
  composer.addPass(new EffectPass(camera,
    ...[bloom, dof, toneMap, grade, vignette, chroma].filter(Boolean)));
}

function resize() {
  const w = window.innerWidth, h = window.innerHeight;
  camera.aspect = w / h;
  camera.updateProjectionMatrix();
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  renderer.setSize(w, h);
  composer?.setSize(w, h);
}
window.addEventListener("resize", resize);

// ------------------------------------------------------------------ content --
const ui = createUi(document);
const audio = createAudio();

const temple = buildTemple(scene);
// 0.50, not 0.365: the third dais step occupies y 0.30-0.45 out to radius 4.16,
// so a radius-4.1 disc at 0.365 was buried inside its own podium and depth-tested
// away. The circle that is supposed to wake when INVOKE FATE is pressed had never
// actually been visible.
const circle = buildMagicCircle(scene, 0.50);
const vfx = createCharacterVfx(scene, QUALITY, camera);
// the die-cut figure the card dissolves into at the reveal
const revealFigure = createRevealFigure(scene);

// ambient field, always on: fine dust through the whole hall
// Counts are budgeted against measured frame cost. Additive-blended points are
// fill-rate bound, and halving every emitter raised an Intel Iris Xe from 41 to
// 64 fps at 1080p, so these are deliberately leaner than they first look.
const dust = createMotes({
  scene, mode: "DUST", count: Math.round(320 * QUALITY),
  distribute: (rnd) => new THREE.Vector3((rnd() - 0.5) * 22, rnd() * 8.5 - 0.6, (rnd() - 0.5) * 22),
  bounds: new THREE.Vector3(20, 8, 20),
  color: { a: 0x9fb0e8, b: 0xffffff }, baseSize: 0.016, seed: 909,
});
dust.uniforms.uOpacity.value = 0.55;

// motes rising off the ritual circle, woken with it
const circleMotes = createMotes({
  scene, mode: "MOTE", count: Math.round(170 * QUALITY),
  distribute: () => new THREE.Vector3(0, 0, 0),
  bounds: new THREE.Vector3(6, 5.2, 6),
  color: { a: 0x8f7bff, b: 0xd8e2ff }, baseSize: 0.024, seed: 424,
});
circleMotes.uniforms.uOpacity.value = 0;

// sparks shed while the deck is in motion
const trail = createMotes({
  scene, mode: "TRAIL", count: Math.round(190 * QUALITY),
  distribute: (rnd) => new THREE.Vector3((rnd() - 0.5) * 6, 0.5 + rnd() * 2.4, (rnd() - 0.5) * 2.4),
  bounds: new THREE.Vector3(6, 4, 6),
  color: { a: 0xc9b6ff, b: 0xffffff }, baseSize: 0.020, seed: 777,
});
trail.uniforms.uOpacity.value = 0;

// -------------------------------------------------------------- selection ---
const drawRng = mulberry32(SEED);
let selected = Math.floor(drawRng() * CHARACTERS.length);
if (FORCE_CHAR !== null && Number.isFinite(FORCE_CHAR)) {
  selected = Math.min(CHARACTERS.length, Math.max(1, Math.floor(FORCE_CHAR))) - 1;
}
const selectedCharacter = CHARACTERS[selected];

// ------------------------------------------------------------------- deck ----
const loader = new THREE.TextureLoader();

function markDataTexture(tex, nonColor = false) {
  tex.colorSpace = THREE.NoColorSpace;
  tex.anisotropy = Math.min(8, renderer.capabilities.getMaxAnisotropy());
  tex.generateMipmaps = true;
  tex.minFilter = THREE.LinearMipmapLinearFilter;
  tex.magFilter = THREE.LinearFilter;
  tex.needsUpdate = true;
  return tex;
}

const backTexture = markDataTexture(await loader.loadAsync("/card-back.png"));

/**
 * Tint multiplied over the card back by the BACK shader (`col *= uBackTint`).
 *
 * This was 0x6a5aa8 - RGB (0.42, 0.35, 0.66). Two things were wrong with it.
 *
 * It crushed the artwork to ~40% brightness, and the artwork was already
 * near-black: measured, tools/png-stat.mjs put the old card-back.png at a mean
 * luminance of 17.9/255 with 95% of its pixels below 32. Since the shader does
 * `col = mix(col, art.rgb, art.a)` with art.a == 1 everywhere, the texture IS
 * the colour - so multiplying black by any tint still gives black, and two
 * rounds of "fixing the tint" could never have worked.
 *
 * The art itself now carries a lit violet centre (mean 52.6, sd 38). So the
 * tint goes neutral and lets the design speak: the card back is deliberately
 * NOT character-coloured, because during the shuffle all five must be
 * indistinguishable - that is the whole point of a fate draw.
 */
const BACK_TINT = 0xf4f0ff;

const deck = createDeck({ scene, count: CHARACTERS.length, backTexture, tintHex: BACK_TINT });

// initial state: invisible, parked on the arc, face down
const N = CHARACTERS.length;
const stArr = [];
deck.cards.forEach((card, i) => {
  const arc = arcPose(i, N);
  card.arc = arc;
  card.rand = {
    turns: drawRng() * 0.7,
    p1: drawRng() * 9, p2: drawRng() * 9, p3: drawRng() * 9,
    p4: drawRng() * 9, p5: drawRng() * 9, p6: drawRng() * 9,
  };
  card.dir = drawRng() < 0.5 ? -1 : 1;
  card.st = {
    opacity: 0, x: arc.x, y: arc.y - 1.6, z: arc.z + arc.zBias,
    rx: 0, ry: arc.ry, rz: 0, s: 0.86,
    foil: 0.65, shuffleP: 0, shuffleActive: 0,
  };
  stArr.push(card.st);
});

// ------------------------------------------------------------------ host -----
const host = {
  cam: { x: 0, y: 1.62, z: 7.4 },
  // the point the camera aims at; the reveal slides it up/forward to the card
  look: { x: 0, y: 1.20, z: 0 },
  exposure: 1,
  trailBoost: 0,
  revealPulse: 0,
  sigK: 0,
  // 0 = still a rectangular card, 1 = die-cut figure standing free
  figureK: 0,
  // 技能面翻转进度：0 = 人物朝前，1 = 翻过来露出技能面。见 toggleSkillFace。
  skillFlip: 0,
  skillFlash: 0,
  selected,
};

// ------------------------------------------------------- per-character art ---
let characterTextures = null;
let skillTexture = null;
let skillError = null;
let loadState = "idle";

/**
 * 全透明 1x1 贴图。
 *
 * 卡面四层里有一层是 text —— 上面烙着「ROLE 03 / 人物图谱 / 身份档案」这种
 * 设计稿占位字样。FRONT 着色器最后一步是 `mix(col, text.rgb, text.a)`，所以
 * 只要把 tText 绑成一张全透明图，那层字就彻底消失，而不用改材质管线。
 *
 * 角色名本来就已经由界面文字给出（THE PHYSICIAN / 医师 / 冷光解剖），
 * 卡面上那行占位字是多余的，而且一眼就是模板。
 */
function blankTexture() {
  const c = document.createElement("canvas");
  c.width = c.height = 1;
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.NoColorSpace;
  return t;
}
const BLANK_TEXT = blankTexture();

/**
 * 让出一帧，但绝不永久挂起。
 *
 * 后台标签页里 requestAnimationFrame 根本不触发；只等它的话，素材上传会永远
 * 停在第一层，而 onInvoke 正 await 着这条链。
 */
function nextFrame() {
  return new Promise((resolve) => {
    const id = setTimeout(resolve, 60);
    requestAnimationFrame(() => { clearTimeout(id); resolve(); });
  });
}

/**
 * 卡面层的解码尺寸 = 原始尺寸，不做任何重采样。
 *
 * 这里走过一段弯路，值得记下来：为了把 861ms 的显存上传压下来，我一度把它降到
 * 1024x1536（上传量四分之一）。上传确实快了，但**卡面在揭示时是画面里最大的元素**，
 * 1024 宽在主屏上只有约 1.7 倍过采样，三线性过滤一开始混合 mip 层就明显发软 ——
 * 一眼就能看出"没有原来清晰"。
 *
 * 而当初降分辨率的理由已经不成立了：上传现在发生在**标题画面**上、并且按层拆帧，
 * 根本不在点击路径里。所以质量拿回来，代价只是标题画面上多几次约 200ms 的停顿 ——
 * 那本来就是加载画面。
 */
const ART_W = 2048, ART_H = 3072;

/**
 * 按目标尺寸解码一层卡面。
 *
 * createImageBitmap 能在解码时直接出目标尺寸，而且做在 worker 线程上：主线程从来
 * 不需要拿到一整张 2048x3072。
 *
 * imageOrientation:'flipY' 是在复刻 UNPACK_FLIP_Y_WEBGL 的既有行为 —— WebGL 不
 * 能翻转 ImageBitmap，所以只能在这里翻，然后告诉 three 不要再翻第二次。着色器里的
 * UV 约定（几何 UV 预先反转、vUv.y = 1 - uv.y）依赖的就是这个朝向。
 */
async function loadLayer(url) {
  try {
    const blob = await (await fetch(url)).blob();
    const bmp = await createImageBitmap(blob, {
      resizeWidth: ART_W, resizeHeight: ART_H, resizeQuality: "high",
      imageOrientation: "flipY",
    });
    const t = new THREE.Texture(bmp);
    t.flipY = false;
    return markDataTexture(t);
  } catch (err) {
    // 这些选项不被支持时退回原路径：只是慢，不是坏
    console.warn("[fate] downscaled decode unavailable, falling back to full size", err);
    return markDataTexture(await loader.loadAsync(url));
  }
}

async function loadCharacterTextures(character) {
  const t0 = performance.now();
  const urls = layerUrls(character.card);
  const [subject, background, lineart] = await Promise.all([
    loadLayer(urls.subject),
    loadLayer(urls.background),
    loadLayer(urls.lineart),
  ]);
  mark("art.fetch+decode", t0);
  return {
    subject,
    background,
    lineart,
    text: BLANK_TEXT,
  };
}

function disposeCharacterTextures(t) {
  if (!t) return;
  for (const k of Object.keys(t)) t[k]?.dispose();
}

/**
 * Put the character's art on the card and on the die-cut figure, INVISIBLY.
 *
 * Called as soon as the textures decode - normally during the intro or the
 * shuffle, seconds before fate-lock. Assigning four 2048x3072 layers and
 * compiling the front shader are both expensive; doing it at the reveal (which
 * is also the instant the exposure dips) stalled the frame at the darkest point
 * of the ritual, which is what read as a black flash. Staging early means the
 * reveal itself costs nothing but an opacity ramp.
 */
async function stageCharacter() {
  if (!characterTextures) return;
  const t0 = performance.now();
  const card = deck.cards[host.selected];
  deck.setCharacter(card, characterTextures);
  revealFigure.setTextures(characterTextures);
  mark("stage.assign", t0);

  // Upload now instead of letting it land on the reveal frame - but one layer per
  // frame. renderer.initTexture is synchronous, so uploading all three at once
  // freezes a single frame for the whole cost (861ms at full size). Split, each
  // frame carries one layer, and this whole sequence runs while the title screen
  // is still up - i.e. before the player has clicked.
  const t1 = performance.now();
  for (const k of ["subject", "background", "lineart", "text"]) {
    const t = characterTextures[k];
    if (t) renderer.initTexture(t);
    await nextFrame();
  }
  mark("stage.upload", t1);

  // Compile and upload everything this run will draw - now, while the title
  // screen is still up, rather than when the player presses the button.
  //
  // The die-cut figure stays hidden until the descend, and its shader compiling
  // at that moment measured as a stall landing right on the reveal. The deck's
  // back texture and edge shaders had the same problem. So for one throwaway
  // frame everything is switched on at once - figure visible, cards moved far
  // below the floor so they are genuinely drawn but never seen - and then put
  // back. Doing it here rather than in onInvoke means the click costs nothing.
  const figWas = revealFigure.visible;
  const saved = deck.cards.map((c) => ({ o: c.st.opacity, y: c.st.y }));
  revealFigure.visible = true;
  revealFigure.setReveal(0);
  deck.cards.forEach((c) => { c.st.opacity = 1; c.st.y = -60; });
  apply();

  const t2 = performance.now();
  // vfx.play() builds the character's particle rig lazily on its first call,
  // which is the descend beat.
  vfx.warm(selectedCharacter);
  mark("stage.vfxWarm", t2);

  const t3 = performance.now();
  renderer.compile(scene, camera);
  mark("stage.compile", t3);
  // Let the frame land before the throwaway draw. Shader compilation and the
  // first draw are two separate GPU costs, and stacking them makes one frame
  // carry both.
  await nextFrame();

  const t4 = performance.now();
  render();
  mark("stage.warmRender", t4);

  deck.cards.forEach((c, i) => { c.st.opacity = saved[i].o; c.st.y = saved[i].y; });
  revealFigure.visible = figWas;
  vfx.hide();
  apply();
  loadState = "staged";

  // Throw away the frame-rate samples taken while the art was decoding and
  // uploading: they measure the loader, not the renderer.
  //
  // Without this, the very first window that is even allowed to adapt still
  // contains those heavy frames, adaptQuality reads "this machine is too slow",
  // and answers by dropping the resolution - which reallocates every
  // post-processing render target and measured as a 681ms frame on the title
  // screen. Restarting the window means a downgrade is only ever triggered by
  // frames that were actually rendered at the current resolution.
  fpsAccum = 0;
  fpsFrames = 0;
  lastAdapt = performance.now();
  mark("stage.total", t0);
  // 现在开始测量是干净的：标题画面静止、素材已经传完。
  tuneDepthOfField();
}

/**
 * 景深：在标题画面上做一次 A/B，而不是拿一个绝对帧率去判断。
 *
 * 为什么不能用绝对阈值：这台机器（Intel Iris Xe 集显笔记本）连跑几轮测试会受热
 * 降频，同一份代码的 p50 在 12.8ms 到 25.5ms 之间漂移过。用"低于 52fps 就关"这类
 * 规则量到的是机器当下的状态，不是景深的代价。
 *
 * 所以：带着景深测一段，再用 BlendFunction.SKIP 关掉测一段，比较两者。只有"关掉
 * 之后确实明显更快"才关，否则保留景深（画面优先）。切换本身免费 —— EffectPass
 * 直接跳过这个 effect，不重建任何 render target。
 */
async function tuneDepthOfField() {
  if (!dof) return;
  const sample = async (settleMs) => {
    await new Promise((r) => setTimeout(r, settleMs));
    const s = [];
    for (let i = 0; i < 2 && introDrift; i++) {
      await new Promise((r) => setTimeout(r, 520));
      if (fpsShown) s.push(fpsShown);
    }
    s.sort((a, b) => a - b);
    return s.length ? s[Math.floor(s.length / 2)] : 0;
  };
  const withDof = await sample(2000);
  // 玩家可能已经点下去了。绝不能在仪式进行到一半的时候换画质。
  if (!introDrift) return;
  dof.blendFunction = BlendFunction.SKIP;
  const without = await sample(900);
  if (!introDrift) { dof.blendFunction = BlendFunction.NORMAL; return; }
  if (withDof && without && without > withDof * 1.12) {
    timings.dof = `off (${withDof} -> ${without} fps without it)`;
  } else {
    dof.blendFunction = BlendFunction.NORMAL;
    timings.dof = `on (${withDof} vs ${without} fps without it)`;
  }
}

/** Raise the staged face. Returns false if nothing has been staged yet. */
function revealCharacterFace() {
  const card = deck.cards[host.selected];
  if (!card?.hasCharacter) return false;
  card.faceK = 1;
  // 技能面在这里才打开。它写着这一局的答案，洗牌时露出来就没有"抽"这件事了；
  // 而且它只在翻过来的时候才被看到，所以提前打开也不会提前泄露。
  if (!card.skillMat.map) {
    // 不能让它静默失败。这里的异常会被 ?t= 那条路径外层 的 try/catch 吞掉，
    // 表现就是"点了没反应"而且毫无线索 —— 实测踩过一次。
    try {
      const tex = makeSkillFace({
        nameCn: selectedCharacter.skillCn,
        nameEn: selectedCharacter.skillEn,
        accent: selectedCharacter.palette.accent,
      });
      skillTexture = tex;
      deck.setSkillFace(card, tex);
    } catch (err) {
      console.error("[fate] skill face failed", err);
      skillError = String((err && err.message) || err);
    }
  }
  loadState = "ready";
  return true;
}

/**
 * Kick the load off at module init, not at the reveal.
 *
 * `selected` is already decided above, and the intro makes the player click
 * before the ritual begins, so this normally finishes with seconds to spare.
 *
 * This replaces a real bug: the LIVE path never called loadCharacterTextures at
 * all - only the ?t= screenshot branch did. A real player's card therefore
 * never received its face, and the whole ritual ran with a blank card.
 */
const characterReady = loadCharacterTextures(selectedCharacter)
  .then(async (t) => {
    characterTextures = t;
    mark("art.arrivedAt", BOOT_T);
    // Await the staging: it now yields frames, and onInvoke awaits THIS promise
    // before lifting the curtain. Resolving early would let the ritual start
    // with layers still queued for upload.
    await stageCharacter();
    return t;
  })
  .catch((err) => { console.error("[fate] character art failed to load", err); return null; });

// ----------------------------------------------------------------- ritual ---
const ctx = {
  deck, cards: deck.cards, circle, temple, vfx, host, ui, audio,
  selectedCharacter,
  onFateLocked() {
    // The art is staged and uploaded by now in the normal case. If it is still
    // in flight, raise it the moment it lands rather than leaving a blank card.
    if (!revealCharacterFace()) characterReady.then(() => revealCharacterFace());
    ui.setStatus("");
  },
  onRitualEnd() {
    // Safe to trade resolution again now that the cut is over.
    qualityLocked = false;
    lastAdapt = performance.now();
    ui.showActions();
    if (window.__fate) window.__fate.state = "interactive";
  },
};

const tl = createTimeline(ctx);

// ---------------------------------------------------------------- apply pass -

/** Reused for the grade's hero-protection projection; apply() runs every frame. */
const _heroV = new THREE.Vector3();
const _pose = { x: 0, y: 0, z: 0, rx: 0, ry: 0, rz: 0 };

function apply() {
  // 截图用：?flip=1 把技能面固定翻到位，这样 tools/shots.mjs 能拍到它。
  // 和 ?t= / ?char= 一样属于验证用的确定性钩子。
  if (FLIP_FIXED !== null) host.skillFlip = FLIP_FIXED;

  // camera
  camera.position.set(host.cam.x, host.cam.y, host.cam.z);
  camera.lookAt(host.look.x, host.look.y, host.look.z);

  for (const card of deck.cards) {
    const st = card.st;
    const g = card.group;

    if (st.shuffleP > 0 && st.shuffleP < 1) {
      shufflePose(card, st.shuffleP, _pose);
      g.position.set(_pose.x, _pose.y, _pose.z);
      g.rotation.set(_pose.rx, _pose.ry, _pose.rz);
    } else {
      g.position.set(st.x, st.y, st.z);
      g.rotation.set(st.rx, st.ry, st.rz);
    }
    g.scale.setScalar(st.s);

    for (const u of card.uniforms) {
      u.uOpacity.value = st.opacity;
      u.uFoil.value = st.foil;
    }
    // The character face is gated separately from the card's own opacity, so it
    // can be compiled and uploaded while still invisible. See faceK in cards.js.
    card.frontMat.uniforms.uOpacity.value = st.opacity * card.faceK;
    // ...and the +Z side keeps showing the back design until then. Without it,
    // every card whose face turned toward the camera during the shuffle was a
    // hollow shell - just its thin edge walls - which is what read as "half the
    // cards are blank".
    card.downMat.uniforms.uOpacity.value = st.opacity * (1 - card.faceK);
  }

  deck.updateView(camera, clockT);

  // exposure dip on fate-lock: dim the whole hall, not just the lights.
  // This used to write `temple.amb.intensity = 1.45 * e` every frame, which
  // OVERWROTE the temple's own (much brighter) settings - so the hall could
  // never be lit properly and the pillars stayed black silhouettes no matter
  // what the temple asked for. Now it scales the configured values instead.
  // 翻开看技能时让殿堂退后一档。
  //
  // "世界暗下去、焦点浮起来"是大厂界面最常用的一招，也是这个交互之前最缺的东西：
  // 卡翻过来时周围一切照旧，于是读起来只是"页面上换了一块内容"。压 22% 曝光，
  // 加上光柱和暗角本来就有的层次，注意力自然收到牌上。
  const e = host.exposure * (1 - 0.22 * host.skillFlip);
  temple.setExposure(e);

  if (bloom) {
    bloom.intensity = 0.62 * (0.72 + 0.28 * e) + host.revealPulse * 1.5;
    // 颗粒必须是动的。静止的颗粒看起来就是一块脏屏幕。
    if (grade) grade.uniforms.get("uTime").value = clockT;
    const pulse = host.revealPulse;
    chroma.offset.set(0.0004 + pulse * 0.006, 0.0004 + pulse * 0.006);
    vignette.darkness = 0.62 + (1 - e) * 0.18;
  }

  // aura follows the chosen card
  const chosen = deck.cards[host.selected];

  // ---- 调色的"主角豁免区" ------------------------------------------------
  //
  // 调色是整帧生效的，它分不清"殿堂的石墙"和"卡面上那张画"。而 lift 和阴影分色调
  // 的机制就是给每个暗部像素**加光** —— 卡面那层深色底会被抬起并推蓝（实测
  // #150100/亮度 7 → #16121e/亮度 21），看起来就是蒙了一层雾。
  //
  // 反过来把 lift 拿掉，整帧平均亮度从 48.2 掉到 32.2 —— 殿堂的调子也没了。
  // 所以不是二选一：把主角所在的屏幕区域传给调色，在那个范围里把 lift 和分色调
  // 渐变到 0。3D 场景保留电影的抬黑，自发光的美术资源保持它本来的黑。
  if (grade) {
    const g = chosen.group;
    const figK = host.figureK || 0;
    const dist = Math.max(0.001, camera.position.distanceTo(g.position));
    // 卡面的世界半尺寸 → 屏幕半尺寸（uv 为单位）。立绘比卡大一圈，所以它在场时放大。
    const sc = g.scale.x * (figK > 0.001 ? 1.35 : 1.06);
    const k = 1 / (dist * Math.tan(camera.fov * Math.PI / 360));
    const u = grade.uniforms;
    const p = _heroV.copy(g.position).project(camera);
    u.get("uHeroXY").value.set(p.x * 0.5 + 0.5, p.y * 0.5 + 0.5);
    u.get("uHeroR").value.set(
      CARD_W * 0.5 * sc * k / camera.aspect,
      CARD_H * 0.5 * sc * k
    );
    u.get("uHeroK").value = Math.max(chosen.faceK, figK);
  }

  if (vfx.aura.visible) {
    const p = chosen.group.position;
    vfx.follow(new THREE.Vector3(p.x, p.y, p.z), 1 / 60, chosen.st.s);
  }
  vfx.setIntensity(host.sigK);

  // ---- die-cut figure handoff -------------------------------------------
  // As figureK rises the card's rectangle dissolves and the character stands
  // free in front of its own backdrop plate, anchored where the card was.
  // The card's opacity is written BEFORE the per-card uniform push below, so it
  // takes effect on this frame rather than lagging one behind.
  const fk = host.figureK || 0;
  // 翻转时把立绘收回去、卡重新显形 —— 见下面 figK 那段的说明。
  const flipBack = 1 - host.skillFlip;
  if (fk > 0.001) chosen.st.opacity = Math.max(0, 1 - fk * 1.35 * flipBack);

  // 上面那个循环（apply 开头）算出的最终变换会被这一遍覆盖，所以翻转也写在这里，
  // 否则抬升量会被前一遍的 g.scale.setScalar / g.position.set 抹掉。
  for (const card of deck.cards) {
    const st = card.st;
    const g = card.group;

    if (st.shuffleP > 0 && st.shuffleP < 1) {
      shufflePose(card, st.shuffleP, _pose);
      g.position.set(_pose.x, _pose.y, _pose.z);
      g.rotation.set(_pose.rx, _pose.ry, _pose.rz);
    } else {
      g.position.set(st.x, st.y, st.z);
      g.rotation.set(st.rx, st.ry, st.rz);
    }
    g.scale.setScalar(st.s);

    // ---- 技能面翻转 ------------------------------------------------------
    //
    // 揭示之后点卡面，把它翻过来 —— 背面写着这一局的能力。绕 Y 轴 180°，同时
    // 在半途（sin 最大处）把牌抬向相机并放大：翻面时牌不会插进背后的柱子，
    // 停下来时技能文字也离眼睛更近、更好读。
    if (card === chosen && host.skillFlip > 0) {
      const k = host.skillFlip;
      // s 停在 1，pop 只在中途鼓一下。
      //
      // 放大倍数从 1.42 收到 1.06：第一版翻过来是一张占满画面中央的平面大卡，
      // 读起来像网页弹窗，不像手里的一件东西。现在说明文字交给左边的信息面板，
      // 卡只需要**轻微前移并侧一点**，把"这是被拿起来的物件"讲清楚就够了。
      const s = Math.sin(k * Math.PI / 2);
      const pop = Math.sin(k * Math.PI);
      g.rotation.y += k * Math.PI + s * 0.055;   // 停住时略带一点角度，不要死平
      g.rotation.x += s * -0.045;                 // 微微仰起
      g.position.z += s * 0.42 + pop * 0.30;
      g.position.y += s * 0.06;
      g.scale.multiplyScalar(1 + s * 0.06 + pop * 0.045);
    }

    for (const u of card.uniforms) {
      u.uOpacity.value = st.opacity;
      u.uFoil.value = st.foil;
    }
    // 技能面是普通 MeshBasicMaterial，没有那套 shader uniform，单独跟一次透明度
    if (card.skillMat) card.skillMat.opacity = st.opacity;
    // The character face is gated separately from the card's own opacity, so it
    // can be compiled and uploaded while still invisible. See faceK in cards.js.
    card.frontMat.uniforms.uOpacity.value = st.opacity * card.faceK;
    // ...and the +Z side keeps showing the back design until then. Without it,
    // every card whose face turned toward the camera during the shuffle was a
    // hollow shell - just its thin edge walls - which is what read as "half the
    // cards are blank".
    card.downMat.uniforms.uOpacity.value = st.opacity * (1 - card.faceK);
  }

  // ---- 立绘 ↔ 卡面：翻牌时把立绘收回去 ------------------------------------
  //
  // 揭示之后画面上那个"人"其实不是卡，是 revealFigure（一张独立的切图立绘），
  // 而卡本身早就淡到透明了（opacity = 1 - fk*1.35）。所以第一版"翻卡"完全没有
  // 反应 —— 翻的是一张看不见的牌，这一点是从运行时的 rotY=3.142 / skillVis=true
  // 却什么都没变才看出来的。
  //
  // 现在两者互补：翻转时立绘溶回卡里、卡重新显形，于是"点一下"读起来是
  // **人收回牌里，牌翻过来给你看技能**；再点一次反向放出来。
  const figK = fk * (1 - host.skillFlip);
  if (figK > 0.001) {
    revealFigure.visible = true;
    const p = chosen.group.position;
    revealFigure.group.position.set(p.x, p.y, p.z);
    revealFigure.group.rotation.set(0, 0, 0);   // always faces the camera square-on
    revealFigure.setReveal(figK);
    revealFigure.update(camera, clockT);
  } else {
    revealFigure.visible = false;
  }
}

// --------------------------------------------------------------- main loop ---
let clockT = 0;
let fpsAccum = 0, fpsFrames = 0, fpsShown = 0;
let raf = null;

// ---------------------------------------------------- adaptive resolution ---
// The scene is fill-rate bound (post stack + card shader + additive particles),
// and profiling showed the cost is spread rather than sitting in any one
// emitter: cutting particles, the stone noise and the whole post stack each
// moved the frame rate by only a few fps. The effective lever is therefore how
// many pixels get shaded.
//
// This scales the device pixel ratio between 0.62x and 1x to hold the frame
// near 60, with a dead band (48..58) and a cooldown so it cannot oscillate.
//
// Measured caveat: a quality change calls setPixelRatio + composer.setSize,
// which reallocates EVERY pass's render target. Left ungated, the first one
// landed 0.87s into the ritual and froze the frame for 824ms - the worst hitch
// in the whole sequence - and it also silently changed the sharpness of the
// shot partway through. So it is locked for the duration of the cut.
const BASE_DPR = Math.min(window.devicePixelRatio || 1, 2);
let qualScale = 1;
let lastAdapt = 0;
let goodWindows = 0;
let qualityLocked = false;

/**
 * 自适应分辨率：默认**关闭**，要 ?adaptive=1 才打开。
 *
 * 它原本的意图是帮弱机器保住帧率，但实测它造成的问题远大于收益：
 *
 *   · 它唯一有机会动作的窗口是标题画面（第一次点击就把 qualityLocked 打开），
 *     而标题画面的帧率并不代表仪式里的帧率 —— 在那里下判断本身就是错的时机。
 *   · 一旦降下去，整局就锁在那个倍率上。实测中 setPixelRatio 被调用一次、降到
 *     0.90，然后整局都在 90% 分辨率下渲染再放大，画面整体发糊 —— 这是"看起来
 *     模糊"的真正原因，和景深无关。
 *   · 每次改动都要重新分配整条后期链的 render target，代价是 400~700ms 的卡顿。
 *
 * 默认关闭之后，渲染倍率是确定的、恒定的，画面永远是最清晰的。
 */
const ADAPTIVE = params.get("adaptive") === "1";

function adaptQuality(fps, now) {
  if (!ADAPTIVE) return;
  if (qualityLocked) return;
  // Never adapt while the character art is still arriving.
  //
  // Decoding three 2048x3072 PNGs drags the frame rate down for several seconds,
  // which is exactly the signal this function looks for - so it used to answer
  // "we are too slow" by dropping the resolution, and reallocating every
  // post-processing render target. Measured: one composer.setSize at 0.73s
  // producing a 698ms frame, at the moment the player pressed the button.
  // Slow frames while loading are not a reason to change the render resolution.
  if (loadState !== "staged") return;
  if (!fps || now - lastAdapt < 3000) return;
  let next = qualScale;
  if (fps < 48 && qualScale > 0.62) {
    next = Math.max(0.62, qualScale - 0.1);
    goodWindows = 0;
  } else if (fps > 58 && qualScale < 1) {
    // Only climb back once the frame rate has genuinely held up. Chasing 1.0 on
    // a vsync-capped display re-allocated the whole post chain every couple of
    // seconds for no visible gain.
    if (++goodWindows < 3) return;
    next = Math.min(1, qualScale + 0.06);
  } else {
    goodWindows = 0;
    return;
  }
  if (next === qualScale) return;
  qualScale = next;
  lastAdapt = now;
  renderer.setPixelRatio(BASE_DPR * qualScale);
  renderer.setSize(window.innerWidth, window.innerHeight);
  composer?.setSize(window.innerWidth, window.innerHeight);
}

function render() {
  if (composer) composer.render();
  else renderer.render(scene, camera);
}

function frame(dt) {
  clockT += dt;
  // 标题画面上的相机不能是死的。
  //
  // 一张完全静止的图看起来是"渲染结果"；缓慢移动的才是"镜头"。这里只是很轻的
  // 推轨与浮动（z 振幅 0.55、y 振幅 0.10），但画面立刻从截图变成开场。
  // 点击之后交给时间轴，所以只在 introDrift 为真时生效。
  if (introDrift) {
    host.cam.z = 7.6 + Math.sin(clockT * 0.10) * 0.55;
    host.cam.y = 1.72 + Math.sin(clockT * 0.065 + 1.3) * 0.10;
    host.look.y = 1.2 + Math.sin(clockT * 0.085) * 0.06;
  }
  temple.update(clockT, dt);
  circle.update(clockT);
  dust.update(clockT);
  circleMotes.update(clockT);
  trail.update(clockT);
  vfx.update(clockT);
  apply();
  render();
}

let last = performance.now();
/**
 * 纯背景模式（?bg=1）下把渲染降到 ~12fps。
 *
 * 这一层是**卷宗墙后面的背景**。它一出帧，上面那几层带 mix-blend-mode 的覆盖层
 * 就得把整个视口重新混合一次 —— 实测卷宗墙只有 16.5fps，根子就在这儿：
 * 一个一直在跑的 WebGL 场景当背景，代价不是它自己，是**它带动了整页的合成**。
 *
 * 12fps 对一层缓慢漂移的背景完全够用，肉眼也看不出和 60 的差别。
 */
const BG_INTERVAL = 1000 / 12;
let bgAccum = 0;

function loop(now) {
  raf = requestAnimationFrame(loop);
  const raw = (now - last) / 1000;
  // clamped for the simulation so a stalled tab cannot explode it...
  const dt = Math.min(raw, 1 / 30);
  last = now;

  if (BG_MODE) {
    // 背景模式：攒够 1/12 秒才画一帧，但时间照常推进（漂移速度不变）
    bgAccum += raw;
    if (bgAccum < BG_INTERVAL / 1000) return;
    bgAccum = 0;
    frame(dt);                       // 只画一次，不累加多次
    return;
  }

  frame(dt);

  // ...but the FPS readout must use the REAL elapsed time, otherwise the
  // clamp makes a 1 fps machine report 30 fps and the counter never updates.
  fpsAccum += raw; fpsFrames++;
  if (fpsAccum >= 0.5) {
    fpsShown = Math.round(fpsFrames / fpsAccum);
    ui.setFps(fpsShown);
    fpsAccum = 0; fpsFrames = 0;
    adaptQuality(fpsShown, now);
  }
}

// ---------------------------------------------------------- skill flip -------

/**
 * 点卡面 → 翻过来看技能。
 *
 * 只在仪式结束之后可用（state === "interactive"）：在揭示过程中点会和时间轴的
 * 编排打架，而且那时候牌还在动，点中的位置下一秒就不对了。
 *
 * 命中判定用射线打主角那张牌的整个 group，所以翻过去之后打在技能面上也仍然算
 * 命中 —— 不然第二次点击就点不回来了。
 */
const raycaster = new THREE.Raycaster();
const _ndc = new THREE.Vector2();
let flipTween = null;

function flippedCardHit(ev) {
  const el = renderer.domElement;
  const r = el.getBoundingClientRect();
  _ndc.set(
    ((ev.clientX - r.left) / r.width) * 2 - 1,
    -((ev.clientY - r.top) / r.height) * 2 + 1
  );
  raycaster.setFromCamera(_ndc, camera);
  const chosen = deck.cards[host.selected];
  return raycaster.intersectObject(chosen.group, true).length > 0;
}

function toggleSkillFace() {
  const to = host.skillFlip > 0.5 ? 0 : 1;
  audio.play("card_flip", { gain: 0.9 });
  if (flipTween) flipTween.kill();
  const tl2 = gsap.timeline();

  flipTween = tl2.to(host, {
    skillFlip: to,
    duration: to ? 0.66 : 0.52,
    // 翻过去带一点过冲再稳住；翻回来干脆利落
    ease: to ? "back.out(1.05)" : "power3.inOut",
    onUpdate: () => {
      const pop = Math.sin(host.skillFlip * Math.PI);
      // 牌侧对着相机的那一瞬间：闪光 + 全牌箔面脉冲。
      // 箔面脉冲走的是卡面着色器自己已有的 uFoil，所以"光扫过卡面"是真的在
      // 材质上发生，而不是盖一层贴图。
      if (to && pop > host.skillFlash) {
        host.skillFlash = pop;
        if (pop > 0.9) {
          // 盖住翻面的那一帧光。原来给 0.30 的纯白满屏 —— 和揭示那一次同样
          // 读成过曝，收到 0.20，时长拉到 0.34s 让升段没那么硬。
          ui.flash(0.20, 0.34);
          // revealPulse 会驱动色差（chroma.offset = 0.0004 + pulse*0.006），
          // 平时是时间轴在仪式里把它衰减回 0 的。仪式已经结束了，所以这里必须自己
          // 收回去 —— 否则一次点击就会把全画面的色差永久拉到 8 倍，地上那圈彩虹
          // 就是这么来的。
          host.revealPulse = 0.38;
          // 不要加 overwrite:true —— 它会把**同一个 target 上所有**补间一起杀掉，
          // 包括正在跑的 skillFlip 本身，结果是牌卡在半路（实测停在 0.52）。
          gsap.to(host, { revealPulse: 0, duration: 0.75, ease: "power2.out" });
        }
      }
      deck.setFoil(0.65 + pop * 0.85);
    },
    onComplete: () => {
      host.skillFlash = 0;
      deck.setFoil(0.65);
      // 说明面板比牌晚一步出现（0.06s），让"牌翻过去 → 信息落下来"读成一个动作
      ui.showCardHint(to === 0);
    },
  });

  if (to) {
    // 面板在牌快停稳时才亮起，不要和翻转抢注意力
    tl2.call(() => ui.showSkillInfo(selectedCharacter), null, 0.34);
    tl2.call(() => document.getElementById("copy")?.classList.remove("is-on"), null, 0.34);
  } else {
    tl2.call(() => {
      ui.showSkillInfo(null);
      document.getElementById("copy")?.classList.add("is-on");
    }, null, 0.05);
  }
}

renderer.domElement.addEventListener("pointerdown", (ev) => {
  if (window.__fate?.state !== "interactive") return;
  if (!flippedCardHit(ev)) return;
  toggleSkillFace();
});

// ------------------------------------------------------------------ intro ----
// 标题画面上的镜头漂移开关。点击之后时间轴接手相机，必须关掉，否则会和 tl 抢。
let introDrift = true;
if (BG_MODE) document.documentElement.classList.add("bg-mode");   // 背景模式：UI 全隐

ui.onInvoke = async () => {
  if (BG_MODE) return;   // 背景模式不接受点击
  const inv0 = performance.now();
  introDrift = false;
  // Freeze the resolution FIRST, before anything can move it. adaptQuality
  // reallocates every post-processing render target when it steps the scale, and
  // one of those landing during the pre-roll measured as a 698ms frame at exactly
  // the moment the player pressed the button. The curtain is going up, so the
  // resolution must not change from here to the end of the reveal.
  qualityLocked = true;
  audio.unmute();
  ui.hideIntro();
  ui.setBusy(true);
  ui.setStatus("正在装订命运…");
  // The art has been loading since boot (module init). Wait for THAT rather
  // than starting a second fetch: the card is blank until it arrives, and the
  // player should never wait twice for the same file.
  //
  // In a normal session this is already done - staging finishes during the title
  // screen - so this await returns immediately. It only actually waits if the
  // player clicks within a second or two of the page opening.
  if (loadState !== "staged" && loadState !== "ready") {
    loadState = "loading";
    const w = performance.now();
    await characterReady;
    mark("invoke.awaitArt", w);
  }
  if (!characterTextures) {
    loadState = "error";
    ui.setStatus("素材载入失败，本局没有卡面");
  }
  ui.setStatus("");
  ui.setBusy(false);
  circleMotes.uniforms.uOpacity.value = 1;

  mark("invoke.total", inv0);
  tl.play(0);
};

ui.onAgain = () => {
  ui.resetCopy();
  vfx.hide();
  host.sigK = 0;
  circleMotes.uniforms.uOpacity.value = 1;
  // re-roll the fate
  const r = mulberry32((Math.random() * 1e9) | 0);
  host.selected = Math.floor(r() * CHARACTERS.length);
  location.reload();
};

/* --------------------------------------------------------------- hand-off -- */

// The ritual ends by handing the player - and the fate they drew - to the case
// itself. The character ids here are exactly the identity ids the case server
// knows (medium / detective / physician / astrologer / chronicler), so the card
// you draw decides which ability you actually play with. That is the whole point
// of drawing a fate, and it is why this mapping must not drift.
// Same origin by default: the ritual is now mounted at /draw on the game
// server, so accepting a fate returns to / on this very origin - one game, one
// URL. `?case=http://host:port` still overrides it, for running the ritual
// standalone against a case server somewhere else.
const CASE_ORIGIN = (params.get("case") || "").replace(/\/+$/, "");

let accepting = false;
ui.onAccept = async () => {
  if (accepting) return;
  accepting = true;
  ui.setStatus("命运已接受 · 正在开启卷宗…");
  if (window.__fate) window.__fate.state = "accepted";

  const id = selectedCharacter?.id || "medium";
  try {
    // Same origin now, so this simply checks that the game server is answering
    // before we cover the screen and hand over.
    await fetch((CASE_ORIGIN || "") + "/", { method: "HEAD", mode: "no-cors" });

    // ---- 开卷 ----------------------------------------------------------
    //
    // 原来是淡出到 #05040a 再跳转 —— 一次黑场交叉溶解，任何网页都能做。
    // 现在换成"手卷展开"：两根轴从画面正中滑向两侧，中间那张纸随之展开，
    // 上面印着你抽到的身份；卷宗页再从**完全相同的状态**把它收回去，露出卷宗墙。
    //
    // 两个页面共用 /scroll.css 与 /scroll.js，所以这个镜头是连续的 —— 这也是
    // 唯一能让"两次页面加载"读成"一个镜头"的办法。
    if (flipTween) flipTween.kill();
    stampScroll({
      nameCn: selectedCharacter?.nameCn,
      nameEn: selectedCharacter?.nameEn,
      skillCn: selectedCharacter?.skillCn,
      skillEn: selectedCharacter?.skillEn,
      accent: null,
    });
    await unfurlScroll();

    // 卷轴已经盖满，这时候跳转看不到任何接缝
    location.href = `${CASE_ORIGIN}/?identity=${encodeURIComponent(id)}`;
  } catch {
    accepting = false;
    ui.setStatus("卷宗未开启 · 请先运行 turtle-soup 的 node server.mjs");
  }
};

ui.onHover = () => audio.play("button_hover", { gain: 0.35 });

// ------------------------------------------------------------------ boot -----
if (SEEK_T !== null) {
  // deterministic single frame for screenshots
  circleMotes.uniforms.uOpacity.value = 1;
  // Only pay for the character's four 2048x3072 layers when the frame being
  // captured actually shows the card face. Acts one to four are all face-down.
  if (SEEK_T >= ACTS.descend.at) {
    try {
      characterTextures = await characterReady;
      revealCharacterFace();
    } catch (e) { console.error(e); }
  }
  ui.hideIntro();
  ui.setBusy(false);
  tl.pause();
  tl.seek(SEEK_T);
  tl.pause();
  if (SEEK_T >= ACTS.descend.at) {
    vfx.play(selectedCharacter);
    circle.setColor(selectedCharacter.palette.primary, selectedCharacter.palette.accent);
    temple.setRitual(selectedCharacter.palette.light, 6.5);
    ui.showCopy(selectedCharacter);
    const stage = SEEK_T >= ACTS.descend.at + 1.28 ? "actions"
      : SEEK_T >= ACTS.descend.at + 1.02 ? "line"
      : SEEK_T >= ACTS.descend.at + 0.62 ? "skill" : "name";
    ui.revealStage(stage);
  }
  if (SEEK_T >= RITUAL_END) ui.showActions();
  // settle the deterministic clock on the seek time and render exactly once
  clockT = SEEK_T;
  temple.update(clockT, 1 / 60);
  circle.update(clockT);
  dust.update(clockT); circleMotes.update(clockT); trail.update(clockT);
  vfx.update(clockT);
  apply();
  render();
  window.__ready = true;
} else {
  ui.showIntro();
  // one warm-up frame so the hall is visible behind the title card
  clockT = 0;
  temple.update(0, 0); circle.update(0); dust.update(0);
  apply(); render();
  last = performance.now();
  raf = requestAnimationFrame(loop);
}

window.__fate = {
  ready: true,
  tl, host, deck, scene, camera, renderer, composer, temple, vfx, revealFigure,
  characters: CHARACTERS,
  timings,
  get selected() { return host.selected; },
  get character() { return selectedCharacter; },
  get loadState() { return loadState; },
  get fps() { return fpsShown; },
  get skillError() { return skillError; },
  get skillFace() { return !!skillTexture; },
  get skillFlipNow() { return host.skillFlip; },
  get heroRotY() { return deck.cards[host.selected].group.rotation.y; },
  get heroSkillVisible() { return deck.cards[host.selected].skillMesh.visible; },
  get figureKNow() { return +(host.figureK || 0).toFixed(3); },
  seek(t) { tl.pause(); tl.seek(t); tl.pause(); clockT = t; apply(); render(); },
};
