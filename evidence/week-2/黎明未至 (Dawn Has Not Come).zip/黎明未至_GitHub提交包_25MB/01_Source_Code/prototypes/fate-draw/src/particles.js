/**
 * Particle systems.
 *
 * Two families, because they do genuinely different jobs:
 *
 *   createMotes()   THREE.Points + ShaderMaterial. All motion is computed in the
 *                   vertex shader from a per-particle seed, so the CPU touches
 *                   nothing per frame and there are no buffer uploads. Used for
 *                   dust, circle motes, mist, rain, orbiting stars and trails.
 *
 *   createSprites() InstancedMesh of quads. Petals, pages and feathers have to
 *                   TUMBLE, and a point sprite cannot rotate. One instanced draw
 *                   call drives hundreds of them.
 *
 * Modes are compile-time `#define`s rather than a uniform branch, so the shader
 * stays a straight line and the driver can constant-fold it.
 *
 * Everything is seeded (mulberry32) so a given seed always yields the same
 * field - required for the ?t=N screenshot harness to be reproducible.
 */
import * as THREE from "three";

export function mulberry32(a) {
  return function () {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const MODES = {
  DUST: 0,
  MOTE: 1,
  MIST: 2,
  RAIN: 3,
  ORBIT: 4,
  TRAIL: 5,
};

const VERT_HEAD = /* glsl */ `
precision highp float;
attribute vec3 aSeed;      // 0..1 random
attribute vec4 aParams;    // x=size, y=speed, z=phase, w=variant
uniform float uTime, uSizeScale, uOpacity, uPixelRatio, uIntensity;
uniform vec3 uColorA, uColorB, uBounds;
varying float vAlpha;
varying vec3 vColor;

float h(float n) { return fract(sin(n) * 43758.5453); }

void main() {
  vec3 p = position;
  float s = aSeed.x, s2 = aSeed.y, s3 = aSeed.z;
  float sp = aParams.y, ph = aParams.z;
  float t = uTime * sp + ph;
  float size = aParams.x * uSizeScale;
  float alpha = 1.0;
  vColor = mix(uColorA, uColorB, s2);
`;

const VERT_MODES = /* glsl */ `
#if MODE == 0   // DUST - slow ambient drift through a slab of air
  p.x += sin(t * 0.35 + s * 12.0) * 0.9;
  p.y += mod(uTime * 0.05 * sp + s3, 1.0) * uBounds.y - uBounds.y * 0.35;
  p.z += cos(t * 0.28 + s2 * 12.0) * 0.9;
  alpha = 0.30 + 0.55 * (0.5 + 0.5 * sin(uTime * 0.8 + s3 * 30.0));
  vColor *= 0.75 + 0.5 * s3;
#elif MODE == 1 // MOTE - rises from the ritual circle, converges inward
  float life = fract(uTime * 0.11 * sp + s3);
  float rise = life * uBounds.y;
  float conv = 1.0 - smoothstep(0.0, 0.75, life);
  float ang = s * 6.28318 + uTime * 0.22 * (0.5 + s2);
  float rad = (0.35 + s2 * 2.6) * conv;
  p = vec3(cos(ang) * rad, rise, sin(ang) * rad);
  alpha = sin(life * 3.14159) * 0.9;
  size *= 0.6 + conv * 0.9;
#elif MODE == 2 // MIST - character: slow wispy rise with wide sway
  float life = fract(uTime * 0.075 * sp + s3);
  p.y = life * uBounds.y * 1.25 - uBounds.y * 0.18;
  p.x += sin(uTime * 0.55 + s * 9.0) * (0.35 + life * 1.5);
  p.z += cos(uTime * 0.42 + s2 * 9.0) * (0.25 + life * 1.1);
  alpha = sin(life * 3.14159) * 0.75;
  // growth is capped: additive points are fill-rate bound, and letting plumes
  // expand to 3.4x cost more than the whole post stack
  size *= 0.85 + life * 1.6;
#elif MODE == 3 // RAIN - character: fast cold streaks falling through the light
  float fall = fract(uTime * 0.55 * sp + s3);
  p.y = uBounds.y * (1.0 - fall) - uBounds.y * 0.25;
  p.x += (fall - 0.5) * 0.5;
  alpha = smoothstep(0.0, 0.12, fall) * (1.0 - smoothstep(0.8, 1.0, fall)) * 0.85;
  size *= 0.55;
#elif MODE == 4 // ORBIT - character: stars riding inclined rings
  float ang = uTime * (0.16 + s2 * 0.5) * sp + s * 6.28318;
  float rad = aParams.w;
  float inc = (s2 - 0.5) * 1.4;
  vec3 ring = vec3(cos(ang) * rad, 0.0, sin(ang) * rad);
  ring.yz = mat2(cos(inc), -sin(inc), sin(inc), cos(inc)) * ring.yz;
  p = ring + vec3(0.0, 0.35, 0.0);
  alpha = 0.45 + 0.55 * (0.5 + 0.5 * sin(uTime * 2.2 + s3 * 40.0));
  size *= 0.7 + s2 * 0.8;
#elif MODE == 5 // TRAIL - sparks shed by cards during the shuffle
  float life = fract(uTime * uIntensity + s3);
  p = position + aSeed * 0.35 * life;
  p.y -= life * life * 1.2;
  alpha = (1.0 - life) * uOpacity;
  size *= 1.0 - life * 0.6;
#endif
`;

const VERT_TAIL = /* glsl */ `
  vAlpha = clamp(alpha, 0.0, 1.0) * uOpacity;
  vec4 mv = modelViewMatrix * vec4(p, 1.0);
  gl_PointSize = size * uPixelRatio * (260.0 / max(-mv.z, 0.001));
  gl_Position = projectionMatrix * mv;
}
`;

const FRAG = /* glsl */ `
precision highp float;
varying float vAlpha;
varying vec3 vColor;
uniform float uSoft;
void main() {
  vec2 c = gl_PointCoord - 0.5;
  float d = length(c);
  if (d > 0.5) discard;
  float a = smoothstep(0.5, uSoft, d) * vAlpha;
  if (a < 0.003) discard;
  gl_FragColor = vec4(vColor, a);
}
`;

/**
 * @param {object} o
 * @param {THREE.Scene} o.scene
 * @param {number} o.mode      key of MODES
 * @param {number} o.count
 * @param {(rnd:()=>number)=>THREE.Vector3} o.distribute  origin generator
 * @param {THREE.Vector3} o.bounds
 * @param {object} o.color     {a: hex, b: hex}
 */
export function createMotes({
  scene, mode, count = 600, distribute, bounds, color,
  sizeScale = 1, opacity = 1, baseSize = 0.02, seed = 1234,
  blending = THREE.AdditiveBlending, soft = 0.0,
}) {
  const rnd = mulberry32(seed);
  const pos = new Float32Array(count * 3);
  const aSeed = new Float32Array(count * 3);
  const aParams = new Float32Array(count * 4);

  for (let i = 0; i < count; i++) {
    const v = distribute(rnd);
    pos[i * 3] = v.x; pos[i * 3 + 1] = v.y; pos[i * 3 + 2] = v.z;
    aSeed[i * 3] = rnd(); aSeed[i * 3 + 1] = rnd(); aSeed[i * 3 + 2] = rnd();
    aParams[i * 4] = baseSize * (0.5 + rnd() * 1.6);
    aParams[i * 4 + 1] = 0.6 + rnd() * 0.9;
    aParams[i * 4 + 2] = rnd() * 100;
    aParams[i * 4 + 3] = 0.5 + rnd() * 2.2;   // orbit radius, unused elsewhere
  }

  const geo = new THREE.BufferGeometry();
  geo.setAttribute("position", new THREE.BufferAttribute(pos, 3));
  geo.setAttribute("aSeed", new THREE.BufferAttribute(aSeed, 3));
  geo.setAttribute("aParams", new THREE.BufferAttribute(aParams, 4));
  geo.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 40);

  const uniforms = {
    uTime: { value: 0 },
    uSizeScale: { value: sizeScale },
    uOpacity: { value: opacity },
    uPixelRatio: { value: 1 },
    uIntensity: { value: 0 },
    uSoft: { value: soft },
    uColorA: { value: new THREE.Color(color.a) },
    uColorB: { value: new THREE.Color(color.b) },
    uBounds: { value: bounds.clone() },
  };

  const mat = new THREE.ShaderMaterial({
    uniforms,
    defines: { MODE: MODES[mode] },
    vertexShader: VERT_HEAD + VERT_MODES + VERT_TAIL,
    fragmentShader: FRAG,
    transparent: true,
    depthWrite: false,
    blending,
  });

  const points = new THREE.Points(geo, mat);
  points.frustumCulled = false;
  scene.add(points);

  return {
    points, uniforms,
    get visible() { return points.visible; },
    set visible(v) { points.visible = v; },
    setColor(a, b) { uniforms.uColorA.value.setHex(a); uniforms.uColorB.value.setHex(b); },
    update(t) { uniforms.uTime.value = t; },
    dispose() { scene.remove(points); geo.dispose(); mat.dispose(); },
  };
}

const SPRITE_VERT = /* glsl */ `
precision highp float;
attribute vec3 aOrigin;    // per-instance world origin
attribute vec3 aSeed;      // 0..1 random
attribute vec4 aParams;    // x=size, y=fall speed, z=phase, w=spin
uniform float uTime, uSizeScale, uOpacity, uPixelRatio;
uniform vec3 uColorA, uColorB, uBounds;
varying float vAlpha;
varying vec3 vColor;
varying vec2 vUvS;

void main() {
  float s = aSeed.x, s2 = aSeed.y, s3 = aSeed.z;
  float life = fract(uTime * 0.09 * aParams.y + s3);
  vec3 p = aOrigin;

  #if SMODE == 0   // PETAL - heavy, sways, flutters down
    p.y = uBounds.y * (1.0 - life) - uBounds.y * 0.15;
    p.x += sin(uTime * 0.9 + s * 9.0) * 1.5 + (s2 - 0.5) * 1.2;
    p.z += cos(uTime * 0.7 + s2 * 9.0) * 1.1;
    vColor = mix(uColorA, uColorB, s2 * 0.65);
    vAlpha = smoothstep(0.0, 0.1, life) * (1.0 - smoothstep(0.82, 1.0, life));
  #elif SMODE == 1 // PAGE - light, tumbles upward on a draught
    p.y = life * uBounds.y * 1.15 - uBounds.y * 0.12;
    p.x += sin(uTime * 0.65 + s * 7.0) * 1.9;
    p.z += cos(uTime * 0.5 + s2 * 7.0) * 1.4;
    vColor = mix(uColorA, uColorB, s2 * 0.8);
    vAlpha = sin(life * 3.14159) * 0.95;
  #endif

  vAlpha *= uOpacity;

  // billboard into view space, then spin in screen space; the X squash is a
  // tumble so the blade catches the light edge-on instead of staying flat
  vec4 mv = modelViewMatrix * vec4(p, 1.0);
  float spin = uTime * aParams.w + s * 6.28318;
  float tumble = sin(uTime * (1.4 + s2) + s3 * 6.28318);
  mat2 R = mat2(cos(spin), -sin(spin), sin(spin), cos(spin));
  vec2 off = R * (position.xy * aParams.x * uSizeScale);
  off.x *= 0.35 + 0.65 * abs(tumble);
  mv.xy += off;

  vUvS = uv;
  gl_Position = projectionMatrix * mv;
}
`;

const SPRITE_FRAG = /* glsl */ `
precision highp float;
varying float vAlpha;
varying vec3 vColor;
varying vec2 vUvS;
void main() {
  // soft-edged blade / page shape rather than a hard quad
  vec2 c = vUvS - 0.5;
  float shape = 1.0 - smoothstep(0.30, 0.5, length(vec2(c.x * 1.9, c.y)));
  float a = shape * vAlpha;
  if (a < 0.004) discard;
  gl_FragColor = vec4(vColor, a);
}
`;

export function createSprites({
  scene, smode, count = 140, distribute, bounds, color,
  sizeScale = 1, opacity = 1, baseSize = 0.06, seed = 99,
}) {
  const rnd = mulberry32(seed);
  const pos = new Float32Array(count * 3);
  const aSeed = new Float32Array(count * 3);
  const aParams = new Float32Array(count * 4);

  for (let i = 0; i < count; i++) {
    const v = distribute(rnd);
    pos[i * 3] = v.x; pos[i * 3 + 1] = v.y; pos[i * 3 + 2] = v.z;
    aSeed[i * 3] = rnd(); aSeed[i * 3 + 1] = rnd(); aSeed[i * 3 + 2] = rnd();
    aParams[i * 4] = baseSize * (0.6 + rnd() * 1.2);
    aParams[i * 4 + 1] = 0.7 + rnd() * 0.7;
    aParams[i * 4 + 2] = rnd() * 100;
    aParams[i * 4 + 3] = (rnd() - 0.5) * 2.4;
  }

  const quad = new THREE.PlaneGeometry(1, 1);
  const geo = new THREE.InstancedBufferGeometry();
  geo.index = quad.index;
  geo.setAttribute("position", quad.attributes.position);   // per-vertex corner
  geo.setAttribute("uv", quad.attributes.uv);
  geo.setAttribute("aOrigin", new THREE.InstancedBufferAttribute(pos, 3));
  geo.setAttribute("aSeed", new THREE.InstancedBufferAttribute(aSeed, 3));
  geo.setAttribute("aParams", new THREE.InstancedBufferAttribute(aParams, 4));
  geo.instanceCount = count;
  geo.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 60);

  const uniforms = {
    uTime: { value: 0 },
    uSizeScale: { value: sizeScale },
    uOpacity: { value: opacity },
    uPixelRatio: { value: 1 },
    uColorA: { value: new THREE.Color(color.a) },
    uColorB: { value: new THREE.Color(color.b) },
    uBounds: { value: bounds.clone() },
  };

  const mat = new THREE.ShaderMaterial({
    uniforms,
    defines: { SMODE: smode },
    vertexShader: SPRITE_VERT,
    fragmentShader: SPRITE_FRAG,
    transparent: true,
    depthWrite: false,
    side: THREE.DoubleSide,
    blending: THREE.AdditiveBlending,
  });

  const mesh = new THREE.Mesh(geo, mat);
  mesh.frustumCulled = false;
  scene.add(mesh);

  return {
    mesh, uniforms,
    get visible() { return mesh.visible; },
    set visible(v) { mesh.visible = v; },
    setColor(a, b) { uniforms.uColorA.value.setHex(a); uniforms.uColorB.value.setHex(b); },
    update(t) { uniforms.uTime.value = t; },
    dispose() { scene.remove(mesh); geo.dispose(); mat.dispose(); quad.dispose(); },
  };
}

export { MODES };
