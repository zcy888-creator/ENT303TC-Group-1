/**
 * Die-cut floating reveal.
 *
 * The brief: the drawn character must not stay a rectangular card. Once fate is
 * locked and the card has flipped, the card's frame dissolves and the character
 * steps OUT of it as a die-cut silhouette floating in front of their own
 * backdrop plate - both still carrying the RuiC treatment (view-dependent
 * parallax, foil, line glow), only now with real separation between the figure
 * and the art behind it.
 *
 * Two planes, two materials:
 *
 *   backdrop  background + typography, deeper, floats as a plate
 *   figure    subject only, alpha-discarded at uCut so the silhouette is
 *             die-cut rather than a rectangle, with a sampling-based rim glow
 *             along the contour and its own parallax depth
 *
 * Both are unlit ShaderMaterials reusing the RuiC `common` chunk, so they are
 * NOT affected by the hall's lights and NOT re-graded by the post stack.
 */
import * as THREE from "three";
import { VERT, COMMON, applyRuicUv } from "./ruicShaders.js";

/** Backdrop plate (background + text), 2:3. */
const BD_W = 1.82, BD_H = 2.73;
/** Figure plate - slightly larger than the backdrop so the character overflows it. */
const FG_W = 1.95, FG_H = 2.925;

const BACKDROP_FRAG = COMMON + /* glsl */ `
uniform sampler2D tBackground, tText;
void main() {
  vec2 uv = vUv;
  vec3 col = texture2D(tBackground, clamp(parallax(uv, uBgDepth), 0., 1.)).rgb;
  vec3 foil = film(uv);
  float amount = strength();
  float band = sweep(uv);
  col += foil * amount * band * .05;
  vec4 text = texture2D(tText, uv);
  col = mix(col, text.rgb, text.a);
  gl_FragColor = vec4(pow(clamp(col, 0., 1.), vec3(2.2)), uOpacity);
  #include <colorspace_fragment>
}
`;

const FIGURE_FRAG = COMMON + /* glsl */ `
uniform sampler2D tSubject, tLine;
uniform vec2 uTexel;
uniform float uCut;
void main() {
  vec2 uv = vUv;
  vec2 su = (parallax(uv, uDepth) - .5) * uScale + .5;
  if (su.x < 0. || su.x > 1. || su.y < 0. || su.y > 1.) discard;

  vec4 s = texture2D(tSubject, su);
  if (s.a < uCut) discard;                    // <-- the die-cut

  vec3 col = s.rgb;
  vec3 foil = film(uv);
  float amount = strength();
  float band = sweep(uv);
  float lum = dot(col, vec3(.2126, .7152, .0722));

  // laminate fill on the figure itself
  col += foil * amount * band * (.075 + .13 * (1. - lum));

  // sparse foil flakes, same hash as the card
  vec2 cell = floor(uv * vec2(480., 720.));
  float flake = step(.994, hash(cell)) *
                pow(.5 + .5 * sin(hash(cell + 8.) * 30. + uView.x * 20. + uTime * .6), 10.);
  col += foil * flake * amount * .16;

  // rim glow: where this texel is opaque but its neighbours are not, we are on
  // the silhouette, so lift the contour. This is what sells "die-cut" - without
  // it an alpha-discarded plane reads as a photo cut out with scissors.
  float aN = texture2D(tSubject, su + vec2(0.0,  uTexel.y)).a;
  float aS = texture2D(tSubject, su + vec2(0.0, -uTexel.y)).a;
  float aE = texture2D(tSubject, su + vec2( uTexel.x, 0.0)).a;
  float aW = texture2D(tSubject, su + vec2(-uTexel.x, 0.0)).a;
  float rim = clamp(s.a - min(min(aN, aS), min(aE, aW)), 0.0, 1.0);
  // Strength was 2.2x in a fixed ice-white (0.72, 0.80, 1.0). On a character
  // with this much hair and fabric edge that blew out into a hard white halo
  // around the whole silhouette - it read as a selection outline, not as light.
  // Softer now, and tinted by the card's own foil so it belongs to the art.
  col += mix(vec3(.62, .70, .92), foil, .75) * rim * 0.85;

  // RuiC line-art emission along the contour, same rule as the card front
  float line = (1. - smoothstep(.06, .25, texture2D(tLine, su).r)) * uHasLine;
  col += line * s.a * band * amount * .10;

  gl_FragColor = vec4(pow(clamp(col, 0., 1.), vec3(2.2)), uOpacity);
  #include <colorspace_fragment>
}
`;

function uniforms(depth, bgDepth) {
  return {
    uTime: { value: 0 },
    uFoil: { value: 0.75 },
    uScale: { value: 1.0 },
    uDepth: { value: depth },
    uBgDepth: { value: bgDepth },
    uFinish: { value: 1 },
    uHasLine: { value: 1 },
    uOpacity: { value: 0 },
    uCut: { value: 0.06 },
    uTexel: { value: new THREE.Vector2(1 / 2048, 1 / 3072) },
    uView: { value: new THREE.Vector3(0, 0, 1) },
    tSubject: { value: null },
    tBackground: { value: null },
    tText: { value: null },
    tLine: { value: null },
  };
}

export function createRevealFigure(scene) {
  const group = new THREE.Group();
  group.visible = false;
  scene.add(group);

  const bdU = uniforms(-0.16, -0.16);
  const fgU = uniforms(0.34, -0.16);

  const mk = (w, h, u, frag) => {
    const m = new THREE.ShaderMaterial({
      uniforms: u,
      vertexShader: VERT,
      fragmentShader: frag,
      transparent: true,
      depthWrite: false,
      side: THREE.FrontSide,
      toneMapped: false,
    });
    // PlaneGeometry's stock UVs are NOT pre-inverted, which flipped the figure
    // upside down. Route through the shared contract instead.
    const geo = applyRuicUv(new THREE.PlaneGeometry(w, h, 1, 1), w, h);
    const mesh = new THREE.Mesh(geo, m);
    group.add(mesh);
    return mesh;
  };

  const backdrop = mk(BD_W, BD_H, bdU, BACKDROP_FRAG);
  backdrop.position.z = -0.16;
  const figure = mk(FG_W, FG_H, fgU, FIGURE_FRAG);
  figure.position.z = 0.34;

  const meshes = [
    { mesh: backdrop, u: bdU, depth: -0.16 },
    { mesh: figure, u: fgU, depth: 0.34 },
  ];

  return {
    group,
    backdrop,
    figure,
    uniforms: [bdU, fgU],

    /** Bind one character's four layers. */
    setTextures(t) {
      bdU.tBackground.value = t.background;
      bdU.tText.value = t.text;
      fgU.tSubject.value = t.subject;
      fgU.tLine.value = t.lineart;
      fgU.uHasLine.value = t.lineart ? 1 : 0;
      if (t.subject?.image) {
        const iw = t.subject.image.width, ih = t.subject.image.height;
        fgU.uTexel.value.set(2.0 / iw, 2.0 / ih);
        // fine typography and thin line art survive better with a little more
        // subject zoom here than on the card, because this plane is bigger
        fgU.uScale.value = 1.12;
      }
      bdU.uOpacity.value = 0;
      fgU.uOpacity.value = 0;
    },

    set visible(v) { group.visible = v; },

    /** k = 0..1 cross-fade from "just a card" to "figure standing free". */
    setReveal(k) {
      bdU.uOpacity.value = Math.min(1, k * 1.4);
      // the figure lags the backdrop slightly, so it reads as stepping forward
      fgU.uOpacity.value = Math.min(1, Math.max(0, (k - 0.25) / 0.75) * 1.5);
    },

    setFoil(v) { for (const u of [bdU, fgU]) u.uFoil.value = v; },

    /** Per-mesh view vector: each plane has its own depth, hence its own parallax. */
    update(camera, t) {
      for (const { mesh, u } of meshes) {
        mesh.updateMatrixWorld();
        u.uView.value.copy(camera.position)
          .applyMatrix4(_m.copy(mesh.matrixWorld).invert()).normalize();
        u.uTime.value = t;
      }
    },

    dispose() {
      scene.remove(group);
      for (const { mesh } of meshes) {
        mesh.geometry.dispose();
        mesh.material.dispose();
      }
    },
  };
}

const _m = new THREE.Matrix4();
