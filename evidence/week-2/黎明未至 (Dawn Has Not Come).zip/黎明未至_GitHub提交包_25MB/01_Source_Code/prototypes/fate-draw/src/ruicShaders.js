/**
 * RuiC card shaders.
 *
 * Lifted from RuiC-card-skill/assets/web-template/app.js (the `common`,
 * `frontFragment`, `edgeFragment` and `backFragment` chunks). The parallax,
 * view-dependent foil, line-glow and flake logic are reproduced as-is so the
 * drawn card looks identical to the single-card viewer. Deliberate changes:
 *
 *   - the gold branch of film() is removed entirely (this project is
 *     silver/pearl only, per the art direction)
 *   - the relief / effects-layer branches are dropped; the fate-draw uses the
 *     composite path only
 *   - uFit / uSafeScale / uSafeOffset collapse to a plain 0..1 map, matching
 *     the shipped web bundle's behaviour
 *
 * Everything that produces the "expensive laminate" look is untouched:
 * parallax(), spectrum(), strength(), sweep(), the band multiply, the edge
 * blend, the sparse flake glints and the moving line-art emission.
 */

import * as THREE from "three";

/**
 * Apply the RuiC UV contract to a plane-shaped geometry.
 *
 * `VERT` finishes with `vUv = vec2(uv.x, 1.0 - uv.y)`, so any geometry feeding
 * these shaders must have its V PRE-INVERTED or the artwork renders upside down.
 *
 * This lives in one place on purpose. The convention used to be duplicated:
 * cards.js pre-inverted its hand-built shape, but revealFigure.js used
 * THREE.PlaneGeometry's stock UVs (`uv.y = y/h + 0.5` - NOT inverted), so the
 * die-cut figure came out flipped the instant the card dissolved into it.
 * One helper, used by both, makes that class of bug impossible to reintroduce.
 *
 * @param {THREE.BufferGeometry} geo plane geometry carrying a `uv` attribute
 * @param {number} w plane width in local units
 * @param {number} h plane height in local units
 */
export function applyRuicUv(geo, w, h) {
  const pos = geo.attributes.position;
  const uv = geo.attributes.uv;
  if (!pos || !uv) return geo;
  for (let i = 0; i < pos.count; i++) {
    uv.setXY(i,
      pos.getX(i) / w + 0.5,
      1.0 - (pos.getY(i) / h + 0.5),
    );
  }
  uv.needsUpdate = true;
  return geo;
}

export const VERT = /* glsl */ `
varying vec2 vUv;
void main() {
  vUv = vec2(uv.x, 1.0 - uv.y);
  gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
}
`;

export const COMMON = /* glsl */ `
precision highp float;
varying vec2 vUv;
uniform float uTime, uFoil, uScale, uDepth, uBgDepth, uFinish, uHasLine, uOpacity;
uniform vec3 uView;

float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float inside(vec2 p) { return step(0., p.x) * step(0., p.y) * step(p.x, 1.) * step(p.y, 1.); }

// Signed-depth UV offset. The view direction is transformed into card-local
// space by the host each frame, which is what makes the layers separate.
vec2 parallax(vec2 uv, float depth) {
  return uv + uView.xy / max(abs(uView.z), .4) * depth * .10;
}
vec3 spectrum(float phase) {
  return .66 + .25 * cos(6.28318 * (phase + vec3(0., .33, .67)));
}
float strength() { return abs(uFinish - 2.0) < 0.05 ? 0. : uFoil; }

// finish 0 = pearl (iridescent colour), 1 = silver (desaturated cold foil),
// 2 = original (no foil at all).
vec3 film(vec2 uv) {
  float phase = uv.x * .85 + uv.y * .55 + uView.x * 1.5 - uView.y * .9;
  vec3 color = spectrum(phase);
  return mix(color, vec3(dot(color, vec3(.2126, .7152, .0722))), step(.5, uFinish));
}
float sweep(vec2 uv) {
  return pow(.5 + .5 * sin((uv.x * .72 + uv.y * .45 + uView.x * 1.2 + uView.y * .6) * 6.283), 10.);
}
`;

export const FRONT = COMMON + /* glsl */ `
uniform sampler2D tSubject, tBackground, tText, tLine;
void main() {
  vec2 uv = vUv;
  vec2 su = (parallax(uv, uDepth) - .5) * uScale + .5;
  vec2 bu = parallax(uv, uBgDepth);

  vec4 subject = texture2D(tSubject, clamp(su, 0., 1.));
  subject.a *= inside(su);
  vec3 bg = texture2D(tBackground, clamp(bu, 0., 1.)).rgb;
  vec3 col = mix(bg, subject.rgb, subject.a);

  vec3 foil = film(uv);
  float amount = strength();
  float luminance = dot(col, vec3(.2126, .7152, .0722));
  float band = sweep(uv);

  // laminate darkens where the band is not, and lifts where it sweeps past
  col *= 1. - amount * .21 * (1. - foil) * (.2 + band * .8);
  col += foil * amount * band * (.065 + .11 * (1. - luminance));

  float edge = 1. - smoothstep(.015, .06, min(min(uv.x, 1. - uv.x), min(uv.y, 1. - uv.y)));
  col = mix(col, foil * .75 + .21, edge * amount * .3);

  vec2 cell = floor(uv * vec2(480., 720.));
  float flake = step(.994, hash(cell)) *
                pow(.5 + .5 * sin(hash(cell + 8.) * 30. + uView.x * 20. + uTime * .6), 10.);
  col += foil * flake * amount * .13;

  float line = (1. - smoothstep(.06, .25, texture2D(tLine, clamp(su, 0., 1.)).r)) * uHasLine;
  col += line * inside(su) * subject.a * band * amount * .055;

  vec4 text = texture2D(tText, uv);
  col = mix(col, text.rgb, text.a);

  gl_FragColor = vec4(pow(clamp(col, 0., 1.), vec3(2.2)), uOpacity);
  #include <colorspace_fragment>
}
`;

export const EDGE = COMMON + /* glsl */ `
void main() {
  vec3 col = mix(vec3(.66, .69, .67), film(vUv) * .6 + .35, strength() * .7);
  gl_FragColor = vec4(pow(col, vec3(2.2)), uOpacity);
  #include <colorspace_fragment>
}
`;

export const BACK = COMMON + /* glsl */ `
uniform sampler2D tBack;
uniform vec3 uBackTint;
void main() {
  // mirrored so the back reads the same way up as the front when flipped
  vec2 uv = vec2(1. - vUv.x, vUv.y);
  vec4 art = texture2D(tBack, uv);
  vec3 col = vec3(.956, .961, .946);
  col *= 1. - strength() * .12 * (1. - film(vUv));
  col += film(vUv) * sweep(vUv) * strength() * .055;
  col = mix(col, art.rgb, art.a);
  // the deck back carries the ambient character tint so the five face-down
  // cards still feel like they belong to the ritual
  col *= uBackTint;
  gl_FragColor = vec4(pow(clamp(col, 0., 1.), vec3(2.2)), uOpacity);
  #include <colorspace_fragment>
}
`;

/** Shared uniform block. One instance per card so parallax stays per-card. */
export function makeUniforms() {
  return {
    uTime: { value: 0 },
    uFoil: { value: 0.65 },
    uScale: { value: 1.25 },
    uDepth: { value: 0.28 },
    uBgDepth: { value: -0.2 },
    uFinish: { value: 1 },          // silver
    uHasLine: { value: 1 },
    uOpacity: { value: 1 },
    uView: { value: new THREE.Vector3(0, 0, 1) },
    tSubject: { value: null },
    tBackground: { value: null },
    tText: { value: null },
    tLine: { value: null },
    tBack: { value: null },
    uBackTint: { value: new THREE.Vector3(1, 1, 1) },
  };
}
