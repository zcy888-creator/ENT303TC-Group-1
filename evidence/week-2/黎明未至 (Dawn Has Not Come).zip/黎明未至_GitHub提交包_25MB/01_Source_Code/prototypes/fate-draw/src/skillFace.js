/**
 * 卡背的"技能面"。
 *
 * 抽到的牌翻过来背面写着你这一局的能力 —— 这是身份真正落地的地方，所以文字必须
 * 和 turtle-soup/server/abilities.mjs 里的实现一致，不能写成好听的宣传语。
 * characters.js 里的文案是按那份实现在这里写死的。
 *
 * 用 canvas 画而不是做图片：文字在任何分辨率下都是矢量清晰的，改文案不用重新出图，
 * 而且它天然跟着卡面的配色走（每个身份一个强调色）。
 */
import * as THREE from "three";

const W = 1024, H = 1536;

const SERIF_CJK = '"Songti SC","STSong","STZhongsong","Noto Serif SC","SimSun",serif';
const SERIF_LAT = 'Constantia,Georgia,"Times New Roman",serif';

const INK = "#ece7f7";
const MUTED = "#a99fc4";
const GOLD = "#c9a24a";

function hex(n) {
  return "#" + n.toString(16).padStart(6, "0");
}

/** 把 #rrggbb 按比例混向另一个颜色。 */
function mix(a, b, t) {
  const pa = [1, 3, 5].map((i) => parseInt(a.slice(i, i + 2), 16));
  const pb = [1, 3, 5].map((i) => parseInt(b.slice(i, i + 2), 16));
  const p = pa.map((v, i) => Math.round(v + (pb[i] - v) * t));
  return "#" + p.map((v) => v.toString(16).padStart(2, "0")).join("");
}

function spaced(g, text, x, y, spacing) {
  // ctx.letterSpacing 在 Chrome 上可用；不支持时退化成普通绘制，只是字距紧一点。
  const prev = g.letterSpacing;
  g.letterSpacing = `${spacing}px`;
  g.fillText(text, x, y);
  g.letterSpacing = prev || "0px";
}

/** 七角星 + 环：和地面法阵、开场纹章同一个母题。 */
function sigil(g, cx, cy, r, color) {
  g.save();
  g.translate(cx, cy);
  g.strokeStyle = color;
  g.lineWidth = 2.4;
  g.globalAlpha = 0.85;
  g.beginPath(); g.arc(0, 0, r, 0, Math.PI * 2); g.stroke();
  g.globalAlpha = 0.5;
  g.beginPath(); g.arc(0, 0, r * 0.82, 0, Math.PI * 2); g.stroke();

  g.globalAlpha = 0.9;
  g.lineWidth = 2;
  const pts = [];
  for (let i = 0; i < 7; i++) {
    const a = -Math.PI / 2 + (2 * Math.PI * i) / 7;
    pts.push([Math.cos(a) * r * 0.62, Math.sin(a) * r * 0.62]);
  }
  g.beginPath();
  for (let i = 0; i < 7; i++) {
    const p = pts[i], q = pts[(i + 3) % 7];
    g.moveTo(p[0], p[1]); g.lineTo(q[0], q[1]);
  }
  g.stroke();
  g.restore();
}

/** 四角的金色角标，呼应开场画面的画面框。 */
function cornerMarks(g, color) {
  const m = 74, pad = 54, len = 54;
  g.strokeStyle = color;
  g.globalAlpha = 0.55;
  g.lineWidth = 3;
  for (const [sx, sy] of [[1, 1], [-1, 1], [1, -1], [-1, -1]]) {
    const x = sx > 0 ? pad : W - pad;
    const y = sy > 0 ? pad : H - pad;
    g.beginPath();
    g.moveTo(x + sx * len, y); g.lineTo(x, y); g.lineTo(x, y + sy * len);
    g.stroke();
  }
  g.globalAlpha = 1;
  void m;
}

/**
 * 画一张技能卡背。
 *
 * 刻意只放三样东西：纹章、技能名、规则标签。
 *
 * 第一版把整段机制说明也印在卡上，结果是"一张写满小字的黑卡片" —— 卡只有屏幕高度的
 * 六成宽，那点字号根本撑不住一段 CJK，看起来既不像卡也不像说明书。大厂的做法是分开的：
 * **卡是物件，字是排版** —— 卡背给纹章和名字，说明交给旁边的信息面板（见 index.html
 * 的 #skillInfo），那里才有真正的字号和层级。
 *
 * @param {object} o
 * @param {string} o.nameCn    技能中文名
 * @param {string} o.nameEn    技能英文名
 * @param {number} o.accent    该身份的强调色
 */
export function makeSkillFace({ nameCn, nameEn, accent }) {
  const c = document.createElement("canvas");
  c.width = W; c.height = H;
  const g = c.getContext("2d");
  const acc = hex(accent);

  // ---- 底：墨紫，顶部透出该身份的强调色 ----
  const bg = g.createLinearGradient(0, 0, 0, H);
  bg.addColorStop(0, "#1a1430");
  bg.addColorStop(0.5, "#110d20");
  bg.addColorStop(1, "#0a0812");
  g.fillStyle = bg;
  g.fillRect(0, 0, W, H);

  const glow = g.createRadialGradient(W / 2, H * 0.34, 0, W / 2, H * 0.34, H * 0.5);
  glow.addColorStop(0, acc);
  glow.addColorStop(0.30, mix(acc, "#110d20", 0.78));
  glow.addColorStop(1, "rgba(0,0,0,0)");
  g.globalAlpha = 0.42;
  g.fillStyle = glow;
  g.fillRect(0, 0, W, H);
  g.globalAlpha = 1;

  cornerMarks(g, GOLD);

  g.textAlign = "center";

  // ---- 眉题 ----
  g.font = `500 28px ${SERIF_CJK}`;
  g.fillStyle = MUTED;
  spaced(g, "身 份 技 能", W / 2, 232, 12);

  // ---- 中心：刻度环 + 纹章 ----
  //
  // 和开场的星盘印章、地面的法阵是同一套语言：一圈细刻度 + 七角星。
  // 这是整张卡背的视觉主体，也是"这是个物件"的来源。
  const cx = W / 2, cy = 600, rOut = 268, rIn = 236;
  g.save();
  g.strokeStyle = "rgba(201,162,74,0.55)";
  g.lineWidth = 2.5;
  for (let i = 0; i < 60; i++) {
    const a = (i / 60) * Math.PI * 2 - Math.PI / 2;
    const long = i % 5 === 0;
    const r0 = long ? rIn - 20 : rIn;
    g.globalAlpha = long ? 0.95 : 0.45;
    g.beginPath();
    g.moveTo(cx + Math.cos(a) * r0, cy + Math.sin(a) * r0);
    g.lineTo(cx + Math.cos(a) * rOut, cy + Math.sin(a) * rOut);
    g.stroke();
  }
  g.globalAlpha = 1;
  g.lineWidth = 2;
  g.strokeStyle = "rgba(201,162,74,0.45)";
  g.beginPath(); g.arc(cx, cy, rIn - 34, 0, Math.PI * 2); g.stroke();
  g.globalAlpha = 0.30;
  g.beginPath(); g.arc(cx, cy, rOut + 16, 0, Math.PI * 2); g.stroke();
  g.restore();

  sigil(g, cx, cy, 150, GOLD);

  // ---- 技能名 ----
  const nameGrad = g.createLinearGradient(W * 0.18, 0, W * 0.82, 0);
  nameGrad.addColorStop(0, "#8a6f2e");
  nameGrad.addColorStop(0.32, "#f0d99a");
  nameGrad.addColorStop(0.55, "#fff7dc");
  nameGrad.addColorStop(1, "#c9a24a");
  g.font = `500 132px ${SERIF_CJK}`;
  g.fillStyle = nameGrad;
  spaced(g, nameCn, W / 2, 1088, 20);

  g.font = `400 34px ${SERIF_LAT}`;
  g.fillStyle = MUTED;
  spaced(g, nameEn, W / 2, 1156, 10);

  // ---- 分隔 ----
  const dy = 1228, half = 210;
  const lg = g.createLinearGradient(W / 2 - half, 0, W / 2 + half, 0);
  lg.addColorStop(0, "rgba(201,162,74,0)");
  lg.addColorStop(0.5, "rgba(201,162,74,0.85)");
  lg.addColorStop(1, "rgba(201,162,74,0)");
  g.strokeStyle = lg;
  g.lineWidth = 2;
  g.beginPath(); g.moveTo(W / 2 - half, dy); g.lineTo(W / 2 + half, dy); g.stroke();
  g.fillStyle = GOLD;
  g.save(); g.translate(W / 2, dy); g.rotate(Math.PI / 4); g.fillRect(-8, -8, 16, 16); g.restore();

  // ---- 规则标签 ----
  const tag = "每 局 一 次";
  g.font = `500 32px ${SERIF_CJK}`;
  const tw = g.measureText(tag).width + 128;
  const ty = 1290;
  g.strokeStyle = "rgba(201,162,74,0.6)";
  g.lineWidth = 2;
  g.strokeRect(W / 2 - tw / 2, ty, tw, 74);
  g.fillStyle = GOLD;
  g.textBaseline = "middle";
  g.fillText(tag, W / 2, ty + 39);
  g.textBaseline = "alphabetic";

  g.font = `400 24px ${SERIF_CJK}`;
  g.fillStyle = "rgba(169,159,196,0.5)";
  spaced(g, "黎明未至 · 海龟汤", W / 2, 1450, 8);

  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 8;
  // 贴图不做任何翻转。
  //
  // 技能面是一张干净的 PlaneGeometry，网格自身 rotation.y = π（朝向 -Z），翻牌时
  // 整个 group 再转 π —— 两次相加是 2π，等于没转。所以平面正对相机、局部 +X 就是
  // 世界的 +X，贴图按原样显示才是对的。
  //
  // 这里来回翻了三次才对上，根因是当时复用了 frontGeo：那套 UV 被 applyRuicUv 预先
  // 反转 V 过，只对 RuiC 的 ShaderMaterial 成立。换成自己的平面之后，正确答案就是"别动它"。
  return t;
}
