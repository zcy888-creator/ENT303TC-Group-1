/**
 * 仪式殿堂 v3。
 *
 * ── 为什么推倒重来 ──────────────────────────────────────────────────────
 * v2 是在"看不见"的状态下做的：只能靠三角形数和帧时间推断，于是往一个空盒子里
 * 堆了几何体。等拿到视觉能力回头看，问题是灾难性的：
 *
 *   · 六座「火盆」半径 3.9、离相机太近，在画面上变成六个巨大的金碗配奶油球，
 *     占了 15% 屏幕，还挡在卡牌前面
 *   · 远景拱廊的顶端被裁掉，读成"天上飘着两块黑板"
 *   · 雾壳（半径 12-14 的圆柱）把整个背景涂成一片死紫 —— 那根本不是墙，
 *     是雾，所以柱子后面什么都没有
 *   · 柱子和拱是纯黑剪影：ambient 太弱、光都在地面附近，我做的砌缝、黄铜环、
 *     嵌刻贴图全部不可见
 *   · 悬链用 TubeGeometry 半径 0.018 渲染成一条虚线，像图形 bug
 *
 * ── v3 的做法 ───────────────────────────────────────────────────────────
 * 按 AAA 流水线的顺序：先形体，再材质，最后光。特效一律不加。
 *
 *   1. 把空间**封起来** —— 穹顶 + 拱肋。之前头顶是敞开的虚空，所以画面没有
 *      上边界，构不成"室内"。
 *   2. 柱式做对 —— 柱础、柱身分段凹槽、柱头、黄铜箍。比例按真实建筑来，
 *      直径 1.05、间距 5.78，柱高 9.5 → 约 9:1，哥特的比例。
 *   3. **删掉火盆**，改成柱子上的壁灯（y=4.2，小，暖，不抢镜）。
 *   4. **删掉雾壳**。纵深交给 FogExp2 和真实的几何层次。
 *   5. 光是主角：暖壁灯从下方洗柱子，冷月光从上方打下来形成明暗分割，
 *      再加一盏从背后打的轮廓光把柱子和背景分开。
 *   6. 地面对比度拉足，嵌刻才看得见。
 */
import * as THREE from "three";

const PILLARS = 12;          // 12 根，环廊更完整
const RING_R = 9.6;
const HALL_H = 9.5;
const VAULT_H = 4.2;         // 拱顶升起的高度

/* ========================================================== 材质库 ======== */

function makeMaterialLibrary() {
  const roles = {};
  const textures = [];

  /** 程序化石材：砌缝 + 错缝 + 斑驳 + 噪点。 */
  function stoneCanvas(base, { courses = 7, lineAlpha = 0.5, tint = null } = {}) {
    const S = 512;
    const c = document.createElement("canvas");
    c.width = c.height = S;
    const g = c.getContext("2d");
    g.fillStyle = base;
    g.fillRect(0, 0, S, S);

    // 斑驳
    for (let i = 0; i < 300; i++) {
      const a = 0.025 + Math.random() * 0.06;
      g.fillStyle = Math.random() < 0.5 ? `rgba(255,255,255,${a})` : `rgba(0,0,0,${a})`;
      g.fillRect(Math.random() * S, Math.random() * S, 16 + Math.random() * 80, 10 + Math.random() * 60);
    }
    // 噪点
    const img = g.getImageData(0, 0, S, S);
    for (let i = 0; i < img.data.length; i += 4) {
      const n = (Math.random() - 0.5) * 22;
      img.data[i] += n; img.data[i + 1] += n; img.data[i + 2] += n;
    }
    g.putImageData(img, 0, 0);

    // 砌缝 —— 石头最重要的形体线索
    const rowH = S / courses;
    g.strokeStyle = `rgba(0,0,0,${lineAlpha})`;
    for (let r = 0; r <= courses; r++) {
      const y = r * rowH;
      g.lineWidth = 2.2;
      g.beginPath(); g.moveTo(0, y); g.lineTo(S, y); g.stroke();
      const off = (r % 2) * rowH * 0.9;
      for (let x = off; x < S + rowH; x += rowH * 1.9) {
        g.beginPath(); g.moveTo(x, y); g.lineTo(x, y + rowH); g.stroke();
      }
    }
    // 上缘高光：每块砖顶一条亮线，这是天然石材受光的读法
    g.strokeStyle = "rgba(255,255,255,0.10)";
    g.lineWidth = 1.2;
    for (let r = 0; r <= courses; r++) {
      const y = r * rowH + 2.2;
      g.beginPath(); g.moveTo(0, y); g.lineTo(S, y); g.stroke();
    }

    if (tint) { g.fillStyle = tint; g.fillRect(0, 0, S, S); }

    const t = new THREE.CanvasTexture(c);
    t.wrapS = t.wrapT = THREE.RepeatWrapping;
    t.anisotropy = 8;
    t.colorSpace = THREE.SRGBColorSpace;
    textures.push(t);
    return t;
  }

  /** 地面嵌刻：同心环 + 放射刻度 + 七角星 + 符文。对比度拉足。 */
  function inlayCanvas() {
    const S = 2048;
    const c = document.createElement("canvas");
    c.width = c.height = S;
    const g = c.getContext("2d");
    const cx = S / 2, cy = S / 2;

    // 底：中灰石，不是黑色 —— 太暗的话所有嵌刻都看不见。
    // 这块贴图不做乘算（材质色是白的），所以底色就是最终反照率；朝上的面又同时吃到
    // 三盏方向光，本来就比墙面亮 3~4 倍，底色再亮就会把画面读成"一块发亮的盘子"。
    g.fillStyle = "#23232f";
    g.fillRect(0, 0, S, S);

    // 径向渐暗，给地面一个光池。
    // 最后一档必须压到接近全黑：以前收到 0.42，盘边在画面上留下一圈生硬的椭圆
    // 边界；收到 0.86 之后，地面边缘自然落进墙根的暗部里。
    const rg = g.createRadialGradient(cx, cy, 0, cx, cy, S * 0.5);
    rg.addColorStop(0, "rgba(150,150,190,0.14)");
    rg.addColorStop(0.42, "rgba(90,90,125,0.06)");
    rg.addColorStop(0.72, "rgba(0,0,0,0.34)");
    rg.addColorStop(1, "rgba(0,0,0,0.86)");
    g.fillStyle = rg;
    g.fillRect(0, 0, S, S);

    // 石材斑驳
    for (let i = 0; i < 2600; i++) {
      const a = Math.random() * 0.07;
      g.fillStyle = Math.random() < 0.5 ? `rgba(255,255,255,${a})` : `rgba(0,0,0,${a})`;
      g.beginPath();
      g.arc(Math.random() * S, Math.random() * S, 3 + Math.random() * 30, 0, 6.283);
      g.fill();
    }
    // 放射状铺砖缝
    g.strokeStyle = "rgba(0,0,0,0.30)";
    g.lineWidth = 3;
    for (let i = 0; i < 48; i++) {
      const a = (i / 48) * Math.PI * 2;
      g.beginPath();
      g.moveTo(cx + Math.cos(a) * S * 0.06, cy + Math.sin(a) * S * 0.06);
      g.lineTo(cx + Math.cos(a) * S * 0.52, cy + Math.sin(a) * S * 0.52);
      g.stroke();
    }
    for (let r = 1; r <= 9; r++) {
      g.beginPath();
      g.arc(cx, cy, (r / 9) * S * 0.5, 0, 6.283);
      g.lineWidth = 3;
      g.stroke();
    }

    const ring = (rr, w, col) => {
      g.beginPath(); g.arc(cx, cy, rr * S * 0.5, 0, 6.283);
      g.strokeStyle = col; g.lineWidth = w; g.stroke();
    };
    // 主体环
    ring(0.20, 10, "rgba(226,196,120,0.85)");
    ring(0.26, 5, "rgba(170,150,230,0.60)");
    ring(0.42, 14, "rgba(226,196,120,0.90)");
    ring(0.47, 6, "rgba(170,150,230,0.55)");
    ring(0.66, 8, "rgba(200,180,120,0.55)");
    ring(0.88, 5, "rgba(150,140,200,0.40)");

    // 放射刻度：96 道，每 8 道加长描金
    for (let i = 0; i < 96; i++) {
      const a = (i / 96) * Math.PI * 2;
      const long = i % 8 === 0;
      const r0 = 0.42 * S * 0.5;
      const r1 = r0 + (long ? 0.075 : 0.036) * S;
      g.beginPath();
      g.moveTo(cx + Math.cos(a) * r0, cy + Math.sin(a) * r0);
      g.lineTo(cx + Math.cos(a) * r1, cy + Math.sin(a) * r1);
      g.strokeStyle = long ? "rgba(232,200,120,0.95)" : "rgba(160,150,210,0.55)";
      g.lineWidth = long ? 11 : 5;
      g.stroke();
    }

    // 内圈七角星
    const R = 0.20 * S * 0.5;
    const pts = [];
    for (let i = 0; i < 7; i++) {
      const a = -Math.PI / 2 + (2 * Math.PI * i) / 7;
      pts.push([cx + R * Math.cos(a), cy + R * Math.sin(a)]);
    }
    g.strokeStyle = "rgba(200,180,255,0.75)";
    g.lineWidth = 5;
    for (let i = 0; i < 7; i++) {
      const a = pts[i], b = pts[(i + 3) % 7];
      g.beginPath(); g.moveTo(a[0], a[1]); g.lineTo(b[0], b[1]); g.stroke();
    }
    for (const [x, y] of pts) {
      g.beginPath(); g.arc(x, y, 14, 0, 6.283);
      g.fillStyle = "rgba(255,235,180,0.95)"; g.fill();
    }
    // 再套一个大的七角星落在 0.88 环上，把构图放大
    const R2 = 0.66 * S * 0.5;
    const p2 = [];
    for (let i = 0; i < 7; i++) {
      const a = -Math.PI / 2 + (2 * Math.PI * i) / 7;
      p2.push([cx + R2 * Math.cos(a), cy + R2 * Math.sin(a)]);
    }
    g.strokeStyle = "rgba(190,170,240,0.45)";
    g.lineWidth = 4;
    for (let i = 0; i < 7; i++) {
      const a = p2[i], b = p2[(i + 3) % 7];
      g.beginPath(); g.moveTo(a[0], a[1]); g.lineTo(b[0], b[1]); g.stroke();
    }

    const t = new THREE.CanvasTexture(c);
    t.anisotropy = 16;
    t.colorSpace = THREE.SRGBColorSpace;
    textures.push(t);
    return t;
  }

  const floorTex = inlayCanvas();

  /** 地面粗糙度：让盘面有干湿/磨损的层次，而不是一块均匀的塑料。 */
  function floorRoughCanvas() {
    const S = 256;
    const c = document.createElement("canvas");
    c.width = c.height = S;
    const g = c.getContext("2d");
    g.fillStyle = "#c8c8c8";
    g.fillRect(0, 0, S, S);
    for (let i = 0; i < 900; i++) {
      const v = 150 + Math.random() * 105;
      g.fillStyle = `rgba(${v},${v},${v},${0.25 + Math.random() * 0.5})`;
      g.beginPath();
      g.arc(Math.random() * S, Math.random() * S, 6 + Math.random() * 46, 0, 6.283);
      g.fill();
    }
    const t = new THREE.CanvasTexture(c);
    t.wrapS = t.wrapT = THREE.RepeatWrapping;
    textures.push(t);
    return t;
  }

  /**
   * 高窗玻璃。
   *
   * 一块平涂的自发光矩形挂在高处，看起来就是"贴图漏了一块"。真正的花窗是**透射**
   * 的东西：上亮下暗（天光从上方来，下面是墙和地面的遮挡），被铅条分成许多小格，
   * 每格因为玻璃厚度不匀而亮度略有不同，外圈还要压暗一圈当窗洞的阴影。
   *
   * 用 MeshBasicMaterial 贴它，因为它本来就不该参与场景光照 —— 我们看到的是透过来的
   * 光，不是被照亮的表面。
   */
  function glassCanvas() {
    const W = 128, H = 384;
    const c = document.createElement("canvas");
    c.width = W; c.height = H;
    const g = c.getContext("2d");

    // 玻璃必须画成**中调饱和蓝**，不能画成接近白的浅色。
    //
    // 后期用的是 ToneMappingMode.NEUTRAL：它会压缩高光并往白里推，所以 #f4f8ff
    // 这种颜色出来只能是一块脏灰 —— 第一版就是这样，4 倍放大后看得清清楚楚。
    // 想要"月光透过蓝玻璃"，就得在贴图里先给足饱和度。
    const lg = g.createLinearGradient(0, 0, 0, H);
    lg.addColorStop(0, "#bcd4ff");
    lg.addColorStop(0.28, "#8fb2f5");
    lg.addColorStop(0.60, "#5f86dd");
    lg.addColorStop(1, "#3f5da8");
    g.fillStyle = lg;
    g.fillRect(0, 0, W, H);

    // 每格玻璃的亮度差
    for (let i = 0; i < 110; i++) {
      const x = Math.random() * W, y = Math.random() * H;
      const r = 6 + Math.random() * 22;
      const warm = Math.random() < 0.22;
      const rg = g.createRadialGradient(x, y, 0, x, y, r);
      const a = 0.05 + Math.random() * 0.14;
      rg.addColorStop(0, warm ? `rgba(255,232,196,${a})` : `rgba(255,255,255,${a})`);
      rg.addColorStop(1, "rgba(255,255,255,0)");
      g.fillStyle = rg;
      g.beginPath(); g.arc(x, y, r, 0, 6.283); g.fill();
    }

    // 菱形铅条。这一层是"花窗"读得出来的关键，比任何渐变都重要。
    g.strokeStyle = "rgba(13,17,36,0.58)";
    g.lineWidth = 1.7;
    const step = 26;
    for (let k = -H; k < W + H; k += step) {
      g.beginPath(); g.moveTo(k, 0); g.lineTo(k + H, H); g.stroke();
      g.beginPath(); g.moveTo(k, 0); g.lineTo(k - H, H); g.stroke();
    }
    // 铅条本身的高光：一条极细的亮线贴在暗线一侧，金属才有厚度
    g.strokeStyle = "rgba(226,232,255,0.16)";
    g.lineWidth = 0.8;
    for (let k = -H; k < W + H; k += step) {
      g.beginPath(); g.moveTo(k + 1.4, 0); g.lineTo(k + H + 1.4, H); g.stroke();
    }

    // 窗洞阴影：外圈压暗
    const vg = g.createRadialGradient(W / 2, H / 2, 0, W / 2, H / 2, H * 0.62);
    vg.addColorStop(0, "rgba(0,0,0,0)");
    vg.addColorStop(0.62, "rgba(8,12,28,0.10)");
    vg.addColorStop(1, "rgba(8,12,28,0.62)");
    g.fillStyle = vg;
    g.fillRect(0, 0, W, H);

    const t = new THREE.CanvasTexture(c);
    t.colorSpace = THREE.SRGBColorSpace;
    t.anisotropy = 8;
    textures.push(t);
    return t;
  }


  /**
   * 高窗洒在窗洞上的冷光晕。
   *
   * 一块亮的玻璃不等于"有光进来"。真正让窗户成立的是它把光**洒在周围的石头上** ——
   * 窗洞内壁比别处亮一档，窗口外圈有一层晕。加法混合，亮度写在 RGB 里。
   */
  function haloCanvas() {
    const S = 128;
    const c = document.createElement("canvas");
    c.width = c.height = S;
    const g = c.getContext("2d");
    const rg = g.createRadialGradient(S / 2, S / 2, 0, S / 2, S / 2, S / 2);
    rg.addColorStop(0, "rgba(198,222,255,0.50)");
    rg.addColorStop(0.42, "rgba(146,180,255,0.19)");
    rg.addColorStop(0.72, "rgba(120,152,232,0.05)");
    rg.addColorStop(1, "rgba(110,140,225,0)");
    g.fillStyle = rg;
    g.fillRect(0, 0, S, S);
    const t = new THREE.CanvasTexture(c);
    t.colorSpace = THREE.SRGBColorSpace;
    textures.push(t);
    return t;
  }

  /** 远处烛火的光晕：加法混合用，所以亮度写在 RGB 里，alpha 不参与。 */
  function glowCanvas() {
    const S = 128;
    const c = document.createElement("canvas");
    c.width = c.height = S;
    const g = c.getContext("2d");
    const rg = g.createRadialGradient(S / 2, S / 2, 0, S / 2, S / 2, S / 2);
    rg.addColorStop(0, "rgba(255,225,180,0.95)");
    rg.addColorStop(0.22, "rgba(255,186,112,0.42)");
    rg.addColorStop(0.55, "rgba(240,140,70,0.10)");
    rg.addColorStop(1, "rgba(220,120,60,0)");
    g.fillStyle = rg;
    g.fillRect(0, 0, S, S);
    const t = new THREE.CanvasTexture(c);
    t.colorSpace = THREE.SRGBColorSpace;
    textures.push(t);
    return t;
  }

  // 石材贴图的底色必须接近中灰。
  //
  // 这些 canvas 是当作**乘算贴图**用的：最终反照率 = 贴图 × material.color。
  // 原来的底色（#4a4b63 / #525470 / #3c3d52）本身就很暗，再乘一遍材质色，得到的
  // 线性反照率只有 0.014~0.087；而没有贴图的远景石材是 0.18~0.32 —— 差了 7~13 倍。
  // 这就是"远拱白得像围栏、外墙黑得像没有"的全部原因，跟打光没关系。
  // 把底色提到中灰之后，材质色才真正控制得住色调。
  const wallTex = stoneCanvas("#a8aabd", { courses: 8 }); wallTex.repeat.set(4, 2);
  const pillarTex = stoneCanvas("#b0b2c6", { courses: 10, lineAlpha: 0.42 }); pillarTex.repeat.set(1, 4);
  const vaultTex = stoneCanvas("#8e90a6", { courses: 10, lineAlpha: 0.55 }); vaultTex.repeat.set(6, 2);

  // 地面：接收光最多，嵌刻要读得出来。
  //
  // 但"读得出来"曾经被做成了"把地面调到最亮"。实测盘面中心 #445090（亮度 84），
  // 而整个背景只有 3~21 —— 画面读成"黑箱子里一块发蓝的盘子"。
  //
  // 探针还纠正了一个误判：那圈亮盘的边界不是嵌刻贴图的渐晕（相机只看得见半径
  // 34 的盘面里靠内的约 30%，边缘渐晕根本不在画面里），而是地脚点光源的 1/d²
  // 热点。所以真正要动的是灯，不是贴图 —— 贴图这边只把底色压下来、把粗糙度
  // 打成不均匀，让它像一块被磨过的石头而不是塑料。
  roles.floorStone = new THREE.MeshStandardMaterial({
    color: 0xffffff, map: floorTex, roughnessMap: floorRoughCanvas(),
    roughness: 0.86, metalness: 0.10,
  });
  // 墙面 / 拱
  roles.wallStone = new THREE.MeshStandardMaterial({
    color: 0x8f93b4, map: wallTex, roughness: 0.93, metalness: 0.05,
  });
  // 外围承重墙：从里面看。
  //
  // 注意这里必须是 DoubleSide，不能图省事写成 BackSide。three 只在 DOUBLE_SIDED
  // 时才对背面翻转法线；BackSide 会把背面画出来但仍用**朝外**的法线去算光照，
  // 于是内表面被背后的光"照亮"、被相机这一侧的光判成 NdotL<0。实测后果就是这面
  // 墙的亮度只有 2~9，而它前面那圈远拱是接近白的 —— 背景重新变回一块黑。
  roles.wallInner = new THREE.MeshStandardMaterial({
    color: 0x7c81a6, map: wallTex.clone(), roughness: 0.94, metalness: 0.04,
    side: THREE.DoubleSide,
  });
  roles.wallInner.map.repeat.set(29, 4);
  roles.wallInner.map.needsUpdate = true;
  textures.push(roles.wallInner.map);
  // 柱身
  roles.pillarStone = new THREE.MeshStandardMaterial({
    color: 0x9aa0c2, map: pillarTex, roughness: 0.84, metalness: 0.06,
  });
  // 穹顶：同一个道理，背面渲染 + 翻转法线，室内朝下的面才会吃到地脚光和烛光
  roles.vaultStone = new THREE.MeshStandardMaterial({
    color: 0x6a6e8e, map: vaultTex, roughness: 0.95, metalness: 0.03,
    side: THREE.DoubleSide,
  });
  // 暗部 / 远景
  roles.darkStone = new THREE.MeshStandardMaterial({
    color: 0x4a4d66, roughness: 0.97, metalness: 0.03,
  });
  /**
   * 远景回廊的石材。
   *
   * 这里原本用的是 darkStone（0x4a4d66），再叠上 66% 的雾 —— 结果就是背景里那
   * 20 根纯黑方块，看起来像渲染 bug 而不是建筑。远石要的是"在暗处依然读得出是
   * 石头"，所以提亮一个档，并且给一点暖色自发光，模拟回廊里烛火的漫反射。
   */
  roles.farStone = new THREE.MeshStandardMaterial({
    color: 0x606582, roughness: 0.92, metalness: 0.05,
    emissive: 0x140d05, emissiveIntensity: 1,
  });
  // 高窗玻璃：透射光，不参与场景光照。
  //
  // 之前这里是一块 emissive 的平面 —— 结果是"一块发亮的长方形"，因为自发光在
  // 任何角度都是同一个颜色。真正的窗是有图案、有明暗、外圈被窗洞压暗的。
  roles.windowGlass = new THREE.MeshBasicMaterial({
    map: glassCanvas(), side: THREE.DoubleSide,
  });
  // 窗洞内壁：比墙亮一档的修凿石。窗框如果不是更亮的石头，窗就只是一张贴纸。
  roles.jambStone = new THREE.MeshStandardMaterial({
    color: 0xc2c6dc, map: wallTex.clone(), roughness: 0.88, metalness: 0.05,
  });
  roles.jambStone.map.repeat.set(2, 3);
  roles.jambStone.map.needsUpdate = true;
  textures.push(roles.jambStone.map);
  // 窗口外圈的冷光晕
  roles.windowHalo = new THREE.MeshBasicMaterial({
    map: haloCanvas(), transparent: true, blending: THREE.AdditiveBlending,
    depthWrite: false, side: THREE.DoubleSide,
  });
  // 墙上的线脚
  roles.moulding = new THREE.MeshStandardMaterial({
    color: 0x9aa0c4, roughness: 0.90, metalness: 0.05, side: THREE.DoubleSide,
  });
  // 远处烛火的光晕
  //
  // size 是**世界单位**：在 15.6 米处，size 2.6 会铺开近 10°，是 150 像素的
  // 大光斑；这里要的是每根远柱上一点烛火，所以收到 1.2，颜色也压暗一档 ——
  // 亮到一定程度就会被 bloom 抓住，再被色差拆成粉色，看起来像渲染错误。
  roles.glow = new THREE.PointsMaterial({
    map: glowCanvas(), size: 1.2, sizeAttenuation: true, transparent: true,
    blending: THREE.AdditiveBlending, depthWrite: false, color: 0xc98a52,
  });
  // 黄铜 trim —— 与石材形成材质对比（评分卡：contrast before post effects）
  roles.brass = new THREE.MeshStandardMaterial({
    color: 0xd8ad52, roughness: 0.28, metalness: 0.95,
    emissive: 0x3a2608, emissiveIntensity: 1,
  });
  roles.brassDark = new THREE.MeshStandardMaterial({
    color: 0x8a6d2e, roughness: 0.45, metalness: 0.85,
  });
  // 发光信号
  roles.signal = new THREE.MeshStandardMaterial({
    color: 0x201a30, roughness: 0.4, metalness: 0.3,
    emissive: 0x9b7fe0, emissiveIntensity: 1.6,
  });
  /**
   * 基座顶面的磨光石。
   *
   * 这一块以前就是台阶本身的 wallStone：朝上的面同时吃到三盏方向光（月光 NdotL
   * 0.84 + 补光 0.50 + 轮廓光 0.61），比任何一个竖直面都亮好几倍，于是半径 4.16
   * 的基座顶在画面里变成下半屏一块又亮又平的灰盘子。
   *
   * 换成低粗糙度 + 较高金属度的深色石之后，它靠高光而不是漫反射去读，法阵的金环
   * 和魔法阵也才有对比可言。
   */
  roles.daisStone = new THREE.MeshStandardMaterial({
    color: 0x272a3c, roughness: 0.42, metalness: 0.20,
  });

  return { roles, textures };
}

/* ========================================================== 几何工具 ====== */

function gothicArchShape(span, height, thickness) {
  const s = new THREE.Shape();
  const half = span / 2;
  const springY = height - half * 1.35;
  s.moveTo(-half, 0);
  s.lineTo(-half, springY);
  s.quadraticCurveTo(-half, height - half * 0.12, 0, height);
  s.quadraticCurveTo(half, height - half * 0.12, half, springY);
  s.lineTo(half, 0);
  s.lineTo(half - thickness, 0);
  s.lineTo(half - thickness, springY);
  s.quadraticCurveTo(half - thickness, height - half * 0.12 - thickness * 0.5,
                     0, height - thickness * 1.15);
  s.quadraticCurveTo(-half + thickness, height - half * 0.12 - thickness * 0.5,
                     -half + thickness, springY);
  s.lineTo(-half + thickness, 0);
  s.closePath();
  return s;
}

/**
 * 实心的尖拱轮廓（不是"拱带"）。
 *
 * gothicArchShape 画的是一个有厚度的拱**框**；高窗要的是一整块拱形的玻璃，
 * 所以需要一个从底边闭合到尖顶的实心面。ShapeGeometry 直接吃它。
 */
function gothicArchFill(span, height) {
  const s = new THREE.Shape();
  const half = span / 2;
  const springY = height - half * 1.35;
  s.moveTo(-half, 0);
  s.lineTo(-half, springY);
  s.quadraticCurveTo(-half, height - half * 0.12, 0, height);
  s.quadraticCurveTo(half, height - half * 0.12, half, springY);
  s.lineTo(half, 0);
  s.closePath();
  return s;
}

/**
 * 把一圈相同的构件收成**一个** InstancedMesh。
 *
 * 环廊的每一根柱子都由同一组构件组成，区别只是绕 Y 转过的角度 —— 这正是
 * InstancedMesh 存在的理由。这里按"第 i 个构件在第 i/n 圈上"的约定摆放。
 */
function ringOf(group, geo, mat, n, y, opts = {}) {
  const { flat = false, offset = 0, radius, shadow = true } = opts;
  const im = new THREE.InstancedMesh(geo, mat, n);
  im.instanceMatrix.setUsage(THREE.StaticDrawUsage);
  im.castShadow = shadow; im.receiveShadow = shadow;
  const m4 = new THREE.Matrix4(), q = new THREE.Quaternion();
  const e = new THREE.Euler(), one = new THREE.Vector3(1, 1, 1);
  for (let i = 0; i < n; i++) {
    const a = (i / n) * Math.PI * 2 + offset;
    e.set(flat ? Math.PI / 2 : 0, 0, 0);
    q.setFromEuler(e);
    m4.compose(new THREE.Vector3(Math.cos(a) * radius, y, Math.sin(a) * radius), q, one);
    im.setMatrixAt(i, m4);
  }
  im.instanceMatrix.needsUpdate = true;
  group.add(im);
  return im;
}

/* ============================================================ 建造 ======== */

export function buildTemple(scene) {
  const group = new THREE.Group();
  group.name = "temple";
  scene.add(group);

  const lib = makeMaterialLibrary();
  const M = lib.roles;

  const m4 = new THREE.Matrix4();
  const q = new THREE.Quaternion();
  const e = new THREE.Euler();
  const one = new THREE.Vector3(1, 1, 1);
  let lightShaft = null;

  /* --- 地面：嵌刻盘 ------------------------------------------------ */
  const floor = new THREE.Mesh(new THREE.CircleGeometry(34, 128), M.floorStone);
  floor.rotation.x = -Math.PI / 2;
  floor.position.y = 0;
  floor.receiveShadow = true;
  group.add(floor);

  /* --- 中央基座：三层 + 磨光顶面 + 铜嵌环 ---------------------------- */
  for (let i = 0; i < 3; i++) {
    const r = 5.0 - i * 0.42;
    const step = new THREE.Mesh(
      new THREE.CylinderGeometry(r, r + 0.20, 0.15, 84),
      i === 2 ? M.darkStone : M.wallStone
    );
    step.position.y = 0.075 + i * 0.15;
    step.receiveShadow = true;
    step.castShadow = true;
    group.add(step);
  }
  // 磨光顶面。也顺手解决了魔法阵消失的问题：魔法阵原来放在 y=0.365，而第三级
  // 台阶占的是 y=0.30~0.45、半径到 4.16 —— 半径 4.1 的法阵整个埋在自己的基座里，
  // 被深度测试剔掉了。"按下召唤时法阵亮起"这件事其实一直没有真正发生过。
  const topPlate = new THREE.Mesh(new THREE.CylinderGeometry(4.14, 4.14, 0.03, 84), M.daisStone);
  topPlate.position.y = 0.465;
  topPlate.receiveShadow = true;
  group.add(topPlate);

  const trim = new THREE.Mesh(new THREE.TorusGeometry(5.05, 0.03, 8, 120), M.brass);
  trim.rotation.x = Math.PI / 2;
  trim.position.y = 0.16;
  group.add(trim);
  const trimTop = new THREE.Mesh(new THREE.TorusGeometry(4.15, 0.022, 8, 120), M.brass);
  trimTop.rotation.x = Math.PI / 2;
  trimTop.position.y = 0.482;
  group.add(trimTop);

  /* --- 符文信号条 ---------------------------------------------------- */
  const signals = [];
  for (let i = 0; i < 4; i++) {
    const a = (i / 4) * Math.PI * 2 + Math.PI / 4;
    const bar = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.025, 2.4), M.signal.clone());
    bar.position.set(Math.cos(a) * 6.6, 0.02, Math.sin(a) * 6.6);
    bar.rotation.y = -a;
    group.add(bar);
    signals.push(bar.material);
  }

  /* --- 环形柱廊：12 根完整柱式，整体实例化 -----------------------------
   *
   * 这一圈原本是 12 根柱子 × 19 个网格 = 228 个 draw call，占整座殿堂 302 个
   * 网格里的 75%，阴影 pass 还要把同样的数量再画一遍。而每根柱子的构件完全
   * 相同、只是绕 Y 转了 30°。
   *
   * 收成实例之后：柱础/柱靴/柱身/柱头/顶板 5 个 + 铜箍 1 个 + 凹槽 1 个 = 7 个。
   */
  const COL_R = 0.52, COL_H = HALL_H;
  {
    const parts = [
      [new THREE.BoxGeometry(COL_R * 2.5, 0.30, COL_R * 2.5), M.wallStone, 0.15],
      [new THREE.CylinderGeometry(COL_R * 1.35, COL_R * 1.55, 0.34, 20), M.pillarStone, 0.47],
      [new THREE.CylinderGeometry(COL_R, COL_R * 1.06, COL_H, 20, 1), M.pillarStone, COL_H / 2 + 0.64],
      [new THREE.CylinderGeometry(COL_R * 1.5, COL_R * 1.05, 0.34, 20), M.pillarStone, COL_H + 0.81],
      [new THREE.BoxGeometry(COL_R * 3.0, 0.26, COL_R * 3.0), M.wallStone, COL_H + 1.11],
    ];
    for (const [geo, mat, y] of parts) ringOf(group, geo, mat, PILLARS, y, { radius: RING_R });

    // 黄铜箍：每根两根，平放
    const rings = new THREE.InstancedMesh(
      new THREE.TorusGeometry(COL_R * 1.045, COL_R * 0.055, 8, 28), M.brass, PILLARS * 2);
    rings.instanceMatrix.setUsage(THREE.StaticDrawUsage);
    for (let i = 0; i < PILLARS; i++) {
      const a = (i / PILLARS) * Math.PI * 2;
      for (let k = 0; k < 2; k++) {
        e.set(Math.PI / 2, 0, 0); q.setFromEuler(e);
        m4.compose(new THREE.Vector3(
          Math.cos(a) * RING_R, 0.9 + k * (COL_H - 0.7), Math.sin(a) * RING_R), q, one);
        rings.setMatrixAt(i * 2 + k, m4);
      }
    }
    rings.instanceMatrix.needsUpdate = true;
    group.add(rings);

    // 凹槽：12 根 × 12 道 = 144 个实例。薄贴合片，投影没有意义，关掉。
    const FL = 12;
    const flutes = new THREE.InstancedMesh(
      new THREE.BoxGeometry(COL_R * 0.20, COL_H * 0.92, COL_R * 0.06), M.darkStone, PILLARS * FL);
    flutes.instanceMatrix.setUsage(THREE.StaticDrawUsage);
    flutes.castShadow = false;
    flutes.receiveShadow = true;
    for (let i = 0; i < PILLARS; i++) {
      const a = (i / PILLARS) * Math.PI * 2;
      const ca = Math.cos(a), sa = Math.sin(a);
      for (let f = 0; f < FL; f++) {
        const fa = (f / FL) * Math.PI * 2;
        const lx = Math.cos(fa) * COL_R * 0.96, lz = Math.sin(fa) * COL_R * 0.96;
        // 柱身自己的旋转 Ry(-a) 作用在局部偏移上，再叠加到柱心的世界坐标
        e.set(0, -a - fa, 0); q.setFromEuler(e);
        m4.compose(new THREE.Vector3(
          ca * RING_R + lx * ca - lz * sa,
          COL_H / 2 + 0.64,
          sa * RING_R + lx * sa + lz * ca,
        ), q, one);
        flutes.setMatrixAt(i * FL + f, m4);
      }
    }
    flutes.instanceMatrix.needsUpdate = true;
    group.add(flutes);
  }

  /* --- 拱廊：柱间尖拱 ------------------------------------------------- */
  const span = 2 * RING_R * Math.sin(Math.PI / PILLARS);
  const archGeo = new THREE.ExtrudeGeometry(gothicArchShape(span - 0.1, 5.2, 0.5), {
    depth: 0.62, bevelEnabled: false, curveSegments: 12,
  });
  archGeo.translate(0, 0, -0.31);
  const arches = new THREE.InstancedMesh(archGeo, M.wallStone, PILLARS);
  arches.castShadow = true; arches.receiveShadow = true;
  for (let i = 0; i < PILLARS; i++) {
    const a = ((i + 0.5) / PILLARS) * Math.PI * 2;
    e.set(0, -a + Math.PI / 2, 0); q.setFromEuler(e);
    m4.compose(new THREE.Vector3(Math.cos(a) * RING_R, HALL_H - 4.4, Math.sin(a) * RING_R), q, one);
    arches.setMatrixAt(i, m4);
  }
  group.add(arches);

  /* --- 穹顶：把空间封起来 --------------------------------------------- */
  // 之前头顶是敞开的虚空，画面没有上边界，构不成"室内"。半球 + 拱肋。
  const vault = new THREE.Mesh(
    new THREE.SphereGeometry(RING_R + 0.4, 48, 24, 0, Math.PI * 2, 0, Math.PI * 0.42),
    M.vaultStone
  );
  vault.position.y = HALL_H - 1.2;
  vault.scale.y = VAULT_H / (RING_R * 0.42);
  group.add(vault);

  // 穹顶拱肋：从每根柱子顶上收拢到中心的一圈肋
  //
  // 12 根肋是同一条曲线绕 Y 转 30° 的复制，所以只建一条几何、实例化 12 份。
  // 原来每根一个 TubeGeometry：12 个 draw call + 12 份顶点数据。
  {
    const pts = [];
    for (let k = 0; k <= 6; k++) {
      const t = k / 6;
      const r = RING_R * (1 - t * 0.98);
      pts.push(new THREE.Vector3(
        r,
        HALL_H - 0.6 + Math.sin(t * Math.PI * 0.5) * VAULT_H * 0.62,
        0,
      ));
    }
    const ribGeo = new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 20, 0.10, 6, false);
    const ribs = new THREE.InstancedMesh(ribGeo, M.pillarStone, PILLARS);
    ribs.castShadow = true;
    for (let i = 0; i < PILLARS; i++) {
      // Ry(-a) 把 (+r, y, 0) 送到 (r cos a, y, r sin a)，正是原来逐条算出来的位置
      const a = (i / PILLARS) * Math.PI * 2;
      e.set(0, -a, 0); q.setFromEuler(e);
      m4.compose(new THREE.Vector3(0, 0, 0), q, one);
      ribs.setMatrixAt(i, m4);
    }
    ribs.instanceMatrix.needsUpdate = true;
    group.add(ribs);
  }
  // 肋交点处的铜环
  const hub = new THREE.Mesh(new THREE.TorusGeometry(1.5, 0.10, 8, 40), M.brass);
  hub.rotation.x = Math.PI / 2;
  hub.position.y = HALL_H + VAULT_H * 0.60;
  group.add(hub);
  const hubCore = new THREE.Mesh(new THREE.SphereGeometry(0.42, 20, 14), M.signal.clone());
  hubCore.position.y = HALL_H + VAULT_H * 0.60;
  group.add(hubCore);

  /* --- 第二重回廊 + 外围承重墙 ----------------------------------------
   *
   * 这里原来是 20 根 darkStone 圆柱加一圈圆筒，放在半径 20.5。两个叠加的错误：
   * 材质是最暗的一档，而雾在 20 米处已经吃掉 66% —— 于是画面上出现那些纯黑方块。
   * 更糟的是头顶：穹顶(半径 10)的檐口高度约 10.9，而相机在 FOV 48 下的上边界
   * 在任何方向都远高于它，所以拱顶其实基本不在画面里，上方那一大片是**什么都没有**
   * 的雾底 —— 像素实测 #050011~#1d0b34，亮度 3~21，这就是"平墙"的真相。
   *
   * 所以纵深按真实的层次重排，并且把空间真正封起来：
   *
   *   近柱廊 9.6  →  远柱廊 15.6 + 远拱  →  线脚  →  高墙 18.6 (到 y=16)
   *
   * 墙高 16 是量出来的：画面背中央的上边界在墙处约 y=12.8，四角约 14.1。
   */
  const FAR_N = 24;            // 远柱根数
  const FAR_R = 15.6;
  const FAR_H = 8.6;
  const WALL_R = 18.6;
  const WALL_H = 16;

  const farParts = [
    // [几何, 材质, 中心高度, 是否平放]
    [new THREE.CylinderGeometry(0.40, 0.46, FAR_H, 12), M.farStone, 0.26 + FAR_H / 2, false],
    [new THREE.CylinderGeometry(0.62, 0.44, 0.34, 12), M.farStone, 0.26 + FAR_H + 0.17, false],
    [new THREE.BoxGeometry(1.18, 0.22, 1.18), M.farStone, 0.26 + FAR_H + 0.45, false],
    [new THREE.BoxGeometry(1.05, 0.26, 1.05), M.farStone, 0.13, false],
    [new THREE.TorusGeometry(0.45, 0.028, 6, 18), M.brass, 0.26 + FAR_H * 0.34, true],
  ];
  for (const [geo, mat, py, flat] of farParts) {
    const im = new THREE.InstancedMesh(geo, mat, FAR_N);
    im.instanceMatrix.setUsage(THREE.StaticDrawUsage);
    for (let i = 0; i < FAR_N; i++) {
      const a = (i / FAR_N) * Math.PI * 2 + 0.15;
      e.set(flat ? Math.PI / 2 : 0, 0, 0);
      q.setFromEuler(e);
      m4.compose(new THREE.Vector3(Math.cos(a) * FAR_R, py, Math.sin(a) * FAR_R), q, one);
      im.setMatrixAt(i, m4);
    }
    im.instanceMatrix.needsUpdate = true;
    group.add(im);
  }

  // 远拱：与近柱廊同一套尖拱，跨在远柱之间。没有它，远柱就只是"一排柱子"，
  // 加上它才读得出是一条回廊。
  const farSpan = 2 * FAR_R * Math.sin(Math.PI / FAR_N);
  const farArchGeo = new THREE.ExtrudeGeometry(gothicArchShape(farSpan - 0.08, 4.4, 0.34), {
    depth: 0.42, bevelEnabled: false, curveSegments: 10,
  });
  farArchGeo.translate(0, 0, -0.21);
  const farArches = new THREE.InstancedMesh(farArchGeo, M.farStone, FAR_N);
  farArches.castShadow = true; farArches.receiveShadow = true;
  for (let i = 0; i < FAR_N; i++) {
    const a = ((i + 0.5) / FAR_N) * Math.PI * 2 + 0.15;
    e.set(0, -a + Math.PI / 2, 0); q.setFromEuler(e);
    m4.compose(new THREE.Vector3(Math.cos(a) * FAR_R, 4.7, Math.sin(a) * FAR_R), q, one);
    farArches.setMatrixAt(i, m4);
  }
  farArches.instanceMatrix.needsUpdate = true;
  group.add(farArches);

  // 外围承重墙：把空间真正封上。没有它，上方永远是雾底。
  const wall = new THREE.Mesh(
    new THREE.CylinderGeometry(WALL_R, WALL_R, WALL_H, 96, 1, true),
    M.wallInner
  );
  wall.position.y = WALL_H / 2;
  group.add(wall);

  // 墙上的线脚：一条裙线、一条檐线。它们的作用是给这面墙一个尺度参照 ——
  // 没有线脚的墙无论多高都是一块布。
  for (const [ry, tube] of [[0.62, 0.16], [8.6, 0.22]]) {
    const band = new THREE.Mesh(
      new THREE.CylinderGeometry(WALL_R - 0.10, WALL_R - 0.10, tube, 96, 1, true),
      M.moulding
    );
    band.position.y = ry;
    group.add(band);
  }

  // 高窗：冷光。全场只有一个色相时，冷暖对冲就靠这一排窗。
  //
  // 位置要算，不能随手写：
  //   · 半径方向要对在**拱洞**里，所以要错开半格（i+0.5），跟远拱对齐而不是跟
  //     远柱对齐 —— 对齐柱子的话每扇窗都正好被一根柱子挡死。
  //   · 高度要对在画面里。y=10.3 换算到相机的仰角是 18.2°，而画面上边界是 20.1°，
  //     于是整排窗只露出最上面几个像素，等于不存在。7.6 对应画面 y≈0.15。
  //
  // 构成（每扇窗，各一个 InstancedMesh，共 +4 个 draw call）：
  //   玻璃  拱形，带铅条格与上亮下暗的透射渐变
  //   窗洞  拱形石框，从墙面往厅内凹进 0.55 —— 有厚度才像窗，没厚度像贴纸
  //   窗棂  一竖两横，用比墙更暗的石材，这样才会在亮玻璃前**剪影**
  //   窗台  底下一条石台
  const WIN_SILL = 6.0, WIN_SPAN = 1.0, WIN_H = 2.9;
  const REVEAL = 0.55;
  {
    const lightGeo = new THREE.ShapeGeometry(gothicArchFill(WIN_SPAN, WIN_H), 14);
    // ShapeGeometry 的 uv 直接取的是形状的二维坐标（x 可能是 -0.5，y 到 2.9），
    // 不在 0..1 里 —— 不重映射的话贴图会平铺错位。这里按窗的实际尺寸归一化。
    {
      const uv = lightGeo.attributes.uv, pos = lightGeo.attributes.position;
      for (let i = 0; i < uv.count; i++) {
        uv.setXY(i, (pos.getX(i) + WIN_SPAN / 2) / WIN_SPAN, pos.getY(i) / WIN_H);
      }
      uv.needsUpdate = true;
    }
    const windows = new THREE.InstancedMesh(lightGeo, M.windowGlass, FAR_N);

    // 窗洞：拱带沿局部 +z 挤出，而实例旋转把 +z 指向厅内，所以从墙面往里凹。
    const revealGeo = new THREE.ExtrudeGeometry(
      gothicArchShape(WIN_SPAN + 0.40, WIN_H + 0.26, 0.20),
      { depth: REVEAL, bevelEnabled: false, curveSegments: 12 });
    const reveals = new THREE.InstancedMesh(revealGeo, M.jambStone, FAR_N);

    // 光晕：贴在窗洞内口，比窗本身大一圈，加法混合
    const halos = new THREE.InstancedMesh(
      new THREE.PlaneGeometry(WIN_SPAN + 1.5, WIN_H + 1.7), M.windowHalo, FAR_N);

    const mullV = new THREE.InstancedMesh(
      new THREE.BoxGeometry(0.075, WIN_H * 0.80, 0.10), M.darkStone, FAR_N);
    const mullH = new THREE.InstancedMesh(
      new THREE.BoxGeometry(WIN_SPAN * 0.96, 0.07, 0.10), M.darkStone, FAR_N * 2);
    const sills = new THREE.InstancedMesh(
      new THREE.BoxGeometry(WIN_SPAN + 0.62, 0.15, REVEAL + 0.28), M.moulding, FAR_N);
    // 拱头里的圆洞花窗（oculus）。这是哥特窗最容易被认出来的一个特征：
    // 尖拱的顶部不是空玻璃，而是一圈石环。不转的四环面本来就躺在窗平面里，
    // 因为实例旋转已经把局部 +z 对准了厅内。
    const oculus = new THREE.InstancedMesh(
      new THREE.TorusGeometry(0.17, 0.032, 8, 22), M.darkStone, FAR_N);

    const col = new THREE.Color();
    for (let i = 0; i < FAR_N; i++) {
      const a = ((i + 0.5) / FAR_N) * Math.PI * 2 + 0.15;
      e.set(0, -a - Math.PI / 2, 0); q.setFromEuler(e);
      const ca = Math.cos(a), sa = Math.sin(a);
      const put = (im, idx, radius, y) => {
        m4.compose(new THREE.Vector3(ca * radius, y, sa * radius), q, one);
        im.setMatrixAt(idx, m4);
      };
      put(windows, i, WALL_R - 0.05, WIN_SILL);
      put(reveals, i, WALL_R - 0.02, WIN_SILL - 0.13);
      put(halos, i, WALL_R - REVEAL - 0.05, WIN_SILL + WIN_H * 0.46);
      put(mullV, i, WALL_R - REVEAL * 0.62, WIN_SILL + WIN_H * 0.40);
      for (let k = 0; k < 2; k++) {
        put(mullH, i * 2 + k, WALL_R - REVEAL * 0.62, WIN_SILL + 0.95 + k * 1.0);
      }
      put(sills, i, WALL_R - REVEAL * 0.5, WIN_SILL - 0.20);
      put(oculus, i, WALL_R - REVEAL * 0.62, WIN_SILL + WIN_H * 0.80);
      // 每扇窗的透光量略有不同：24 扇一模一样的窗会立刻读成贴图重复。
      // 确定性伪随机，所以同一 seed 每次跑都一致。
      windows.setColorAt(i, col.setScalar(0.66 + 0.34 * (((i * 7) % 5) / 4)));
    }
    for (const im of [windows, reveals, halos, mullV, mullH, sills, oculus]) {
      im.instanceMatrix.needsUpdate = true;
      group.add(im);
    }
    if (windows.instanceColor) windows.instanceColor.needsUpdate = true;
  }

  // 远柱上的烛火：24 个光晕画在一张 Points 里（1 个 draw call），
  // 外加一朵很小的火苗几何当光源本体。暖色只出现在这一圈和近柱壁灯上，
  // 冷色只出现在高窗上 —— 这就是这张画面的冷暖分割。
  const glowPts = [];
  const flameGeo = new THREE.ConeGeometry(0.04, 0.13, 6);
  const flameMat = new THREE.MeshBasicMaterial({ color: 0xcf9a5a });
  const farFlames = new THREE.InstancedMesh(flameGeo, flameMat, FAR_N);
  for (let i = 0; i < FAR_N; i++) {
    const a = (i / FAR_N) * Math.PI * 2 + 0.15;
    const x = Math.cos(a) * (FAR_R - 0.34), z = Math.sin(a) * (FAR_R - 0.34);
    glowPts.push(x, 4.45, z);
    e.set(0, 0, 0); q.setFromEuler(e);
    m4.compose(new THREE.Vector3(x, 4.42, z), q, one);
    farFlames.setMatrixAt(i, m4);
  }
  farFlames.instanceMatrix.needsUpdate = true;
  group.add(farFlames);
  const glowGeo = new THREE.BufferGeometry();
  glowGeo.setAttribute("position", new THREE.Float32BufferAttribute(glowPts, 3));
  group.add(new THREE.Points(glowGeo, M.glow));

  /* --- 光柱：从画面外斜射到基座上 --------------------------------------
   *
   * 一座教堂内景没有光柱，读起来就是纸板搭的布景。而光柱恰恰是最便宜的大片感：
   * 一个开口向下的圆锥 + 一个加法混合的着色器，一次 draw call。
   *
   * 方向对着主光（moon 在 -9,18,-6），所以它是**斜**的 —— 垂直光柱看起来像
   * 特效，斜的才像从上方某个开口漏下来的。锥口小、锥底大，光在空气里散开。
   *
   * 亮度用 |dot(N,V)| 算：视线正对的地方穿过的"体积"最长，所以中心亮、轮廓软。
   * 一个圆柱的硬边轮廓是它看起来像塑料片的原因。
   */
  {
    const shaftMat = new THREE.ShaderMaterial({
      uniforms: {
        uTime: { value: 0 },
        uColor: { value: new THREE.Color(0x9fb4ff) },
        // 亮度单位是**线性**空间，而这个厅本身只有 0.01~0.1 —— 加法混合在这里
        // 非常容易过头。0.17 是一层蓝纱，0.075 仍然把整幅画洗白；0.022 才是光束。
        uIntensity: { value: 0.022 },
      },
      vertexShader: /* glsl */`
        varying vec3 vN;
        varying vec3 vV;
        varying vec2 vUv;
        void main() {
          vec4 mv = modelViewMatrix * vec4(position, 1.0);
          vN = normalize(normalMatrix * normal);
          vV = normalize(-mv.xyz);
          vUv = uv;
          gl_Position = projectionMatrix * mv;
        }
      `,
      fragmentShader: /* glsl */`
        uniform float uTime;
        uniform vec3 uColor;
        uniform float uIntensity;
        varying vec3 vN;
        varying vec3 vV;
        varying vec2 vUv;
        void main() {
          float facing = pow(abs(dot(normalize(vN), normalize(vV))), 2.0);
          // CylinderGeometry 的 uv.y 从下 0 到上 1：越靠近光源越亮，到底散尽。
          // 指数要大，否则光柱会一路亮到地面，变成一片光幕。
          float fade = pow(vUv.y, 2.4);
          // 尘埃在光柱里缓慢下沉 —— 完全干净的光柱看起来就是一块半透明塑料。
          // 频率要细，粗条纹会读成"斜纹布"。
          float n = 0.80 + 0.20 * sin(vUv.y * 34.0 - uTime * 0.5
                                      + sin(vUv.x * 6.28318) * 1.1);
          float a = facing * fade * n * uIntensity;
          gl_FragColor = vec4(uColor, a);
        }
      `,
      transparent: true,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      side: THREE.DoubleSide,
    });

    // 落点选在基座的左后方，而不是正中。
    //
    // 一开始让它落在 (0,0.6,0)，正好压在揭示时那张牌上 —— 加法混合把主角洗白了。
    // 而且那条轴的投影几乎正对相机，看起来是一团光斑而不是一束光。
    // 现在它横着穿过左半边画面（z 从 -8 到 -3.8，几乎不朝相机来），侧看才有光束感，
    // 落点也在基座外侧的地面上。
    const from = new THREE.Vector3(-11.0, 13.0, -8.0);
    const to = new THREE.Vector3(-4.7, 0.5, -3.8);
    const axis = new THREE.Vector3().subVectors(to, from);
    const len = axis.length();
    const shaft = new THREE.Mesh(
      new THREE.CylinderGeometry(0.5, 1.7, len, 40, 1, true),
      shaftMat
    );
    shaft.position.copy(from).addScaledVector(axis, 0.5);
    // 让锥体的 +Y 对准轴（three 默认轴是 +Y）
    shaft.quaternion.setFromUnitVectors(
      new THREE.Vector3(0, 1, 0), axis.clone().normalize()
    );
    group.add(shaft);
    lightShaft = shaftMat;
  }

  /* --- 壁灯：柱身上的小火苗，取代原来那六个巨型火盆 ------------------- */
  //
  // 托架 / 灯碗 / 火苗各一个 InstancedMesh：36 个网格 → 3 个 draw call。
  // 火苗要跳动，所以它的实例矩阵每帧重算 —— 12 次 compose，可以忽略。
  const candles = [];
  const candleColor = 0xffb45a;
  const flames = new THREE.InstancedMesh(
    new THREE.ConeGeometry(0.055, 0.20, 8),
    new THREE.MeshBasicMaterial({ color: 0xffd9a0 }),
    PILLARS
  );
  flames.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
  {
    const brackets = new THREE.InstancedMesh(
      new THREE.BoxGeometry(0.10, 0.10, 0.42), M.brassDark, PILLARS);
    const cups = new THREE.InstancedMesh(
      new THREE.CylinderGeometry(0.13, 0.07, 0.14, 12), M.brass, PILLARS);
    for (let i = 0; i < PILLARS; i++) {
      const a = (i / PILLARS) * Math.PI * 2;
      const ca = Math.cos(a), sa = Math.sin(a);
      e.set(0, -a, 0); q.setFromEuler(e);      // 托架朝向圆心
      m4.compose(new THREE.Vector3(ca * 0.965 * RING_R, 4.15, sa * 0.965 * RING_R), q, one);
      brackets.setMatrixAt(i, m4);
      e.set(0, 0, 0); q.setFromEuler(e);
      m4.compose(new THREE.Vector3(ca * 0.90 * RING_R, 4.26, sa * 0.90 * RING_R), q, one);
      cups.setMatrixAt(i, m4);
    }
    brackets.instanceMatrix.needsUpdate = true;
    cups.instanceMatrix.needsUpdate = true;
    group.add(brackets, cups);
  }
  group.add(flames);

  for (let i = 0; i < PILLARS; i++) {
    const a = (i / PILLARS) * Math.PI * 2;
    const x = Math.cos(a) * RING_R * 0.90, z = Math.sin(a) * RING_R * 0.90;
    const l = new THREE.PointLight(candleColor, 9, 13, 2);
    l.position.set(x, 4.43, z);
    scene.add(l);
    candles.push({ light: l, base: 9, phase: i * 1.7, x, z });
  }

  /* --- 光照：暖壁灯 + 冷月光 + 冷轮廓 ---------------------------------
   *
   * 上一版 ambient 只有 0x2a2447 @1.05，柱子全成黑剪影。室内要读得出材质，
   * 环境光必须够，再靠方向光做出明暗分界。
   *
   * 但实测又走向另一个极端：整个背景压在亮度 3~21，唯一亮的东西是地面中央一块
   * #445090。原因是两点 ——
   *
   *   1. 唯一带阴影的主光（moon）在**背后**（-9,18,-6）。它其实是轮廓光，不是
   *      主光：相机看到的那一面全部背光。真正照正面的 fill 只有 1.15。
   *   2. 地脚光是一盏 y=0.6、decay 2 的点光。1/d² 在 0.6 米处爆出一个热点，
   *      半径约 5~8 米，颜色偏蓝 —— 画面上那圈"发蓝的亮盘"和硬椭圆边界就是它，
   *      和嵌刻贴图无关。
   *
   * 所以：把 fill 提上来当正面的主光，moon 退成它本来该有的角色（冷背光 + 投影），
   * 地脚光改成 decay 1 的柔和光池。
   *
   * 这些强度是**基准值**，曝光衰减按比例缩放它们（见 setExposure）。
   */
  const AMB = 2.2, HEMI = 1.6, MOON = 2.6, FILL = 2.4, RIM = 2.2, GROUND = 2.6;
  const amb = new THREE.AmbientLight(0x413e60, AMB);
  scene.add(amb);
  // 地面反弹色给暖的，天空给冷的 —— 冷上是高窗和月光，暖下是烛火
  const hemi = new THREE.HemisphereLight(0x93a8ea, 0x5c3c22, HEMI);
  scene.add(hemi);

  // 冷背光：从左上后方打下来，负责穹肋和柱子的边缘，以及地面上的长投影
  const moon = new THREE.DirectionalLight(0xd2e2ff, MOON);
  moon.position.set(-9, 18, -6);
  moon.castShadow = true;
  moon.shadow.mapSize.set(2048, 2048);
  moon.shadow.camera.near = 1;
  moon.shadow.camera.far = 60;
  moon.shadow.camera.left = -20;
  moon.shadow.camera.right = 20;
  moon.shadow.camera.top = 20;
  moon.shadow.camera.bottom = -20;
  moon.shadow.bias = -0.0008;
  moon.shadow.normalBias = 0.045;
  scene.add(moon);

  // 正面主光：从相机这一侧偏右打过来。这是让柱子、远回廊、高墙读出形体的那盏。
  const fill = new THREE.DirectionalLight(0xa8aee6, FILL);
  fill.position.set(8, 7, 9);
  scene.add(fill);

  // rim：从背后把柱子和穹肋从背景里"切"出来
  const rim = new THREE.DirectionalLight(0xb0c4ff, RIM);
  rim.position.set(4, 11, -14);
  scene.add(rim);

  // 地脚光：让柱子根部和地面交界处亮一点，强化接地。
  // decay 1（不是物理的 2）是刻意的：平方反比会在灯正下方烧出一个热点，
  // 而这里要的是一片铺开的、能读出嵌刻的光池。
  const ground = new THREE.PointLight(0x7d86c8, GROUND, 44, 1);
  ground.position.set(0, 2.4, 0);
  scene.add(ground);

  const ritual = new THREE.PointLight(0x8f7bff, 0, 22, 2);
  ritual.position.set(0, 2.4, 0);
  scene.add(ritual);

  return {
    group, ritual, amb, hemi, moon, materials: M, signals,
    setRitual(color, intensity = 5.5) {
      ritual.color.setHex(color);
      ritual.intensity = intensity;
      for (const s of signals) {
        s.emissive.setHex(color);
        s.emissiveIntensity = 1.2 + intensity * 0.14;
      }
    },
    /**
     * 整厅曝光倍率（命运的锁定瞬间会压暗全场）。
     *
     * 之前这件事是在 main.js 里直接写 `temple.amb.intensity = 1.45 * e` —— 每帧
     * 用旧的低值**覆盖**这里配置的强度。结果是无论把殿堂的光调多亮，都永远亮不过
     * 1.45 环境光，柱子只能是黑剪影。现在改成按比例缩放，配置值才真正生效。
     */
    setExposure(e) {
      amb.intensity = AMB * e;
      hemi.intensity = HEMI * e;
      moon.intensity = MOON * e;
      fill.intensity = FILL * e;
      rim.intensity = RIM * e;
      ground.intensity = GROUND * e;
    },
    update(t) {
      if (lightShaft) lightShaft.uniforms.uTime.value = t;
      for (let i = 0; i < candles.length; i++) {
        const c = candles[i];
        const f = 0.82 + 0.18 * Math.sin(t * 9.3 + c.phase) * Math.sin(t * 3.1 + c.phase * 2);
        c.light.intensity = c.base * f;
        // 火苗的跳动现在写在实例矩阵里：位置不动，只改缩放
        e.set(0, 0, 0); q.setFromEuler(e);
        m4.compose(
          new THREE.Vector3(c.x, 4.43, c.z), q,
          new THREE.Vector3(0.9 + f * 0.25, 0.85 + f * 0.35, 0.9 + f * 0.25)
        );
        flames.setMatrixAt(i, m4);
      }
      flames.instanceMatrix.needsUpdate = true;
    },
    diagnostics() {
      let meshes = 0, instanced = 0, tris = 0;
      group.traverse((o) => {
        if (!o.isMesh) return;
        meshes++;
        const g = o.geometry;
        const idx = g.index ? g.index.count : (g.attributes.position?.count || 0);
        const n = o.isInstancedMesh ? o.count : 1;
        if (o.isInstancedMesh) instanced++;
        tris += (idx / 3) * n;
      });
      return { meshes, instanced, triangles: Math.round(tris) };
    },
    dispose() {
      scene.remove(group);
      group.traverse((o) => {
        if (o.geometry) o.geometry.dispose();
        if (o.material) (Array.isArray(o.material) ? o.material : [o.material]).forEach((m) => m.dispose());
      });
      lib.textures.forEach((t) => t.dispose());
      [amb, hemi, moon, fill, rim, ground, ritual].forEach((l) => scene.remove(l));
    },
  };
}
