/**
 * The draw ritual, as one GSAP timeline.
 *
 * Timing follows the brief exactly (seconds after INVOKE FATE is pressed):
 *
 *   spawn    0.0 - 1.0   circle wakes, five cards rise out of the dark
 *   shuffle  1.0 - 3.3   cards break formation and interleave through the hall
 *   lock     3.3 - 4.2   hard stop, hall dims, one card shakes and rises
 *   reveal   4.2 - 5.5   camera pushes, card flips with a flare at 90 degrees
 *   descend  5.5 - 6.8   aura blooms, signature object appears, copy staggers in
 *   (end)    6.8         hands control to the player
 *
 * Design notes:
 *
 *  - GSAP never writes to Three.js objects directly. It animates plain state
 *    objects (`card.st`, `cam`, `host`); a single apply-pass in the render loop
 *    pushes that state into matrices and uniforms. This keeps tweens cheap,
 *    makes seeking exact, and means the shuffle can be a procedural function of
 *    one scalar rather than hundreds of keyframes.
 *
 *  - The shuffle returns to the exact arc pose at both p=0 and p=1 (the swing
 *    term is sin(p*PI)), so the formation is identical before and after and no
 *    tween has to reconcile a mismatch.
 *
 *  - The chosen card is decided BEFORE the shuffle and stored, per the brief,
 *    but nothing on screen reveals it until the lock.
 */
import { gsap } from "gsap";

export const ACTS = {
  spawn: { at: 0.0, dur: 1.0 },
  shuffle: { at: 1.0, dur: 2.3 },
  lock: { at: 3.3, dur: 0.9 },
  reveal: { at: 4.2, dur: 1.3 },
  descend: { at: 5.5, dur: 1.3 },
};
export const RITUAL_END = 6.8;

const ARC_R = 3.6;
const ARC_STEP = 0.375;
const CARD_Y = 0.55;

/** Resting pose of card i in the five-card arc. */
export function arcPose(i, n) {
  const a = (i - (n - 1) / 2) * ARC_STEP;
  const x = Math.sin(a) * ARC_R;
  // negative z pushes the outer cards away from the camera, so the formation
  // curves around the ritual circle rather than sitting on a flat line
  const z = -ARC_R * (1 - Math.cos(a));
  return {
    a, x, y: CARD_Y, z,
    // face-down: the back's local -Z has to be turned toward the camera, and
    // the arc tilt still applied. theta = PI - a satisfies both.
    ry: Math.PI - a,
    // the middle card sits slightly forward, per the brief
    zBias: i === (n - 1) / 2 ? 0.30 : 0,
  };
}

/**
 * Shuffle motion. Returns the pose as a function of progress p in 0..1.
 * p = 0 and p = 1 both land exactly on the arc pose.
 */
export function shufflePose(card, p, out) {
  const s = card.rand;
  const swing = Math.sin(p * Math.PI);                      // 0 -> 1 -> 0
  const turns = 1.05 + s.turns;
  const ang = card.arc.a + card.dir * swing * Math.PI * turns;
  const radius = ARC_R * (1 + 0.42 * swing);

  out.x = Math.sin(ang) * radius + swing * Math.sin(p * 11 + s.p1) * 0.35;
  out.z = -radius * (1 - Math.cos(ang)) + swing * Math.sin(p * 13 + s.p2) * 0.75;
  out.y = CARD_Y + swing * (0.75 + 0.65 * Math.sin(p * 7 + s.p3));
  out.ry = Math.PI - ang + swing * Math.sin(p * 9 + s.p4) * 0.7;
  out.rx = swing * Math.sin(p * 6 + s.p5) * 0.42;
  out.rz = swing * Math.sin(p * 8 + s.p6) * 0.55;
  return out;
}

export function createTimeline(ctx) {
  const { deck, cards, circle, temple, vfx, host, ui, audio } = ctx;
  const n = cards.length;

  const cam = host.cam;
  const pose = { x: 0, y: 0, z: 0, rx: 0, ry: 0, rz: 0 };

  const tl = gsap.timeline({
    paused: true,
    onStart: () => audio.play("ambient_loop", { gain: 0.0 }),
  });

  // ---------------------------------------------------------------- act 1 --
  tl.addLabel("spawn", ACTS.spawn.at);

  tl.to(circle.uniforms.uIntensity, {
    value: 1, duration: 0.9, ease: "power2.out",
  }, ACTS.spawn.at);

  tl.to(cam, { z: 7.0, y: 1.55, duration: 3.0, ease: "power1.inOut" }, ACTS.spawn.at);
  tl.to(host.look, { y: 1.28, duration: 3.0, ease: "power1.inOut" }, ACTS.spawn.at);

  cards.forEach((card, i) => {
    const at = ACTS.spawn.at + i * 0.11;
    tl.to(card.st, {
      opacity: 1, s: 1, duration: 0.55, ease: "power2.out",
      onStart: () => audio.play("card_spawn", { gain: 0.5, rate: 0.95 + i * 0.04 }),
    }, at);
  });

  // ---------------------------------------------------------------- act 2 --
  tl.addLabel("shuffle", ACTS.shuffle.at);
  tl.call(() => audio.play("shuffle", { gain: 0.7 }), null, ACTS.shuffle.at);

  cards.forEach((card, i) => {
    tl.to(card.st, {
      shuffleP: 1,
      duration: ACTS.shuffle.dur,
      ease: "sine.inOut",
      onStart: () => { card.st.shuffleActive = 1; },
      onComplete: () => { card.st.shuffleActive = 0; },
    }, ACTS.shuffle.at + i * 0.03);
    tl.to(card.st, {
      foil: 0.92, duration: ACTS.shuffle.dur * 0.5, ease: "sine.inOut",
      yoyo: true,
    }, ACTS.shuffle.at);
  });

  tl.to(circle.uniforms.uRot, { value: 26, duration: ACTS.shuffle.dur, ease: "power1.in" }, ACTS.shuffle.at);
  tl.to(host, { trailBoost: 1, duration: 0.5, ease: "power1.out" }, ACTS.shuffle.at);
  tl.to(host, { trailBoost: 0, duration: 0.8, ease: "power1.in" }, ACTS.shuffle.at + 1.4);
  tl.to(cam, { z: 6.80, duration: ACTS.shuffle.dur, ease: "sine.inOut" }, ACTS.shuffle.at);
  tl.to(host.look, { z: 0.30, y: 1.34, duration: ACTS.shuffle.dur, ease: "sine.inOut" }, ACTS.shuffle.at);

  // ---------------------------------------------------------------- act 3 --
  tl.addLabel("lock", ACTS.lock.at);

  // hard stop: everything freezes on one frame, hall drops, then the chosen
  // card is singled out
  tl.call(() => audio.play("fate_lock", { gain: 1.0 }), null, ACTS.lock.at);
  tl.to(temple.ritual, { intensity: 0.6, duration: 0.12, ease: "power4.in" }, ACTS.lock.at);
  tl.to(host, { exposure: 0.34, duration: 0.22, ease: "power3.in" }, ACTS.lock.at);
  tl.call(() => {
    // the selection was made before the shuffle; this is the reveal of it
    ctx.onFateLocked();
  }, null, ACTS.lock.at + 0.16);

  tl.to(host, { exposure: 1, duration: 0.5, ease: "power2.out" }, ACTS.lock.at + 0.28);
  tl.to(temple.ritual, { intensity: 7.5, duration: 0.55, ease: "power2.out" }, ACTS.lock.at + 0.3);

  cards.forEach((card, i) => {
    if (i === host.selected) return;
    tl.to(card.st, {
      opacity: 0.16, s: 0.86, duration: 0.65, ease: "power2.in",
      onUpdate: () => {},
    }, ACTS.lock.at + 0.18);
  });

  // chosen card: a short shake, then it lifts out of the formation
  const chosen = cards[host.selected];
  const shakeT = ACTS.lock.at + 0.18;
  for (let k = 0; k < 4; k++) {
    tl.to(chosen.st, {
      x: chosen.arc.x + (k % 2 ? 0.045 : -0.045),
      duration: 0.045, ease: "none",
    }, shakeT + k * 0.045);
  }
  tl.to(chosen.st, {
    x: 0, y: 1.55, z: 1.20,
    // still FACE DOWN at this point: ry = PI turns the card's back to the
    // camera. The flip to 0 is what reveals the front, in act four.
    ry: Math.PI, rx: 0, rz: 0, s: 1.12,
    duration: 0.62, ease: "power3.out",
  }, shakeT + 0.2);
  tl.to(cam, { z: 6.60, y: 1.55, duration: 0.62, ease: "power3.out" }, shakeT + 0.2);
  tl.to(host.look, { y: 1.42, z: 0.90, duration: 0.62, ease: "power3.out" }, shakeT + 0.2);

  // ---------------------------------------------------------------- act 4 --
  tl.addLabel("reveal", ACTS.reveal.at);

  tl.to(cam, { z: 6.35, y: 1.55, duration: ACTS.reveal.dur, ease: "power2.inOut" }, ACTS.reveal.at);
  tl.to(chosen.st, { z: 1.45, y: 1.50, s: 1.24, duration: ACTS.reveal.dur, ease: "power2.inOut" }, ACTS.reveal.at);
  tl.to(host.look, { y: 1.48, z: 1.30, duration: ACTS.reveal.dur, ease: "power2.inOut" }, ACTS.reveal.at);

  // the flip, with the flare fired exactly at 90 degrees so the face swap is
  // never actually seen
  const flipAt = ACTS.reveal.at + 0.42;
  tl.to(chosen.st, {
    ry: 0,                 // PI (back to camera) -> 0 (front to camera)
    duration: 0.72,
    ease: "power2.inOut",
  }, flipAt);
  tl.call(() => {
    audio.play("card_flip", { gain: 0.8 });
    // 0.92 是"纯白满屏"的量级，在暗殿堂上就是过曝（玩家反馈：高爆白屏）。
    // 这里它只需要**盖住换面**那一帧，0.46 足够，而且时长拉长到 0.46s，
    // 升段占 16%，是亮起来不是炸开。
    ui.flash(0.46, 0.46);
    // 色差也跟着收：revealPulse=1 会把 chroma.offset 拉到基准的 16 倍，
    // 在闪光那一帧叠加出一圈彩虹边。
    host.revealPulse = 0.5;
  }, null, flipAt + 0.33);
  tl.to(host, { revealPulse: 0, duration: 0.5, ease: "power2.out" }, flipAt + 0.36);

  // ---------------------------------------------------------------- act 5 --
  tl.addLabel("descend", ACTS.descend.at);

  tl.call(() => {
    audio.play("character_reveal", { gain: 0.9 });
    vfx.play(ctx.selectedCharacter);
    circle.setColor(ctx.selectedCharacter.palette.primary, ctx.selectedCharacter.palette.accent);
    temple.setRitual(ctx.selectedCharacter.palette.light, 6.5);
    ui.showCopy(ctx.selectedCharacter);
  }, null, ACTS.descend.at);

  tl.fromTo(vfx.auraUniforms.uIntensity,
    { value: 0 },
    { value: 1, duration: 0.85, ease: "power2.out" }, ACTS.descend.at);
  // signature opacity/scale ride a host scalar so the tween has something plain
  // to animate; the apply pass forwards it to vfx.setIntensity()
  tl.fromTo(host,
    { sigK: 0 },
    {
      sigK: 1, duration: 0.9, ease: "power2.out",
      onUpdate: () => vfx.setIntensity(host.sigK),
    }, ACTS.descend.at);

  tl.to(chosen.st, { z: 1.60, y: 1.45, s: 1.30, duration: ACTS.descend.dur, ease: "power2.inOut" }, ACTS.descend.at);
  tl.to(cam, { z: 6.10, y: 1.55, duration: ACTS.descend.dur, ease: "power2.inOut" }, ACTS.descend.at);
  tl.to(host.look, { y: 1.45, z: 1.60, duration: ACTS.descend.dur, ease: "power2.inOut" }, ACTS.descend.at);

  // The card stops being a card. Its rectangle dissolves and the character
  // steps out as a die-cut figure in front of its own backdrop plate - the beat
  // that turns "a card appeared" into "the character arrived".
  tl.to(host, { figureK: 1, duration: 1.05, ease: "power2.inOut" }, ACTS.descend.at + 0.06);

  // stagger the copy: name -> skill -> line
  tl.call(() => ui.revealStage("name"), null, ACTS.descend.at + 0.15);
  tl.call(() => ui.revealStage("skill"), null, ACTS.descend.at + 0.62);
  tl.call(() => ui.revealStage("line"), null, ACTS.descend.at + 1.02);
  tl.call(() => ui.revealStage("actions"), null, ACTS.descend.at + 1.28);

  tl.addLabel("end", RITUAL_END);
  tl.call(() => ctx.onRitualEnd(), null, RITUAL_END);

  return tl;
}
