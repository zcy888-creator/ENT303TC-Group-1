/**
 * DOM overlay: the ritual's typography and controls.
 *
 * Kept as HTML rather than rendered into the canvas so the serif faces, letter
 * spacing and CJK line breaking are exactly what the browser gives us. The
 * canvas is purely the 3D stage; nothing narrative is drawn into it.
 *
 * Copy reveal is staggered name -> skill -> line -> actions, per the brief, and
 * `revealStage` is called from the GSAP timeline so the type stays locked to the
 * choreography rather than to a CSS delay.
 */

export function createUi(root) {
  const $ = (sel) => root.querySelector(sel);

  const el = {
    intro: $("#intro"),
    introTitle: $("#intro-title"),
    introSub: $("#intro-sub"),
    invoke: $("#invoke"),
    flash: $("#flash"),
    copy: $("#copy"),
    nameEn: $("#name-en"),
    nameCn: $("#name-cn"),
    skillBox: $("#skill"),
    skillCn: $("#skill-cn"),
    skillEn: $("#skill-en"),
    line: $("#line"),
    actions: $("#actions"),
    accept: $("#accept"),
    again: $("#again"),
    status: $("#status"),
    fps: $("#fps"),
    cardHint: $("#cardhint"),
    skillInfo: $("#skillInfo"),
    siName: $("#si-name"),
    siNameEn: $("#si-name-en"),
    siBody: $("#si-body"),
  };

  const state = {};

  const api = {
    el,
    onInvoke: null,
    onAccept: null,
    onAgain: null,
    onHover: null,

    /**
     * 转向 90° 时盖住换面的一次闪光。
     *
     * 旧实现是"把 opacity 直接写成峰值，再淡出"——那个**瞬间跳变**在暗场景上
     * 读起来就是一次过曝（玩家的原话："高爆白屏闪一下，很不舒服"）。
     * 现在交给一条 CSS 动画：0 → 峰值 → 0，升段占 16%，是"亮起来"而不是"炸开"。
     *
     * 峰值默认也从 0.9 降到 0.5 —— 这个游戏是暗紫金的，不该有纯白满屏。
     */
    flash(alpha = 0.5, dur = 0.42) {
      if (!el.flash) return;
      el.flash.style.setProperty("--a", String(alpha));
      el.flash.style.animation = "none";
      // 强制一次样式读取，否则连续两次闪光会被合并成一次
      void el.flash.offsetHeight;
      el.flash.style.animation = `flashPulse ${dur}s cubic-bezier(.2,.7,.3,1) both`;
    },

    showIntro() {
      el.intro?.classList.add("is-on");
      el.copy?.classList.remove("is-on");
    },
    hideIntro() {
      el.intro?.classList.remove("is-on");
    },

    /** Pre-fill the copy block while it is still invisible. */
    showCopy(character) {
      state.character = character;
      el.nameEn.textContent = character.nameEn;
      el.nameCn.textContent = character.nameCn;
      el.skillCn.textContent = character.skillCn;
      el.skillEn.textContent = character.skillEn;
      el.line.textContent = character.line;
      el.copy.classList.add("is-on");
      el.copy.dataset.provisional = character.skillProvisional ? "1" : "0";
    },

    revealStage(stage) {
      const map = { name: "reveal-name", skill: "reveal-skill", line: "reveal-line", actions: "reveal-actions" };
      el.copy?.classList.add(map[stage]);
    },

    setStatus(text) {
      if (el.status) el.status.textContent = text || "";
    },

    setFps(v) {
      if (el.fps) el.fps.textContent = v ? `${v} FPS` : "";
    },

    /** Reset every reveal class so DRAW AGAIN replays cleanly. */
    resetCopy() {
      el.copy?.classList.remove("is-on", "reveal-name", "reveal-skill", "reveal-line", "reveal-actions");
      el.actions?.classList.remove("is-on");
    },

    showActions() {
      el.actions?.classList.add("is-on");
      // 牌已经稳在手上，可以点了 —— 提示和按钮同时出现
      el.cardHint?.classList.add("is-on");
    },

    /** 翻到技能面之后就把"点击卡面"的提示收掉：那个高度上正好压着卡面。 */
    showCardHint(on) {
      el.cardHint?.classList.toggle("is-on", !!on);
    },

    /**
     * 技能说明面板。翻开时 #copy 淡出、这块淡入 —— 同一个位置，同一套排版，
     * 读起来是"信息换了一页"而不是"又弹了一个框"。
     */
    showSkillInfo(character) {
      if (!el.skillInfo) return;
      if (!character) { el.skillInfo.classList.remove("is-on"); return; }
      el.siName.textContent = character.skillCn;
      el.siNameEn.textContent = character.skillEn;
      // 逐行注入，行与行之间错开 55ms —— 一次性出现会像网页加载完
      el.siBody.innerHTML = "";
      (character.skillDesc || []).filter((s) => s && s.length).forEach((line, i) => {
        const p = document.createElement("p");
        p.className = "si-line";
        p.textContent = line;
        p.style.transitionDelay = `${0.16 + i * 0.055}s`;
        el.siBody.appendChild(p);
      });
      el.skillInfo.classList.add("is-on");
    },

    setBusy(busy) {
      el.invoke?.toggleAttribute("disabled", busy);
      el.accept?.toggleAttribute("disabled", busy);
      el.again?.toggleAttribute("disabled", busy);
    },
  };

  el.invoke?.addEventListener("click", () => { api.onInvoke?.(); });
  el.accept?.addEventListener("click", () => { api.onAccept?.(); });
  el.again?.addEventListener("click", () => { api.onAgain?.(); });
  for (const b of [el.invoke, el.accept, el.again]) {
    b?.addEventListener("pointerenter", () => api.onHover?.());
  }

  return api;
}
