/**
 * Per-character reveal effects.
 *
 * The brief is explicit that the five characters must not share one purple
 * effect, so each gets three things that switch together at fate-lock:
 *
 *   1. an AURA   - one shader, but the rune-ring tick count and ring count
 *                  differ per character, so the geometry of the halo itself
 *                  reads differently instead of being a recolour
 *   2. a SIGNATURE object - a real form built from geometry, not glow:
 *                  crescent moon / watch dial / lens + cross / armillary
 *                  rings / suspended pages around a wax seal
 *   3. PARTICLES - a distinct motion mode (see particles.js): rising mist,
 *                  cold rain, tumbling petals, orbiting stars, drifting pages
 *
 * Structure: each rig is  root(billboard) -> inner(spins about Z) -> parts.
 * The root faces the camera every frame; only the inner spins, so the spin
 * stays screen-aligned instead of tumbling out of the plane.
 */
import * as THREE from "three";
import { createMotes, createSprites } from "./particles.js";

const AURA_FRAG = /* glsl */ `
precision highp float;
varying vec2 vUv;
uniform float uTime, uIntensity, uTicks, uRings;
uniform vec3 uColorA, uColorB;

float ringMask(float r, float t, float w) { return smoothstep(w, 0.0, abs(r - t)); }

void main() {
  vec2 p = (vUv - 0.5) * 2.0;
  float r = length(p);
  if (r > 1.0) discard;
  float a = atan(p.y, p.x);

  float glow = pow(smoothstep(1.0, 0.0, r), 3.2) * 0.30;

  float seg = fract((a / 6.28318) * uTicks + uTime * 0.035);
  float ticks = smoothstep(0.34, 0.0, abs(seg - 0.5)) * ringMask(r, 0.62, 0.055);
  float seg2 = fract((a / 6.28318) * (uTicks / 6.0) + uTime * 0.035);
  float longTicks = smoothstep(0.10, 0.0, abs(seg2 - 0.5)) * ringMask(r, 0.62, 0.10);

  // 环要细。之前 0.62/宽0.22 × 强度1.15 是一整条宽带，在象牙白命色下糊成
  // 一圈实心死白 —— 看起来像选中高亮。现在是几条叠在一起的细线。
  float rings = 0.0;
  for (int i = 0; i < 3; i++) {
    if (float(i) >= uRings) break;
    rings += ringMask(r, 0.30 + float(i) * 0.17, 0.0035) * (0.55 - float(i) * 0.12);
  }

  float seg3 = fract((a / 6.28318) * (uTicks * 0.5) - uTime * 0.06);
  float inner = smoothstep(0.18, 0.0, abs(seg3 - 0.5)) * ringMask(r, 0.26, 0.028);

  float m = glow + ticks * 0.62 + longTicks * 0.72 + rings * 0.5 + inner * 0.34;
  vec3 col = mix(uColorA, uColorB, clamp(r * 1.2, 0.0, 1.0));
  float outA = m * uIntensity;
  if (outA < 0.003) discard;
  gl_FragColor = vec4(col, outA);
}
`;

const AURA_VERT = `varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }`;

// Aura diameter in world units. Budgeted against the reveal framing: the camera
// ends ~4.5 units from the card with a visible height of ~3.1, and the card
// itself is 1.575 * 1.30 = 2.05 tall. 2.3 keeps the halo just inside the frame
// instead of washing the whole screen with additive glow.
const FX_SCALE = 2.3;

/**
 * 命座印记的整体压暗系数。
 *
 * 每个角色的秘仪符号原本按 0.4-0.95 的不透明度绘制，叠起来是一圈抢戏的亮环 ——
 * 尤其医师那圈象牙白，在画面上像选中高亮。压到一半之后它们退到角色**背后**，
 * 变成"隐约的仪式刻痕"，而不是盖在美术上的装饰。五个角色一起调，一个常数搞定。
 */
const SIGIL_GAIN = 0.5;

/** 0.30-0.50 opacity range, restored verbatim by setIntensity */
function glowMat(mats, hex, opacity) {
  const m = new THREE.MeshBasicMaterial({
    color: hex, transparent: true, opacity,
    blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false,
  });
  m.userData.baseOpacity = opacity;
  mats.push(m);
  return m;
}

function buildSignature(id, mats) {
  const root = new THREE.Group();     // billboarded
  const inner = new THREE.Group();    // spins about Z
  root.add(inner);
  root.userData.inner = inner;

  if (id === "medium") {
    const crescent = new THREE.Mesh(
      new THREE.TorusGeometry(1.55, 0.055, 8, 96, Math.PI * 1.35),
      glowMat(mats, 0xc9d3e6, 0.95));
    crescent.rotation.z = Math.PI * 0.32;
    const halo = new THREE.Mesh(
      new THREE.TorusGeometry(1.9, 0.016, 6, 128), glowMat(mats, 0x9b7fe0, 0.5));
    inner.add(crescent, halo);
    for (let i = 0; i < 3; i++) {
      const f = new THREE.Mesh(
        new THREE.ConeGeometry(0.10, 0.54, 8, 1, true), glowMat(mats, 0xb98cff, 0.45));
      const a = (i / 3) * Math.PI * 2;
      f.position.set(Math.cos(a) * 1.2, -0.75, 0);
      inner.add(f);
    }
    root.userData.spin = 0.055;
  } else if (id === "detective") {
    const dial = new THREE.Group();
    for (let i = 0; i < 60; i++) {
      const long = i % 5 === 0;
      const tick = new THREE.Mesh(
        new THREE.BoxGeometry(long ? 0.034 : 0.016, long ? 0.26 : 0.13, 0.012),
        glowMat(mats, long ? 0xd9c07a : 0x8a8778, long ? 0.95 : 0.55));
      const a = (i / 60) * Math.PI * 2;
      tick.position.set(Math.cos(a) * 1.66, Math.sin(a) * 1.66, 0);
      tick.rotation.z = a - Math.PI / 2;
      dial.add(tick);
    }
    const handMat = glowMat(mats, 0xd9c07a, 0.85);
    const h1 = new THREE.Mesh(new THREE.BoxGeometry(0.020, 0.92, 0.010), handMat);
    h1.position.y = 0.43; h1.rotation.z = 0.6;
    const h2 = new THREE.Mesh(new THREE.BoxGeometry(0.016, 1.26, 0.010), handMat);
    h2.position.y = 0.56; h2.rotation.z = -1.9;
    const gear = new THREE.Mesh(
      new THREE.TorusGeometry(1.22, 0.028, 6, 48), glowMat(mats, 0x6f6a58, 0.4));
    dial.add(h1, h2);
    inner.add(dial, gear);
    root.userData.spin = -0.085;
  } else if (id === "physician") {
    // The lens ring was TorusGeometry(1.55, 0.045, 8, 96) at 0.8 opacity in the
    // character's near-white primary - a continuous 96-segment torus almost as
    // tall as the card. On screen it read as a hard white halo around the whole
    // reveal, which is the single cheapest-looking thing in the ritual. Thinner,
    // dimmer, and pushed toward the accent colour so it frames instead of glows.
    const lens = new THREE.Mesh(
      new THREE.TorusGeometry(1.62, 0.016, 6, 128), glowMat(mats, 0xe8e2d4, 0.40));
    const inner2 = new THREE.Mesh(
      new THREE.TorusGeometry(1.18, 0.012, 6, 96), glowMat(mats, 0x4f7f6a, 0.34));
    const cross = new THREE.Group();
    const cm = glowMat(mats, 0x8e1f2c, 0.62);
    const v = new THREE.Mesh(new THREE.BoxGeometry(0.045, 1.02, 0.020), cm);
    const h = new THREE.Mesh(new THREE.BoxGeometry(0.56, 0.045, 0.020), cm);
    h.position.y = 0.22;
    cross.add(v, h);
    cross.position.y = -0.38;
    inner.add(lens, inner2, cross);
    root.userData.spin = 0.028;
  } else if (id === "astrologer") {
    [[1.9, 0.022, 0xcfe0ff, 0.72, 0.35],
     [1.52, 0.015, 0x3f7bd6, 0.5, 1.15],
     [1.16, 0.013, 0x3f7bd6, 0.45, -0.75]].forEach(([rr, tube, hex, op, inc]) => {
      const ring = new THREE.Mesh(
        new THREE.TorusGeometry(rr, tube, 6, 120), glowMat(mats, hex, op));
      ring.rotation.x = inc;
      inner.add(ring);
    });
    inner.add(new THREE.Mesh(
      new THREE.SphereGeometry(0.075, 12, 12), glowMat(mats, 0xcfe0ff, 0.95)));
    root.userData.spin = 0.045;
  } else {
    const seal = new THREE.Mesh(
      new THREE.CylinderGeometry(0.34, 0.34, 0.06, 24), glowMat(mats, 0xa8802f, 0.75));
    seal.rotation.x = Math.PI / 2;
    inner.add(seal);
    for (let i = 0; i < 7; i++) {
      const leaf = new THREE.Mesh(
        new THREE.PlaneGeometry(0.42, 0.56),
        glowMat(mats, i % 2 ? 0xe0c489 : 0x6d1f2e, 0.5));
      const a = (i / 7) * Math.PI * 2;
      leaf.position.set(Math.cos(a) * 1.6, Math.sin(a) * 1.55, 0);
      leaf.rotation.z = a;
      inner.add(leaf);
    }
    root.userData.spin = -0.038;
  }

  return root;
}

const BOUNDS = new THREE.Vector3(9, 7, 9);
const boxDist = (spread) => (rnd) =>
  new THREE.Vector3((rnd() - 0.5) * spread, (rnd() - 0.5) * spread, (rnd() - 0.5) * spread);

function buildParticles(id, palette, quality, scene) {
  const q = (n) => Math.max(12, Math.round(n * quality));
  const list = [];

  if (id === "medium") {
    list.push(createMotes({
      scene, mode: "MIST", count: q(180), distribute: boxDist(3.4), bounds: BOUNDS,
      color: { a: palette.primary, b: palette.secondary }, baseSize: 0.045, seed: 11,
    }));
  } else if (id === "detective") {
    list.push(createMotes({
      scene, mode: "RAIN", count: q(280), distribute: boxDist(6.0), bounds: BOUNDS,
      color: { a: palette.secondary, b: palette.accent }, baseSize: 0.015, seed: 22,
    }));
  } else if (id === "physician") {
    list.push(createSprites({
      scene, smode: 0, count: q(64), distribute: boxDist(3.2), bounds: BOUNDS,
      color: { a: 0xf2ece0, b: palette.secondary }, baseSize: 0.12, seed: 33,
    }));
    list.push(createMotes({
      scene, mode: "MIST", count: q(64), distribute: boxDist(2.6), bounds: BOUNDS,
      color: { a: palette.secondary, b: 0xf2ece0 }, baseSize: 0.028, seed: 34,
    }));
  } else if (id === "astrologer") {
    list.push(createMotes({
      scene, mode: "ORBIT", count: q(200), distribute: boxDist(0.25), bounds: BOUNDS,
      color: { a: palette.accent, b: palette.secondary }, baseSize: 0.028, seed: 44,
    }));
  } else {
    list.push(createSprites({
      scene, smode: 1, count: q(56), distribute: boxDist(3.0), bounds: BOUNDS,
      color: { a: 0xe8d9b4, b: palette.secondary }, baseSize: 0.15, seed: 55,
    }));
    list.push(createMotes({
      scene, mode: "DUST", count: q(80), distribute: boxDist(3.0), bounds: BOUNDS,
      color: { a: palette.accent, b: 0xffd9a0 }, baseSize: 0.018, seed: 56,
    }));
  }

  for (const p of list) p.visible = false;
  return list;
}

const AURA_CFG = {
  medium: { ticks: 72, rings: 3 },
  detective: { ticks: 60, rings: 2 },
  physician: { ticks: 48, rings: 3 },
  astrologer: { ticks: 96, rings: 1 },
  chronicler: { ticks: 36, rings: 2 },
};

export function createCharacterVfx(scene, quality = 1, camera = null) {
  const rigs = {};
  for (const id of ["medium", "detective", "physician", "astrologer", "chronicler"]) {
    const mats = [];
    const root = buildSignature(id, mats);
    root.visible = false;
    scene.add(root);
    rigs[id] = { root, mats, particles: null, palette: null };
  }

  const auraUniforms = {
    uTime: { value: 0 },
    uIntensity: { value: 0 },
    uTicks: { value: 72 },
    uRings: { value: 2 },
    uColorA: { value: new THREE.Color(0x7b5bd6) },
    uColorB: { value: new THREE.Color(0xc9d3e6) },
  };
  const auraMat = new THREE.ShaderMaterial({
    uniforms: auraUniforms,
    vertexShader: AURA_VERT,
    fragmentShader: AURA_FRAG,
    transparent: true, depthWrite: false,
    blending: THREE.AdditiveBlending, side: THREE.DoubleSide, toneMapped: false,
  });
  const aura = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), auraMat);
  aura.visible = false;
  scene.add(aura);

  let current = null;

  return {
    aura,
    auraUniforms,
    get current() { return current; },

    play(character) {
      if (current) {
        rigs[current].root.visible = false;
        rigs[current].particles?.forEach((p) => (p.visible = false));
      }
      current = character.id;
      const rig = rigs[current];
      rig.palette = character.palette;
      rig.root.visible = true;

      if (!rig.particles) rig.particles = buildParticles(current, character.palette, quality, scene);
      rig.particles.forEach((p) => {
        p.visible = true;
        p.setColor(character.palette.primary, character.palette.accent);
        p.uniforms.uOpacity.value = 1;
      });

      const cfg = AURA_CFG[current];
      auraUniforms.uTicks.value = cfg.ticks;
      auraUniforms.uRings.value = cfg.rings;
      auraUniforms.uColorA.value.setHex(character.palette.primary);
      auraUniforms.uColorB.value.setHex(character.palette.accent);
      aura.visible = true;
    },

    /**
     * Build this character's particles and make the rig drawable, WITHOUT
     * starting the effect. The caller compiles, then calls hide().
     *
     * play() builds particles lazily on its first call, which is the descend
     * beat - it measured as a 137ms stall landing exactly on the reveal, the
     * second worst frame in the ritual. Paying that while the intro is still up
     * costs the player nothing.
     */
    warm(character) {
      const rig = rigs[character.id];
      rig.palette = character.palette;
      if (!rig.particles) {
        rig.particles = buildParticles(character.id, character.palette, quality, scene);
      }
      rig.root.visible = true;
      rig.particles.forEach((p) => { p.visible = true; });
      const cfg = AURA_CFG[character.id];
      auraUniforms.uTicks.value = cfg.ticks;
      auraUniforms.uRings.value = cfg.rings;
      auraUniforms.uColorA.value.setHex(character.palette.primary);
      auraUniforms.uColorB.value.setHex(character.palette.accent);
      aura.visible = true;
      current = character.id;
      return rig;
    },

    hide() {
      if (current) {
        rigs[current].root.visible = false;
        rigs[current].particles?.forEach((p) => (p.visible = false));
      }
      aura.visible = false;
      auraUniforms.uIntensity.value = 0;
      current = null;
    },

    /** k = 0..1 reveal strength; also fades the signature opacity */
    setIntensity(k) {
      auraUniforms.uIntensity.value = k;
      if (!current) return;
      const rig = rigs[current];
      // signature ornaments (built at ~1.9 radius) sit just inside the aura
      rig.root.scale.setScalar(0.40 + k * 0.22);
      // SIGIL_GAIN damps every character's sigil uniformly. At full base opacity
      // the ornaments read as a bright geometric halo competing with the card
      // art; at ~half they read as occult markings BEHIND the character, which
      // is what they are for. One constant here beats tuning five branches.
      for (const m of rig.mats) {
        m.opacity = m.userData.baseOpacity * SIGIL_GAIN * Math.min(1, k * 1.15);
      }
      rig.particles?.forEach((p) => (p.uniforms.uOpacity.value = Math.min(1, k)));
    },

    /** Anchor the rig to the revealed card and billboard it. */
    follow(pos, dt, scale = 1) {
      aura.position.copy(pos);
      aura.scale.setScalar(FX_SCALE * scale);
      if (camera) aura.quaternion.copy(camera.quaternion);

      if (!current) return;
      const root = rigs[current].root;
      root.position.copy(pos);
      if (camera) root.quaternion.copy(camera.quaternion);
      const inner = root.userData.inner;
      inner.rotation.z += (root.userData.spin ?? 0) * dt * 60 * 0.02;
    },

    update(t) {
      auraUniforms.uTime.value = t;
      if (current) rigs[current].particles?.forEach((p) => p.update(t));
    },

    dispose() {
      for (const id of Object.keys(rigs)) {
        const r = rigs[id];
        scene.remove(r.root);
        r.root.traverse((o) => { if (o.geometry) o.geometry.dispose(); });
        r.mats.forEach((m) => m.dispose());
        r.particles?.forEach((p) => p.dispose());
      }
      scene.remove(aura);
      aura.geometry.dispose();
      auraMat.dispose();
    },
  };
}
