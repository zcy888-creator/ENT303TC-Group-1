/**
 * 黎明未至 · 桌面启动器
 *
 * 把游戏当成一个独立程序打开，而不是一个网页。
 *
 * 做的事情：
 *   1. 启动内置的 node 服务器（如果端口上没有已经在跑的话）
 *   2. 用 Chrome / Edge 的 --app 模式打开一个**没有地址栏、没有标签页、没有
 *      书签栏**的独立窗口——从外面看就是一个应用窗口，不是浏览器
 *   3. 用独立的 user-data-dir，所以不会碰你平时的浏览记录和登录状态
 *   4. 窗口关掉，服务器跟着关掉
 *
 * 为什么不用 Electron：Electron / Tauri 都要从 npm 下几百 MB 的运行时，
 * 而这个环境连不上 npm。--app 模式的窗口在观感上就是原生程序，而且立刻能用。
 * 真正的 .exe 见同目录的 electron/ 工程。
 *
 * 用法：  node launch.mjs
 *         node launch.mjs --port 4300 --start /
 */
import { spawn } from "node:child_process";
import { existsSync, mkdirSync, writeFileSync } from "node:fs";
import net from "node:net";
import path from "node:path";
import { fileURLToPath } from "node:url";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const argv = process.argv.slice(2);
const argOf = (name, dflt) => {
  const i = argv.indexOf(name);
  return i >= 0 && argv[i + 1] ? argv[i + 1] : dflt;
};

/**
 * 日志。
 *
 * 「启动游戏.vbs」是不弹控制台的，所以一旦出错玩家什么都看不到——只会觉得
 * 「双击了没反应」。所有输出都同时写进 launch-log.txt，出问题时让玩家把这个
 * 文件发过来就行。
 */
const LOG = path.join(HERE, "launch-log.txt");
const logLines = [];
function say(msg) {
  console.log(msg);
  logLines.push(`[${new Date().toISOString()}] ${msg}`);
  try { writeFileSync(LOG, logLines.join("\n") + "\n", "utf8"); } catch {}
}
// 每次启动覆盖上一次的日志
try { writeFileSync(LOG, "", "utf8"); } catch {}

process.on("uncaughtException", (err) => {
  say("启动失败：" + (err?.stack || err));
  process.exit(1);
});

const PORT = Number(argOf("--port", process.env.PORT || 4200));
// 游戏从抽卡开始，所以默认就落在仪式上
const START = argOf("--start", "/draw/");
const URL = `http://127.0.0.1:${PORT}${START}`;
const PROFILE = path.join(HERE, ".app-profile");

/* ------------------------------------------------------------- 找浏览器 --- */

const CANDIDATES = [
  process.env.CHROME_PATH,
  "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
  "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe",
  process.env.LOCALAPPDATA && path.join(process.env.LOCALAPPDATA, "Google/Chrome/Application/chrome.exe"),
  "C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe",
  "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe",
  "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
  "/usr/bin/google-chrome",
  "/usr/bin/chromium",
].filter(Boolean);

const browserExe = CANDIDATES.find((p) => existsSync(p));
if (!browserExe) {
  say("找不到 Chrome 或 Edge。装一个，或者用 CHROME_PATH 指定路径。");
  process.exit(1);
}

/* ---------------------------------------------------------- 端口准备好了吗 --- */

function portOpen(port, timeout = 400) {
  return new Promise((resolve) => {
    const sock = net.connect({ host: "127.0.0.1", port });
    const done = (v) => { sock.destroy(); resolve(v); };
    sock.setTimeout(timeout);
    sock.once("connect", () => done(true));
    sock.once("timeout", () => done(false));
    sock.once("error", () => done(false));
  });
}

/* ------------------------------------------------------------------- 启动 --- */

let server = null;
const already = await portOpen(PORT);
if (already) {
  say(`端口 ${PORT} 上已经有服务器了，直接用它。`);
} else {
  say("正在启动游戏服务器…");
  server = spawn(process.execPath, ["server.mjs"], {
    cwd: HERE,
    env: { ...process.env, PORT: String(PORT), HOST: "127.0.0.1" },
    stdio: "ignore",
  });

  let up = false;
  for (let i = 0; i < 100; i++) {
    if (await portOpen(PORT)) { up = true; break; }
    await new Promise((r) => setTimeout(r, 100));
  }
  if (!up) {
    say("服务器起不来，退出。");
    server?.kill();
    process.exit(1);
  }
}

/* --------------------------------------------------------------- 开窗口 ----- */

// 独立 profile：不碰你平时的浏览器会话，也保证窗口关掉时进程真的退出
mkdirSync(PROFILE, { recursive: true });

say(`打开应用窗口：${URL}`);
const app = spawn(browserExe, [
  `--app=${URL}`,
  `--user-data-dir=${PROFILE}`,
  "--no-first-run",
  "--no-default-browser-check",
  "--disable-features=Translate,MediaRouter",
  // ── 窗口尺寸 ────────────────────────────────────────────────────────────
  // 界面是照 1600×1000 定的版。--window-size 给的是**含标题栏**的外框尺寸，
  // 所以高度要加回标题栏那一条，内容区才落在 1000 左右。
  "--window-size=1600,1040",
  "--window-position=60,30",
  // 应用感：没有地址栏、没有标签栏、没有书签栏
  "--bookmark-bar-visible=false",
], { stdio: "ignore", detached: false });

const shutdown = () => { try { app.kill(); } catch {} try { server?.kill(); } catch {} };
process.on("SIGINT", () => { shutdown(); process.exit(0); });
process.on("exit", shutdown);

// 窗口关掉 = 程序退出
app.on("exit", () => {
  say("窗口已关闭，退出。");
  try { server?.kill(); } catch {}
  process.exit(0);
});
