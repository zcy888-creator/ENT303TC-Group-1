/**
 * 命途之印 —— 这一局唯一的王牌。
 *
 * 它是整个游戏里分量最重的一个动作：一次一局，用完就没，而且五种身份的回报
 * 完全不同。按 game-feel 的说法，一个有分量的动作是**5~8 个小响应叠在 100ms 内**，
 * 而且**短暂夸张之后必须回到静止** —— 否则夸张就成了新的常态，也就不再是反馈。
 *
 * 所以这里做五拍，总共约 1.5 秒：
 *
 *   一拍 定身   印停在半空 0.4s（hit-stop），世界安静
 *   二拍 升起   幕布暗下、印飞向屏幕中央并旋转放大（back 缓动，过冲）
 *   三拍 冲击   冲击波 + 全屏冲洗 + 屏幕震屏
 *   四拍 落纸   结果作为一张案卷页砸进来（squash & stretch 回弹）
 *   五拍 作废   印回到横杆上，裂开、灰掉
 *
 * 震屏用的是 game-feel 的 trauma 模型，不是每帧随机抖动：
 * trauma 累积后按时间衰减，位移取 trauma²（小冲击几乎不动，大冲击才炸），
 * 而且用 sin 采样而不是 rand —— 每帧 rand 会嗡成一片静电噪声。
 */

/** 仪式总时长（毫秒）。CSS 里 rite* 那组动画都是 1.5s，必须和它对上。 */
const RITE_MS = 1500;
/** 冲击发生在仪式的第几毫秒 —— 对应 riteRise 的关键帧 58% 之后开始展开。 */
const IMPACT_MS = 900;

const reduced = () =>
  window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

/* ------------------------------------------------------------ 屏幕震屏 --- */

let trauma = 0;
let shakeRaf = null;
let shakeT = 0;
let shakeLast = 0;

const DECAY = 1.7;        // 每秒衰减的 trauma
const MAX_X = 13, MAX_Y = 9;

function shakeStep(now) {
  const dt = Math.min(0.05, (now - shakeLast) / 1000);
  shakeLast = now;
  trauma = Math.max(0, trauma - DECAY * dt);

  const app = document.getElementById("app");
  if (!app) { shakeRaf = null; return; }

  if (trauma <= 0.0005) {
    app.style.transform = "";
    shakeRaf = null;
    return;
  }
  const s = trauma * trauma;          // 二次曲线：小的几乎不动，大的才炸
  shakeT += dt * 30;
  app.style.transform =
    `translate(${(MAX_X * s * Math.sin(shakeT * 1.7)).toFixed(2)}px,`
    + `${(MAX_Y * s * Math.sin(shakeT * 2.3)).toFixed(2)}px)`;
  shakeRaf = requestAnimationFrame(shakeStep);
}

/** 累积 trauma（冲击是叠加的，不是重置），必要时启动衰减循环。 */
export function addTrauma(n) {
  trauma = Math.min(1, trauma + n);
  if (shakeRaf === null) {
    shakeLast = performance.now();
    shakeRaf = requestAnimationFrame(shakeStep);
  }
}

/* ---------------------------------------------------------------- 状态 --- */

/**
 * 把印切成另一个状态。
 * @param {"ready"|"spent"} s
 */
export function setPlaqueState(s) {
  const el = document.getElementById("ability-btn");
  if (!el) return;
  el.classList.toggle("is-ready", s === "ready");
  el.classList.toggle("is-spent", s === "spent");
  el.disabled = s === "spent";
  const invoke = el.querySelector(".rail-invoke");
  const once = el.querySelector(".rail-once");
  if (invoke) invoke.textContent = s === "spent" ? "已 发 动" : "发 动";
  if (once) once.textContent = s === "spent" ? "本 局 已 用" : "每 局 一 次";
}

/* ---------------------------------------------------------------- 演出 --- */

/**
 * 播完整段仪式，然后 resolve。调用方在这之后才把结果放进 DOM ——
 * 结果必须在冲击**之后**才出现，否则玩家看不到闪光，只看到内容换了一下。
 */
export function playActivation() {
  const rite = document.getElementById("rite");
  const burst = document.getElementById("ability-burst");
  const wash = document.getElementById("ability-wash");
  if (!rite) return Promise.resolve();

  if (reduced()) { setPlaqueState("spent"); return Promise.resolve(); }

  // 重排一次，让连续发动也能重新播
  rite.classList.remove("is-on", "is-done");
  void rite.offsetWidth;
  rite.classList.add("is-on");

  // 冲击波与冲洗都以屏幕中心为圆心（印此刻正在那里）。
  // 传给 CSS 的是两个自定义属性而不是 left/top —— 冲击波现在是一个铺满全屏的
  // 径向渐变（半径动画、线宽恒定），元素本身不需要定位。
  const cx = window.innerWidth / 2;
  const cy = window.innerHeight * 0.46;
  for (const el of [burst, wash]) {
    if (!el) continue;
    el.style.setProperty("--bx", `${cx}px`);
    el.style.setProperty("--by", `${cy}px`);
  }

  return new Promise((resolve) => {
    setTimeout(() => {
      for (const el of [burst, wash]) {
        if (!el) continue;
        el.classList.remove("is-on");
        void el.offsetWidth;
        el.classList.add("is-on");
      }
      // 三拍：震屏。0.55 在 trauma 模型里属于"重击但不到顶"，
      // 留给以后更夸张的事件（比如真相揭晓）。
      addTrauma(0.55);
    }, IMPACT_MS);

    setTimeout(() => {
      rite.classList.add("is-done");
      setPlaqueState("spent");
      resolve();
    }, RITE_MS);
  });
}

/** 清掉一次性图层，免得它们挂在那儿。 */
export function clearBurst() {
  for (const id of ["ability-burst", "ability-wash"]) {
    document.getElementById(id)?.classList.remove("is-on");
  }
  document.getElementById("rite")?.classList.remove("is-on", "is-done");
}

export const timings = { RITE_MS, IMPACT_MS };
