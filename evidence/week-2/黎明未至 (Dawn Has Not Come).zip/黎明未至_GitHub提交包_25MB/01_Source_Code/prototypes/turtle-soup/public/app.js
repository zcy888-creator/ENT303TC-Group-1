/**
 * 黎明未至 · client.
 *
 * Thin on purpose: what the host answers, which page a question unlocks, how
 * the final three are graded and how many questions are left all happen on the
 * server. This file renders state and sends intent.
 *
 * The one thing it must never do is render a sealed page's text. A locked page
 * is drawn as redaction bars - NOT as blurred real text, because a CSS blur is
 * reversible straight out of devtools and would hand the player the sentence
 * they have not earned.
 */

import { stampScroll, retractScroll } from "./scroll.js";
import { openSettings, engineLabel } from "./settings.js";
import { skylineSvg } from "./skyline.js";

/**
 * 难度 → 哥特体拉丁词。
 *
 * 拉丁字段是 Grenze Gotisch（哥特体）唯一能发挥作用的地方 —— **中文没有哥特体**。
 * 所以卡面上要有一个拉丁词可写，"中英双语字标"也就顺理成章：
 * 那本来就是顶级中式游戏的通行做法（原神 / 明日方舟 / 黑神话都有），
 * 它同时给了哥特体一个真实的岗位和一层"做得讲究"的信息密度。
 *
 * 五档和题库里的 difficulty 字段一一对应，缺一个就会有一个词是空的。
 */
/**
 * 阿拉伯数字 → 罗马数字。
 *
 * 案号原本用中文数字（一 / 二 / 三）。中文数字读起来是"第几册"的目录感，
 * 而这个游戏是哥特探案 —— 罗马数字配哥特体才是对的味道，
 * 而且 Grenze Gotisch 渲染罗马数字特别有戏：I 的衬线、V 的断裂、X 的交叉。
 *
 * 题库上限 44（XLIV），四字符，卡面上放得下；再多就得换写法了。
 */
const ROMAN = [
  [1000, "M"], [900, "CM"], [500, "D"], [400, "CD"],
  [100, "C"], [90, "XC"], [50, "L"], [40, "XL"],
  [10, "X"], [9, "IX"], [5, "V"], [4, "IV"], [1, "I"],
];
function romanNumber(n) {
  let v = Math.max(1, Math.round(Number(n) || 1));
  if (v > 3999) return String(v);            // 罗马数字表达不了，退回阿拉伯
  let out = "";
  for (const [num, sym] of ROMAN) while (v >= num) { out += sym; v -= num; }
  return out;
}

const DIFFICULTY_EN = {
  "入门": "Novice",
  "简单": "Easy",
  "进阶": "Advanced",
  "困难": "Hard",
  "极难": "Severe",
};
import { setPlaqueState, playActivation, clearBurst } from "./ability.js";
import { createRoom } from "./room.js";

const $ = (id) => document.getElementById(id);

// The opening ritual is mounted at /draw/ by this same server, so the whole game
// is one origin. The trailing slash is required, not cosmetic: without it the
// browser treats /draw as a file and every relative path inside the ritual
// resolves against the origin root.
const DRAW_ORIGIN = new URLSearchParams(location.search).get("draw") || "/draw/";

// 档案库背景。canvas 元素一直躺在 DOM 里（#app 内），这里只挂上绘制器；
// 真正开画是在案件数据到位之后 —— 构图要用到书页宽度和命运色。
const room = (() => {
  const c = document.getElementById("room");
  return c ? createRoom(c) : null;
})();

const state = {
  sessionId: null,
  identity: null,
  host: null,
  caseData: null,
  points: 0,
  startingPoints: 50,
  busy: false,
  abilityUsed: false,
  unlocked: new Map(),   // clue id -> { page, text }
  final: null,
};

/* ------------------------------------------------------------------- net --- */

async function api(path, body) {
  const res = await fetch(path, {
    method: body ? "POST" : "GET",
    headers: {
      "Content-Type": "application/json",
      ...(state.sessionId ? { "x-session-id": state.sessionId } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
  return data;
}

/* ------------------------------------------------------------------ boot --- */

async function boot() {
  const params = new URLSearchParams(location.search);
  const identity = params.get("identity")
    || localStorage.getItem("tsg.identity")
    || "medium";
  localStorage.setItem("tsg.identity", identity);
  // Arriving with an identity in the URL means we came from the ritual, so the
  // archive can offer "draw again" rather than "draw" next time.
  if (params.get("identity")) localStorage.setItem("tsg.drawn", "1");

  const caseId = params.get("case");
  if (!caseId) return showLibrary();

  const b = await api(
    `/api/bootstrap?case=${encodeURIComponent(caseId)}&identity=${encodeURIComponent(identity)}`);
  state.sessionId = b.sessionId;
  state.identity = b.identity;
  state.host = b.host;
  state.points = b.points;
  state.startingPoints = b.startingPoints;
  state.caseData = b.case;
  state.unlocked = new Map();

  // The canonical title usually gives the answer away (融化的雪人, 53辆自行车),
  // so the investigation runs under the codename; the ending hands over the name.
  $("case-title").textContent = b.case.codename || b.case.title;
  const stars = "★".repeat(b.case.difficultyStars || 0);
  const tags = (b.case.tags || []).join(" · ");
  $("case-meta").textContent =
    `${b.case.difficulty} ${stars} · 共 ${b.case.clueCount} 页案卷${tags ? " · " + tags : ""}`;
  $("surface").textContent = b.case.surface;

  // 左页边距上竖排的卷宗编号。档案库用自己的声音报数（中文数字），
  // 和卷宗墙上的编号是同一套写法。
  const idx = (b.case.id || "").match(/^(\d+)/);
  $("margin-case").textContent = idx ? `卷 宗 · ${romanNumber(Number(idx[1]))}` : "卷 宗";

  // 档案库背景：canvas 画的（room.js）。在这一刻才开始画，因为它的构图
  // 依赖书页的宽度和命运色。
  room?.setAccent(state.identity?.uiAccent || "");
  room?.repaint();

  $("ident-en").textContent = b.identity.nameEn;
  $("ident-cn").textContent = b.identity.nameCn;
  $("ident-ability").textContent = `${b.identity.abilityCn} · ${b.identity.abilityEn}`;

  $("host-line").textContent = b.host.engine === "llm"
    ? `主持人：AI · ${b.host.provider}`
    : "主持人：离线匹配模式（未配置 LLM，回答会比较迟钝）";
  $("host-line").dataset.mode = b.host.engine;

  renderPoints();
  renderClues();
  // 技能牌回到"待发"。放在这里而不是只靠 HTML 上的 class：重新进入一局时，
  // 上一局的 "is-spent" 会留在 DOM 上，王牌就永远灰着了。
  setPlaqueState(state.abilityUsed ? "spent" : "ready");
  $("boot").hidden = true;
  $("app").hidden = false;
  // 案件页是普通文档流，必须摘掉锁视口的 class，否则正文会被 100vh 裁掉。
  // 而调查屏自己也是锁视口的（body.view-case）—— 见 style.css 的"调查阶段"一节。
  document.body.classList.remove("view-library");
  document.body.classList.add("view-case");
  // 兜底：卷轴只在"仪式 -> 卷宗墙"那一次交接里展开，而收卷写在 showLibrary 里。
  // 万一 from-ritual 漏到这里（比如书签带着 ?identity= 又带 ?case=），整块屏幕会
  // 被一张纸永久盖住 —— 那时候游戏已经不能玩了，所以这里直接把它摘掉。
  document.documentElement.classList.remove("from-ritual");
  document.getElementById("scroll")?.classList.remove("is-on", "is-open");

  // The prologue frames the case before the questioning starts.
  showPrologue(b);
}

/* ---------------------------------------------------------------- library -- */

// Guards the nightfall transition: without it a second click during the 1.5s
// veil would queue a second navigation.
let leaving = false;

// Case numbers are set in Chinese numerals on the wall - it is the archive's
// own voice, and it stops the card reading as a numbered list row.
const CN_DIGIT = ["零", "一", "二", "三", "四", "五", "六", "七", "八", "九"];


/** Where a card sits vertically. Deterministic, so the wall is stable across
 *  renders but is not a grid. */
/**
 * 手摆感的错落，但只留一点点。
 *
 * 原来它是 [0, 22, -10, 34, 8, -16] —— 相邻的卡上下差 34px。那在一条滚动的长页面
 * 里像"墙"，在锁住视口的网格里就是**没对齐**：卡片高低参差，底行还会被裁掉。
 * 收到 ±6px 之后还留着手工摆放的呼吸感，但网格读起来是整齐的。
 */
const dropFor = (i) => [0, 4, -3, 6, 2, -4][i % 6];

// The accent of the fate drawn in the ritual, carried into the archive.
let fateAccent = "";
// How long 黑夜降临 holds before the dossier opens.
const NIGHTFALL_MS = 2600;

/**
 * 黑夜降临 - committing to a case.
 *
 * This is the hinge of the game, so it is a sequence rather than a page swap:
 * the darkness opens from the folder you touched, a seal strikes down, the case
 * names itself, and only then does the dossier open. It also carries the same
 * accent as the fate you drew, so the archive and the ritual read as one room
 * going dark rather than as two unrelated pages.
 */
function openCase(c, card) {
  if (leaving) return;
  leaving = true;

  const box = card.getBoundingClientRect();
  const nf = $("nightfall");
  nf.style.setProperty("--nf-x", `${Math.round(box.left + box.width / 2)}px`);
  nf.style.setProperty("--nf-y", `${Math.round(box.top + box.height / 2)}px`);
  if (fateAccent) nf.style.setProperty("--fate", fateAccent);

  $("nf-title").textContent = c.codename || c.title;
  $("nf-meta").textContent =
    `${c.difficulty} ${"★".repeat(c.difficultyStars || 0)}`
    + (c.clueCount ? ` · 共 ${c.clueCount} 页案卷` : "");

  nf.hidden = false;
  // re-trigger the CSS animations, so choosing a second case replays the beat
  nf.classList.remove("is-on");
  void nf.offsetWidth;
  nf.classList.add("is-on");

  setTimeout(() => { location.href = `?case=${encodeURIComponent(c.id)}`; }, NIGHTFALL_MS);
}

/**
 * 顶栏那个齿轮。
 *
 * 放这里而不是塞进某个面板里：玩家第一次遇到"主持人怎么老是答无关"的时候，
 * 应该一眼能看到去哪儿改，而不是翻设置菜单。
 */
async function mountSettingsButton() {
  const host = document.getElementById("library-meta") || document.querySelector(".library-meta");
  if (!host || document.getElementById("settings-btn")) return;
  const b = document.createElement("button");
  b.id = "settings-btn";
  b.className = "btn btn-quiet btn-settings";
  b.type = "button";
  b.textContent = "主持人设置";
  b.addEventListener("click", () => openSettings());
  host.append(b);
  const label = await engineLabel();
  if (label) {
    const s = document.createElement("span");
    s.className = "meta engine-tag";
    s.textContent = label;
    host.append(s);
  }
}

async function showLibrary() {
  const data = await api("/api/cases");
  // 顶栏挂「主持人设置」入口。玩家觉得主持人答得不对劲时，得一眼看到去哪儿改。
  mountSettingsButton().catch(() => {});
  const grid = $("library-grid");
  grid.replaceChildren();

  /**
   * 天空的三层：云隙、地平线剪影、指针光。
   *
   * 挂一次就够 —— 它们都是 position: fixed，不属于任何一块内容。
   * 一条均匀的渐变不是"天"，是"渐变"；天需要云的缝隙和地平线上的东西。
   */
  const libEl = $("library");
  /**
   * ── 背景：**殿堂本身** ──────────────────────────────────────────────────
   *
   * 我原来给卷宗墙另画了一片 2D 的夜空 + 天际线。方向是错的：
   * 开局那座古堡殿堂（石柱、蓝玻璃高窗、壁灯、地面法阵）**已经是这个游戏的
   * 环境**，再画一个"别的地方"当背景，两边就不像同一个世界。
   *
   * 所以直接把殿堂垫在后面 —— 用 /draw/?bg=1 那个纯背景模式（同一个场景、
   * 同一套光、同一批柱子），走 iframe。quality 调低一档：它在后面只当背景，
   * 不值得占满 GPU。
   */
  if (libEl && !libEl.querySelector(".hall-bg")) {
    const hall = document.createElement("iframe");
    hall.className = "hall-bg";
    hall.src = "/draw/?bg=1&quality=0.7";
    hall.setAttribute("aria-hidden", "true");
    hall.setAttribute("tabindex", "-1");
    hall.setAttribute("scrolling", "no");
    libEl.append(hall);
    const scrim = document.createElement("div");
    scrim.className = "hall-scrim";
    scrim.setAttribute("aria-hidden", "true");
    libEl.append(scrim);
  }
  /**
   * ── 2D 天空撤了 ────────────────────────────────────────────────────────
   *
   * 这一整段（.atmosphere 画布、.sky-clouds、三层 .sky-layer 天际线、
   * 指针视差）是我为卷宗墙另画的背景。它本身做得不差，但**方向错了**：
   * 开局那座古堡殿堂已经是这个游戏的环境，再画一个"别的地方"当背景，
   * 两边就不像同一个世界了 —— 用户的判断是对的。
   *
   * 现在背景就是殿堂本体（.hall-bg iframe，走 /draw/?bg=1）。
   * 指针光留着：它和背景无关，是"这面墙对你有反应"。
   */
  if (libEl && !libEl.querySelector(".pointer-light")) {
    const d = document.createElement("div");
    d.className = "pointer-light";
    d.setAttribute("aria-hidden", "true");
    libEl.append(d);
    let px = 0, py = 0, queued = false;
    const flush = () => {
      queued = false;
      libEl.style.setProperty("--px", px + "px");
      libEl.style.setProperty("--py", py + "px");
    };
    libEl.addEventListener("pointermove", (e) => {
      px = e.clientX; py = e.clientY;
      if (!queued) { queued = true; requestAnimationFrame(flush); }
    }, { passive: true });
  }
  const total = data.cases.length;
  // 标题原来写死"经典案件十六则"，题库涨到 44 条之后就成了假话。
  // 让数字跟着数据走，改成"四十四"这样的中文数字，和卷宗墙的写法一致。
  const mc = $("masthead-count");
  if (mc) mc.textContent = String(total);
  const cultural = data.cases.filter((c) => c.requiresCulturalKnowledge).length;
  const filter = $("filter-culture");
  const setCount = () => {
    $("library-count").textContent = filter.checked
      ? `共 ${total - cultural} 个案件（已隐藏 ${cultural} 个需要文化背景的）`
      : `共 ${total} 个案件 · 难度 ★ 到 ★★★★★`;
  };
  filter.onchange = () => { grid.dataset.hideCulture = filter.checked ? "1" : "0"; setCount(); };
  grid.dataset.hideCulture = filter.checked ? "1" : "0";
  setCount();

  const mine = (data.identities || [])
    .find((i) => i.id === (localStorage.getItem("tsg.identity") || "medium"));
  const idLine = $("library-identity");
  if (mine) {
    // The archive wears the colour of the fate you drew, so it is a different
    // room depending on what you are carrying. Without this the draw ended at
    // the ritual and every case list looked identical.
    if (mine.uiAccent) {
      fateAccent = mine.uiAccent;
      document.documentElement.style.setProperty("--fate", fateAccent);
    }
    idLine.textContent = `${mine.nameCn} · ${mine.abilityCn}`;
    idLine.hidden = false;
  }

  // The door to the ritual. Without it the card draw is only reachable by
  // knowing the port, which is exactly how the game came to look like it had
  // no draw at all.
  const cta = $("draw-cta");
  cta.href = DRAW_ORIGIN;
  if (localStorage.getItem("tsg.drawn")) {
    cta.querySelector(".draw-cta-t").textContent = "重 抽 命 运";
    $("draw-cta-sub").textContent = "抽到不同身份，这一局的玩法会变";
  }

  let idx = 0;
  for (const c of data.cases) {    const card = document.createElement("article");
    card.className = "case-card";
    card.dataset.culture = c.requiresCulturalKnowledge ? "1" : "0";
    // 五色轮转撤了。参考图里"多色"是它的风格，而这里是暗黑 ——
    // 暗黑靠的是**近单色 + 一个强调色**，四十四张卡各自换颜色只会变热闹。
    card.style.setProperty("--i", String(idx));
    card.style.setProperty("--drop", `${dropFor(idx)}px`);
    idx++;

    // the whole folder is clickable, not just the link
    card.addEventListener("click", (ev) => {
      if (ev.target.closest(".case-hint")) return;   // let the 谜点 unfold
      openCase(c, card);
    });

    // this fate's mark, pressed onto the folder
    const seal = document.createElement("span");
    seal.className = "case-seal";
    seal.textContent = "卷";
    card.append(seal);

    const num = romanNumber(c.number || idx);
    // 扫光层：悬停时一道极淡的光从左上掠过。
    // game-feel 的分层原则 —— 抬起、描边亮起、案名提亮、数字点亮之外，
    // 再加一条"光扫过"的通道，各自用不同时长，才不会读成"只变了一下"。
    const sheen = document.createElement("span");
    sheen.className = "sheen";
    sheen.setAttribute("aria-hidden", "true");
    card.append(sheen);

    const no = document.createElement("span");
    no.className = "case-no";
    no.textContent = num;
    card.append(no);

    // 卡面不再有任何图形。
    //
    // 这里前后试过七轮：几何印记 → 档案夹色号 → 中式线装 → 二次元命牌 →
    // 星图 → 哥特花窗 → 黑暗证据墙。**每一轮都更差**，用户的判断是
    // "甚至不如最开始什么都不做的" —— 而这是对的。
    //
    // 最初那版之所以好，是因为它**克制**：细边框、深底、清楚的字、手摆的错落。
    // 我一直往上加装饰，把克制一层层拆掉，最后做成一片几乎全黑的墙，
    // 连卡片的边界都看不清了。
    //
    // 所以：不加图形。区分度交给案名、星级、标签和错落本身。



    const top = document.createElement("div");
    top.className = "case-top";
    const name = document.createElement("h2");
    name.className = "case-codename";
    name.textContent = c.codename || c.title;
    top.append(name);
    card.append(top);

    const n = c.difficultyStars || 0;
    const stars = document.createElement("p");
    stars.className = "case-stars";
    stars.textContent = "★".repeat(n);
    if (n < 5) {
      const off = document.createElement("span");
      off.className = "off";
      off.textContent = "☆".repeat(5 - n);
      stars.append(off);
    }
    const grade = document.createElement("span");
    grade.className = "grade";
    // 中文难度 + 一个哥特体拉丁词。
    // 拉丁字段是 Grenze Gotisch 唯一能发挥作用的地方 —— 中文没有哥特体，
    // 而"中英双语字标"本来就是顶级中式游戏的通行做法。
    grade.textContent = c.difficulty;
    const en = document.createElement("b");
    en.textContent = DIFFICULTY_EN[c.difficulty] || "";
    grade.append(en);
    stars.append(grade);

    const tags = document.createElement("ul");
    tags.className = "case-tags";
    for (const t of c.tags || []) {
      const li = document.createElement("li");
      li.textContent = t;
      tags.append(li);
    }

    // The 谜点 tempts you to pick the case, but it is also a hint - so it stays
    // folded away until asked for.
    const hint = document.createElement("details");
    hint.className = "case-hint";
    const sum = document.createElement("summary");
    sum.textContent = "谜点提示";
    const hp = document.createElement("p");
    hp.textContent = c.coreMystery || "—";
    hint.append(sum, hp);

    const foot = document.createElement("div");
    foot.className = "case-foot";
    if (c.requiresCulturalKnowledge) {
      const warn = document.createElement("p");
      warn.className = "case-warn";
      warn.textContent = "⚠ 需要一点海外文化背景";
      foot.append(warn);
    }
    const btn = document.createElement("button");
    btn.className = "case-open";
    btn.textContent = "开始调查";
    btn.addEventListener("click", (ev) => { ev.stopPropagation(); openCase(c, card); });
    foot.append(btn);

    // `top` and the number are already on the card
    card.append(stars, tags, hint, foot);
    grid.append(card);
  }

  $("boot").hidden = true;
  $("app").hidden = true;
  $("library").hidden = false;
  // 卷宗墙是锁住视口的游戏画面（页面本身不滚动，只有网格内部滚）。
  // 进入案子时要把这个 class 摘掉，否则案件页会被 100vh 裁掉。
  document.body.classList.remove("view-case");
  document.body.classList.add("view-library");

  // ---- 开卷：卷轴收回去，露出已经铺好的卷宗墙 ------------------------------
  //
  // 顺序很关键：**先在帘子后面把卷宗墙铺好，再开帘**。第一版把收卷放在函数开头，
  // 于是卷轴退开时露出的是还没隐藏的开场屏（"卷 / 正在开启卷宗"），然后才"啪"地
  // 换成卷宗墙 —— 等于把一次转场拆成了两次闪烁。
  //
  // 印记用的是服务端 IDENTITIES 的同一份数据（nameCn / nameEn / abilityCn），
  // 仪式页印的是 characters.js 的对应字段；两边必须指向同一个人，否则会出现
  // "卷轴上写着医师、进去却是灵媒"。
  if (document.documentElement.classList.contains("from-ritual")) {
    const mineForStamp = (data.identities || [])
      .find((i) => i.id === (localStorage.getItem("tsg.identity") || "medium"));
    if (mineForStamp) {
      stampScroll({
        nameCn: mineForStamp.nameCn,
        nameEn: mineForStamp.nameEn,
        skillCn: mineForStamp.abilityCn,
        skillEn: mineForStamp.abilityEn,
        accent: mineForStamp.uiAccent,
      });
    }
    await retractScroll();
  }
}

/* --------------------------------------------------------------- prologue -- */

function showPrologue(b) {
  const c = b.case;
  $("prologue-title").textContent = `《${c.codename || c.title}》`;
  const body = $("prologue-body");
  body.replaceChildren();

  const block = (label, nodes) => {
    const l = document.createElement("p");
    l.className = "lbl";
    l.textContent = label;
    body.append(l);
    for (const n of nodes) body.append(n);
  };
  const para = (t) => { const p = document.createElement("p"); p.textContent = t; return p; };
  const bullets = (items) => {
    const ul = document.createElement("ul");
    for (const t of items) { const li = document.createElement("li"); li.textContent = t; ul.append(li); }
    return ul;
  };

  block("发生了什么", [para(c.surface)]);
  block("你为什么会在这里", [para(
    "有人死了，或者有人做了一件没人能解释的事。卷宗被封在这里，"
    + "知情的人只肯回答「是」或「否」——一句多余的话都不肯说。")]);
  block("你的任务", [para(
    "在提问次数用完之前，把这件事真正的经过还原出来。"
    + "问对了方向，封死的书页会一页页显形；问到最后，你要面对最终三问。")]);
  block("你手上的东西", [bullets([
    `一份 ${c.clueCount} 页的案卷，其中大部分还是一片模糊`,
    `${b.identity.nameCn}的身份，以及它带来的那一次能力`,
    `${state.points} 次提问机会——每问一句少一次`,
  ])]);

  const dlg = $("prologue");
  if (!dlg.open) dlg.showModal();
}

/* --------------------------------------------------------------- render ---- */

function renderPoints() {
  $("points").textContent = state.points;
  const pct = Math.max(0, Math.min(1, state.points / state.startingPoints));
  $("points-fill").style.width = (pct * 100).toFixed(1) + "%";
  const fill = $("points-fill");
  fill.dataset.low = pct < 0.2 ? "1" : "0";
  // 提问次数是这一局唯一的资源，也是全部压力的来源。它必须会变脸：
  // 正常 / 吃紧（<40%）/ 告急（<15%）。只把数字改小，玩家感觉不到自己在消耗什么。
  const counter = $("counter");
  counter.dataset.state = pct < 0.15 ? "critical" : pct < 0.4 ? "low" : "ok";
  // 每次扣减都让数字顿一下 —— 重排动画，保证连续提问时每一下都打得出来
  counter.dataset.bump = "1";
  clearTimeout(renderPoints._t);
  renderPoints._t = setTimeout(() => { counter.dataset.bump = "0"; }, 800);
}

function renderClues(freshIds = []) {
  const n = state.caseData?.clueCount || 0;
  const list = $("clues");
  list.replaceChildren();

  for (let i = 1; i <= n; i++) {
    const id = "k" + i;
    const got = state.unlocked.get(id);
    const li = document.createElement("li");
    li.className = "clue";
    li.dataset.locked = got ? "0" : "1";
    if (freshIds.includes(id)) li.dataset.fresh = "1";

    const top = document.createElement("div");
    top.className = "clue-top";
    const page = document.createElement("span");
    page.className = "clue-page";
    // Sealed pages show a neutral slot number; the real heading (验尸记录,
    // 现场照片…) is itself part of what gets revealed.
    page.textContent = got ? got.page : `第 ${i} 页`;
    const lock = document.createElement("span");
    lock.className = "clue-lock";
    lock.textContent = got ? "已显形" : "未显形";
    top.append(page, lock);
    li.append(top);

    if (got) {
      const p = document.createElement("p");
      p.className = "clue-text";
      p.textContent = got.text;
      li.append(p);
    } else {
      // Redaction bars. The sentence is not in the DOM at all. The seal is the
      // only ornament, and it marks the page as deliberately closed.
      const a = document.createElement("span");
      a.className = "redact";
      const bBar = document.createElement("span");
      bBar.className = "redact short";
      const seal = document.createElement("span");
      seal.className = "seal-mini";
      seal.textContent = "封";
      li.append(a, bBar, seal);
    }
    list.append(li);
  }
  $("clue-count").textContent = `${state.unlocked.size} / ${n}`;
}

function addEntry(entry, revealed = []) {
  const li = document.createElement("li");
  li.className = "entry is-new";
  li.dataset.verdict = entry.verdict;

  const num = document.createElement("span");
  num.className = "entry-n";
  num.textContent = String(entry.n).padStart(2, "0");

  const q = document.createElement("span");
  q.className = "entry-q";
  q.textContent = entry.question;

  const a = document.createElement("span");
  a.className = "entry-a";
  a.textContent = entry.verdict;
  if (entry.note) a.title = entry.note;

  li.append(num, q, a);
  if (entry.note) {
    const note = document.createElement("span");
    note.className = "entry-note";
    note.textContent = entry.note;
    li.append(note);
  }
  if (revealed.length) {
    const got = document.createElement("span");
    got.className = "entry-got";
    got.textContent = `✦ 书页显形 · ${revealed.map((r) => r.page).join("、")}`;
    li.append(got);
  }
  $("log").prepend(li);
  $("log-count").textContent = `${$("log").children.length} 条`;
  // is-new 的意思是"刚到的这一条"，只用来触发盖章动画。摘掉它，样式里的静止角度
  // 才是最终状态 —— 否则这个 class 会一直挂着，语义也就没了。
  setTimeout(() => li.classList.remove("is-new"), 700);
}

/* -------------------------------------------------------------------- ask -- */

$("ask-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  if (state.busy) return;
  const input = $("ask-input");
  const question = input.value.trim();
  if (!question) return;

  state.busy = true;
  $("ask-btn").disabled = true;
  $("ask-btn").textContent = "…";
  // 主持人"开始思考" —— 这一屏原来在整个请求往返期间完全静止，玩家不知道
  // 是在等回复还是卡住了。徽记脉动是最便宜、也最不打扰的等待反馈。
  const host = $("host-presence");
  host?.classList.add("is-thinking");
  host?.classList.remove("verdict-yes", "verdict-no");
  try {
    const r = await api("/api/ask", { question });
    if (r.exhausted && !r.entry) {
      addEntry({ n: $("log").children.length + 1, question, verdict: "—", note: r.message });
    } else {
      input.value = "";
      const revealed = r.unlocked || [];
      addEntry(r.entry, revealed);
      state.points = r.points;
      renderPoints();

      // 回答落下的那一刻，徽记闪一下，颜色跟着判决走
      host?.classList.remove("is-thinking");
      if (r.entry?.verdict === "是") host?.classList.add("verdict-yes");
      else if (r.entry?.verdict === "否") host?.classList.add("verdict-no");

      if (revealed.length) {
        for (const u of revealed) state.unlocked.set(u.id, u);
        renderClues(revealed.map((u) => u.id));
        // Bring the page that just opened into view.
        const idx = Number(String(revealed[0].id).slice(1));
        const el = $("clues").children[idx - 1];
        el?.scrollIntoView({ block: "nearest", behavior: "smooth" });
      }
      if (r.exhausted) {
        addEntry({ n: $("log").children.length + 1, question: "（提问已用尽）",
                   verdict: "—", note: "只能进入最终审判了。" });
      }
      if (r.degraded) {
        $("host-line").textContent = "主持人：AI 调用失败，已临时降级为离线匹配";
      }
    }
  } catch (err) {
    addEntry({ n: $("log").children.length + 1, question, verdict: "错误", note: err.message });
  } finally {
    state.busy = false;
    host?.classList.remove("is-thinking");
    $("ask-btn").disabled = false;
    $("ask-btn").textContent = "提问";
    $("ask-input").focus();
  }
});

/* ---------------------------------------------------------------- ability -- */

const ABILITY_FORMS = {
  witness: () => `<label>向谁提问<input id="ab-char" placeholder="角色名，如 酒保"></label>
                  <label>问什么<input id="ab-q" placeholder="你当时看到了什么？"></label>`,
  extra_questions: () => `<p class="hint">向主持人争取 10 次额外的提问机会。</p>`,
  evidence: () => `<p class="hint">验一次物证，会给出本案的一条物理事实。</p>`,
  directions: () => `<p class="hint">星盘会指出三个值得追的方向。</p>`,
  recall: () => `<p class="hint">重读你自己最关键的几次提问。</p>`,
};

$("ability-btn").addEventListener("click", async () => {
  const box = $("ability-out");
  if (state.abilityUsed) { box.hidden = false; box.textContent = "本局已经用过了。"; return; }
  const kind = state.identity.ability;
  box.hidden = false;
  box.innerHTML = `<div class="ab-form">${ABILITY_FORMS[kind]?.() || ""}
      <button id="ab-go" class="btn">确认发动</button></div>
      <p class="hint" id="ab-err"></p>`;

  $("ab-go").addEventListener("click", async () => {
    const args = {};
    if (kind === "witness") {
      args.character = $("ab-char")?.value.trim();
      args.question = $("ab-q")?.value.trim();
    }
    try {
      const r = await api("/api/ability", { args });
      if (!r.ok) {
        $("ab-err").textContent = r.error + (r.options ? `（可选：${r.options.join("、")}）` : "");
        return;
      }
      state.abilityUsed = true;

      // 演出必须在结果**之前**：先把技能牌蓄力、爆闪、作废，再把答案作为一张
      // 案卷页放进去。反过来的话玩家只会看到内容换了一下，闪光全被盖住。
      $("ab-go").disabled = true;
      await playActivation();

      box.innerHTML = `<p class="ab-title">${r.result.title}</p><pre class="ab-body">${
        escapeHtml(formatAbility(r.result))}</pre>
        <button class="btn ab-close" id="ab-close">收 起</button>`;
      $("ab-close")?.addEventListener("click", () => { box.hidden = true; });
      // 结果落定之后再收掉一次性图层，免得冲击波一直挂着
      setTimeout(clearBurst, 400);

      // The detective's ability changes the budget, so the counter must move -
      // and say so loudly, because that is the whole point of the identity.
      if (r.points !== undefined && r.points !== state.points) {
        state.points = r.points;
        renderPoints();
        const c = $("counter");
        c.dataset.bump = "1";
        setTimeout(() => { c.dataset.bump = "0"; }, 800);
      }
      if (r.result.unlockClue) {
        state.unlocked.set(r.result.unlockClue.id, r.result.unlockClue);
        renderClues([r.result.unlockClue.id]);
      }
    } catch (err) { $("ab-err").textContent = err.message; }
  });
});

function formatAbility(r) {
  if (r.ability === "witness") return `你问「${r.character}」：${r.question}\n\n他说：${r.reply}`;
  if (r.ability === "extra_questions") {
    return `${r.note}\n\n提问次数上限被推高了，但真相没有变近——只是你多了一点时间。`;
  }
  if (r.ability === "evidence") {
    return `${r.evidence.text}${r.evidence.detail ? "\n\n" + r.evidence.detail : ""}`;
  }
  if (r.ability === "directions") {
    const rows = (r.directions || []).map((d) => `${d.label}　${d.hint}`);
    return rows.join("\n") + (r.note ? "\n\n" + r.note : "");
  }
  if (r.ability === "recall") {
    const rows = (r.recalled || []).map((x) =>
      `${String(x.n).padStart(2, "0")}　${x.question}　→　${x.verdict}${x.unlocked ? "　✦" : ""}`);
    return (rows.length ? rows.join("\n") : "（还没有可以回溯的提问）")
      + (r.note ? "\n\n" + r.note : "");
  }
  return JSON.stringify(r, null, 2);
}

/* ---------------------------------------------------------- final judgement */

$("solve-btn").addEventListener("click", () => {
  const qs = state.caseData?.finalQuestions || [];
  const wrap = $("final-questions");
  wrap.replaceChildren();
  $("final-err").textContent = "";

  qs.forEach((q, i) => {
    const box = document.createElement("div");
    box.className = "fq";

    const qp = document.createElement("p");
    qp.className = "fq-q";
    qp.dataset.n = `第${["一", "二", "三"][i]}问`;
    qp.textContent = q.question;
    box.append(qp);

    const opts = document.createElement("div");
    opts.className = "fq-opts";
    q.options.forEach((text, j) => {
      const label = document.createElement("label");
      label.className = "fq-opt";
      const input = document.createElement("input");
      input.type = "radio";
      input.name = q.id;
      input.value = String(j);
      input.addEventListener("change", () => {
        for (const sib of opts.children) sib.dataset.picked = "0";
        label.dataset.picked = "1";
      });
      const span = document.createElement("span");
      span.textContent = text;
      label.append(input, span);
      opts.append(label);
    });
    box.append(opts);
    wrap.append(box);
  });

  $("final").showModal();
});

$("final-cancel").addEventListener("click", () => $("final").close());

$("final-submit").addEventListener("click", async () => {
  const qs = state.caseData?.finalQuestions || [];
  const answers = qs.map((q) => {
    const picked = document.querySelector(`input[name="${q.id}"]:checked`);
    return picked ? Number(picked.value) : -1;
  });
  if (answers.some((a) => a < 0)) {
    $("final-err").textContent = "三问都要作答，才能进入审判。";
    return;
  }
  $("final-submit").disabled = true;
  try {
    const written = $("solve-text").value.trim();
    const r = await api("/api/final", { answers, answer: written });
    $("final").close();
    showEnding(r);
  } catch (err) {
    $("final-err").textContent = err.message;
  } finally {
    $("final-submit").disabled = false;
  }
});

/* ------------------------------------------------------------------ ending */

const TIER = { dawn: "黎明已至", night: "黎明未至" };

function showEnding(r) {
  // 黎明已至要**真的天亮**：太阳从地平线露头、光柱放射、同一座城逆光成剪影。
  // 复用卷宗墙那套天际线模块 —— 那边是"天没亮"，这边是"天刚亮"，
  // 同一座城，同一套代码，只换配色和光。
  const endEl = $("ending");
  if (endEl && !endEl.querySelector(".dawn-sun")) {
    for (const cls of ["dawn-rays", "dawn-sun", "dawn-city"]) {
      const d = document.createElement("div");
      d.className = cls;
      d.setAttribute("aria-hidden", "true");
      endEl.append(d);
    }
    const city = endEl.querySelector(".dawn-city");
    if (city) {
      // 逆光：城压在亮起来的天上，所以只要一层，而且是最深的颜色
      city.innerHTML = skylineSvg({
        seed: 20260813, depth: "near", fill: "#04050a", window: "#ffcf82",
      });
    }
  }
  const res = r.result;
  const tier = TIER[res.ending] || "审判结束";
  $("ending-tier").textContent = tier;
  // The whole ending screen re-lights itself: 黎明已至 warms, 黎明未至 stays cold.
  $("ending").dataset.tier = res.ending;
  $("ending-eyebrow").textContent = res.ending === "dawn" ? "ENDING · 黎明已至" : "ENDING · 黎明未至";

  // The tier is the gate; the authored copy below it is graded on how close
  // the player actually got, so a 2/3 reads differently from a 0/3.
  const key = res.right === res.total ? "true" : res.right >= res.total - 1 ? "good" : "bad";
  $("ending-text").textContent = r.endings?.[key] || "";

  $("final-right").textContent = `${res.right}/${res.total}`;
  $("clue-progress").textContent = `${res.cluesFound}/${res.clueCount}`;
  $("questions-used").textContent = String(res.questionsUsed);

  // the three questions, marked
  const review = $("final-review");
  review.replaceChildren();
  for (const g of res.graded) {
    const li = document.createElement("li");
    li.dataset.ok = g.correct ? "1" : "0";
    const q = document.createElement("div");
    q.textContent = g.question;
    const picked = document.createElement("div");
    picked.className = "picked";
    picked.textContent = `你选了：${g.options[g.picked] ?? "（未作答）"}`;
    li.append(q, picked);
    if (!g.correct) {
      const right = document.createElement("div");
      right.className = "right";
      right.textContent = `正确：${g.options[g.answer]}`;
      li.append(right);
    }
    review.append(li);
  }

  // optional written reconstruction
  const w = res.written;
  $("written-wrap").hidden = !w;
  $("score-wrap").hidden = !w;
  if (w) {
    $("score-num").textContent = w.score;
    fill($("hit-list"), w.hits.map((h) => h.text), "（一条都没命中）");
    fill($("miss-list"), w.missing.map((m) => m.text), "（没有遗漏）");
    const wrong = w.wrongClaims || [];
    $("wrong-wrap").hidden = wrong.length === 0;
    fill($("wrong-list"), wrong, "");
  }

  $("truth-text").textContent = r.truth;
  fill($("truth-timeline"), r.timeline.map((t) => t.event), "");
  fill($("truth-clues"), (r.clues || []).map((k) => `${k.page}　${k.text}`), "");
  fill($("truth-facts"), r.keyHiddenFacts, "");

  if (res.written?.engine === "fallback") {
    $("ending-text").textContent += "（还原度由离线匹配完成，未配置 LLM）";
  }
  if (r.title) {
    $("ending-title").textContent = `《${r.title}》`;
    $("case-title").textContent = r.title;
  }

  $("ending").hidden = false;
  window.scrollTo(0, 0);
}

function fill(el, items, empty) {
  el.innerHTML = "";
  if (!items.length && empty) {
    const li = document.createElement("li");
    li.textContent = empty;
    el.append(li);
    return;
  }
  for (const t of items) {
    const li = document.createElement("li");
    li.textContent = t;
    el.append(li);
  }
}
const escapeHtml = (s) => String(s).replace(/[&<>]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" }[c]));

/* ------------------------------------------------------------------- misc -- */

$("prologue-go").addEventListener("click", () => {
  $("prologue").close();
  $("ask-input").focus();
});

$("again-btn").addEventListener("click", () => {
  localStorage.removeItem("tsg.identity");
  location.href = "/";
});

/* ------------------------------------------------------------------- go ----- */

boot().catch(async (err) => {
  console.error(err);
  try {
    await showLibrary();
    $("library-count").textContent = "这个案件打不开：" + err.message;
  } catch {
    $("boot").textContent = "卷宗打不开：" + err.message;
  }
});
