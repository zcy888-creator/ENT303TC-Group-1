/**
 * 档案库背景 —— 用 canvas 画出来。
 *
 * ── 为什么不再用 CSS 渐变 ────────────────────────────────────────────────
 * 上一版用 `repeating-linear-gradient` 堆出"架子"，用户的原话是"看不出来是啥"。
 * 他说得对：那条指令**只能画出等宽的条纹**，画不出"一排书"。
 *
 * 背景之所以读成背景，靠三样东西，缺一不可：
 *
 *   1. **一个个有差异的物体** —— 书要有不同的宽、高、颜色，有的歪、有的缺
 *   2. **真实的光照** —— 灯是暖色、有衰减；离灯远的地方暗；书架顶部被照亮
 *   3. **景深** —— 背景是失焦的。这一条最省事也最有效：先把画面画在**一半分辨率**
 *      上再让浏览器放大，天然就是柔的；形状上的粗糙也一并被藏掉。
 *
 * 这三样 CSS 渐变一样都给不了，canvas 三样都给得了。
 *
 * 画完不保留任何状态，只在尺寸变化时重画一次。
 */

/** 确定性随机。背景必须每次刷新都一样，否则"档案库"会显得像在闪。 */
function mulberry32(a) {
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** 书脊的颜色：暗紫、褐、墨绿，全部压在低明度里 —— 它们只是背景。 */
const SPINES = [
  [58, 48, 78], [46, 40, 62], [72, 56, 60], [40, 46, 58],
  [64, 52, 44], [50, 44, 70], [44, 54, 52], [68, 50, 62],
];

const rgba = (c, a) => `rgba(${c[0]},${c[1]},${c[2]},${a})`;

/**
 * 画一侧的墙。
 * @param {CanvasRenderingContext2D} g
 * @param {-1|1} side  -1 = 左墙，1 = 右墙
 * @param {number} innerX  靠书页那一侧的 x
 * @param {number} outerX  屏幕边缘那一侧的 x
 */
function drawWall(g, side, innerX, outerX, H, rand) {
  const bandW = Math.abs(innerX - outerX);
  if (bandW < 30) return;

  const ROWS = 7;
  const rowH = H / ROWS;
  const dir = side;                         // 从 outer 往 inner 推进的方向

  for (let r = 0; r < ROWS; r++) {
    const boardY = r * rowH;

    // ---- 隔板：一块有厚度的板，顶面被灯照亮 ----
    g.fillStyle = "rgba(18,15,28,0.92)";
    g.fillRect(Math.min(innerX, outerX), boardY, bandW, rowH * 0.10);
    g.fillStyle = "rgba(232,214,180,0.10)";   // 顶面的受光边
    g.fillRect(Math.min(innerX, outerX), boardY, bandW, 1.2);

    // ---- 这一层的书 ----
    // 从屏幕边缘（远）往书页（近）摆。越靠外越暗：这是"离灯越来越远"，
    // 也是让两只书架读成两条**纵深**而不是两条平面的关键。
    let d = 0;
    while (d < bandW - 4) {
      const gap = rand() < 0.13 ? 3 + rand() * 7 : 0.8;   // 偶尔留个空位
      d += gap;
      if (d >= bandW - 4) break;

      const w = 3 + rand() * 10;
      if (d + w > bandW - 2) break;

      const hFrac = 0.42 + rand() * 0.52;                 // 高矮不一
      const h = rowH * 0.90 * hFrac;
      const x = outerX + dir * d;
      const x0 = Math.min(x, x + dir * w);
      const y0 = boardY + rowH * 0.10 - h;

      // 纵深：靠近书页的一侧亮，靠屏幕边缘的一侧沉下去
      const near = 1 - d / bandW;
      const shade = 0.30 + near * 0.70;

      const col = SPINES[Math.floor(rand() * SPINES.length)];
      g.fillStyle = rgba(col, shade);
      g.fillRect(x0, y0, w, h);

      // 书脊上的高光：一条竖直的窄亮带，位置随机 —— 这一笔最能把"矩形"
      // 变成"一本书"，因为它的位置差异读成圆书脊的漫反射。
      g.fillStyle = rgba([236, 228, 210], shade * (0.05 + rand() * 0.11));
      g.fillRect(x0 + w * (0.18 + rand() * 0.28), y0, Math.max(0.7, w * 0.16), h);

      // 顶部一道压暗，让书从隔板上"立起来"
      g.fillStyle = "rgba(0,0,0,0.35)";
      g.fillRect(x0, y0, w, Math.min(1.5, h * 0.06));

      // 偶尔一本歪着靠在邻居身上
      if (rand() < 0.07) {
        g.save();
        g.translate(x0 + w / 2, y0 + h);
        g.rotate(dir * (0.10 + rand() * 0.10));
        g.fillStyle = rgba(col, shade * 0.9);
        g.fillRect(-w / 2, -h, w, h);
        g.restore();
      }

      d += w;
    }
  }
}

/** 壁灯：暖色、有衰减、叠加发光。 */
function drawLamp(g, x, y, r, strength) {
  const grd = g.createRadialGradient(x, y, 0, x, y, r);
  grd.addColorStop(0, `rgba(255,226,170,${0.55 * strength})`);
  grd.addColorStop(0.28, `rgba(224,178,110,${0.20 * strength})`);
  grd.addColorStop(1, "rgba(224,178,110,0)");
  g.save();
  g.globalCompositeOperation = "lighter";
  g.fillStyle = grd;
  g.fillRect(x - r, y - r, r * 2, r * 2);
  g.restore();
}

export function createRoom(canvas) {
  let raf = null;
  let accent = "#b98cff";

  function paint() {
    raf = null;
    const cssW = canvas.clientWidth || window.innerWidth;
    const cssH = canvas.clientHeight || window.innerHeight;

    // 一半分辨率 = 天然柔化（见文件开头第 3 条）。背景不需要锐利，
    // 而 0.5x 让形状上的粗糙一并消失，代价还只有四分之一。
    const W = Math.max(320, Math.round(cssW / 2));
    const H = Math.max(240, Math.round(cssH / 2));
    canvas.width = W;
    canvas.height = H;

    const g = canvas.getContext("2d");
    const rand = mulberry32(20260813);

    // 底：夜里的石室，冷色，底部微微透出命运色
    const base = g.createLinearGradient(0, 0, 0, H);
    base.addColorStop(0, "#0b0916");
    base.addColorStop(0.6, "#080711");
    base.addColorStop(1, "#0c0a16");
    g.fillStyle = base;
    g.fillRect(0, 0, W, H);

    // 书页占的宽度（和 CSS 的 --book-w 同源，这里再算一次）
    const bookW = Math.min(1560, cssW * 0.82) / 2;
    const cx = W / 2;
    const innerL = cx - bookW / 2;
    const innerR = cx + bookW / 2;

    drawWall(g, -1, innerL, 0, H, rand);
    drawWall(g, 1, innerR, W, H, rand);

    // 壁灯：两侧各两盏，位置和 CSS 里那套一致（书页边缘外 48px 处，半分辨率）
    g.save();
    g.globalAlpha = 0.9;
    drawLamp(g, innerL - 48, H * 0.30, W * 0.16, 1.0);
    drawLamp(g, innerR + 48, H * 0.30, W * 0.16, 1.0);
    drawLamp(g, innerL - 48, H * 0.72, W * 0.13, 0.62);
    drawLamp(g, innerR + 48, H * 0.72, W * 0.13, 0.62);
    g.restore();

    // 灯下的一小片地面反光
    g.save();
    g.globalCompositeOperation = "lighter";
    const warm = g.createRadialGradient(cx, H * 1.04, 0, cx, H * 1.04, W * 0.42);
    warm.addColorStop(0, "rgba(180,150,255,0.10)");
    warm.addColorStop(1, "rgba(180,150,255,0)");
    g.fillStyle = warm;
    g.fillRect(0, 0, W, H);
    g.restore();

    // 远近层次：书页左右留出清楚的一段，再往外逐渐沉进黑暗。
    // 和 CSS 里那条 linear-gradient 是同一个意图，但这里作用在**画好的墙**上。
    const fade = g.createLinearGradient(0, 0, W, 0);
    const fl = innerL / W, fr = innerR / W;
    fade.addColorStop(0, "rgba(0,0,0,0.72)");
    fade.addColorStop(Math.max(0, fl - 0.06), "rgba(0,0,0,0.16)");
    fade.addColorStop(Math.max(0, fl), "rgba(0,0,0,0)");
    fade.addColorStop(Math.min(1, fr), "rgba(0,0,0,0)");
    fade.addColorStop(Math.min(1, fr + 0.06), "rgba(0,0,0,0.16)");
    fade.addColorStop(1, "rgba(0,0,0,0.72)");
    g.fillStyle = fade;
    g.fillRect(0, 0, W, H);

    // 上下压暗
    const vg = g.createLinearGradient(0, 0, 0, H);
    vg.addColorStop(0, "rgba(0,0,0,0.66)");
    vg.addColorStop(0.20, "rgba(0,0,0,0)");
    vg.addColorStop(0.78, "rgba(0,0,0,0)");
    vg.addColorStop(1, "rgba(0,0,0,0.70)");
    g.fillStyle = vg;
    g.fillRect(0, 0, W, H);
  }

  const schedule = () => { if (raf === null) raf = requestAnimationFrame(paint); };

  window.addEventListener("resize", schedule);
  // 字体/布局稳定之后再画一次，避免首次 clientWidth 是 0
  schedule();

  return {
    setAccent(a) { if (a) { accent = a; schedule(); } },
    repaint: schedule,
    destroy() { window.removeEventListener("resize", schedule); if (raf) cancelAnimationFrame(raf); },
  };
}
