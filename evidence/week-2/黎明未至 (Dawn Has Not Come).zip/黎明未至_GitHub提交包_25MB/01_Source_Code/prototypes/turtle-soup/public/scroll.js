/**
 * 开卷 —— 两页共用的转场驱动。
 *
 * 动画本身全在 scroll.css 里（靠 @property --open + transition 驱动），这里只负责
 * 一件事：**什么时候加哪个 class**。这样仪式页和卷宗页不会各自写一套时间轴而漂移。
 *
 * 时序（毫秒，和 CSS 里的 620ms 对应）：
 *
 *   仪式页  0    盖上卷轴（--open 0，轴在正中合拢）
 *          30   开始展开  --open 0 → 1
 *          620  展开完毕
 *          760  停顿（纸面上的印记已经浮现）
 *          900  跳转
 *
 *   卷宗页  0    第一帧就是展开状态（.from-ritual 在 <head> 里加的，早于首次绘制）
 *          240  收卷  --open 1 → 0
 *          860  卷轴收尽、淡出
 */

/** 展开的总时长，跳转要等它走完。和 scroll.css 的 transition 保持一致。 */
export const UNFURL_MS = 620;
export const HOLD_MS = 420;

const reduced = () =>
  window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

function el() {
  return document.getElementById("scroll");
}

/** 把身份信息印到纸面上。两个页面都调用，保证印的是同一份东西。 */
export function stampScroll({ nameCn, nameEn, skillCn, skillEn, accent }) {
  const box = el();
  if (!box) return;
  const set = (sel, text) => {
    const n = box.querySelector(sel);
    if (n) n.textContent = text || "";
  };
  set(".scroll-name", nameCn);
  set(".scroll-name-en", nameEn);
  set(".scroll-skill", [skillCn, skillEn].filter(Boolean).join("  ·  "));
  if (accent) box.style.setProperty("--fate", accent);
}

/**
 * 仪式页：展开卷轴把画面盖住。
 * @returns {Promise<void>} 盖满并停顿之后 resolve —— 调用方此时再跳转。
 */
export function unfurlScroll() {
  const box = el();
  if (!box) return Promise.resolve();
  if (reduced()) { box.classList.add("is-on", "is-open"); return Promise.resolve(); }

  box.classList.add("is-on");
  // 先让它以"合拢"的状态上屏一帧，再开始展开。不加这一帧，浏览器会把
  // is-on 和 is-open 合并成一次样式计算，展开动画就完全看不到了。
  return new Promise((resolve) => {
    requestAnimationFrame(() => requestAnimationFrame(() => {
      box.classList.add("is-open");
      setTimeout(resolve, UNFURL_MS + HOLD_MS);
    }));
  });
}

/**
 * 卷宗页：从展开状态把卷轴收回去，露出下面的卷宗墙。
 * @returns {Promise<void>} 收尽之后 resolve。
 */
export function retractScroll() {
  const box = el();
  if (!box) return Promise.resolve();
  if (reduced()) {
    box.classList.remove("is-on", "is-open");
    document.documentElement.classList.remove("from-ritual");
    return Promise.resolve();
  }
  return new Promise((resolve) => {
    // 第一帧保持展开（.from-ritual 已经在 head 里加好了），停顿一下再收
    setTimeout(() => {
      document.documentElement.classList.remove("from-ritual");
      box.classList.add("is-on");
      box.classList.remove("is-open");
      setTimeout(() => { box.classList.remove("is-on"); resolve(); }, UNFURL_MS + 240);
    }, 240);
  });
}
