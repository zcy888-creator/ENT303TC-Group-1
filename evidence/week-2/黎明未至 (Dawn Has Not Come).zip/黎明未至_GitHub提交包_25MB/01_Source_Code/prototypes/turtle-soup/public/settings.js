/**
 * 设置面板：让玩家在界面里填 API key。
 *
 * ── 为什么需要 ──────────────────────────────────────────────────────────
 * 原来 key 只能靠环境变量传。让一个来玩游戏的人去「Win 键搜环境变量 →
 * 用户变量 → 新建三条」是不合理的 —— 那不是玩家该做的事，而且大概率会放弃，
 * 于是只能玩离线模式（判定会钝很多）。
 *
 * ── 设计上的几个决定 ────────────────────────────────────────────────────
 *
 * **只让填一个 key。** 地址和模型都给了默认值（DeepSeek），折叠在"高级"里。
 * 填得越少，填完的概率越高。
 *
 * **填完立刻测一次。** 玩家真正想知道的是"填对了没有"，不是"填了没有"。
 * 光存下来不验证，等于把失败推迟到他第一次提问的时候。
 *
 * **绝不显示完整的 key。** 只显示头尾（sk-abc…xyz），让他确认填的是不是
 * 他以为的那个。完整值只在输入框里、且是 password 类型。
 *
 * **明确告诉对方"填完能玩什么"。** 不填也能玩，只是主持人会钝一些 ——
 * 这句话必须写在面板上，否则玩家会以为不填就打不开。
 */
const $ = (id) => document.getElementById(id);

let dialog = null;
let lastStatus = null;

/** 面板的 DOM。第一次打开时才建，避免给首屏增加节点。 */
function ensureDialog() {
  if (dialog) return dialog;

  dialog = document.createElement("dialog");
  dialog.className = "sheet settings-sheet";
  dialog.id = "settings";
  dialog.innerHTML = `
    <div class="sheet-inner">
      <p class="eyebrow">HOST · 主持人</p>
      <h2 class="sheet-title">AI 主持人设置</h2>
      <p class="note" id="set-state">正在读取…</p>

      <label class="set-row">
        <span class="set-label">API Key</span>
        <input id="set-key" type="password" autocomplete="off" spellcheck="false"
               placeholder="sk-..." />
      </label>
      <p class="note set-hint" id="set-keyhint"></p>

      <details class="set-adv">
        <summary>高级</summary>
        <label class="set-row">
          <span class="set-label">接口地址</span>
          <input id="set-base" type="text" autocomplete="off" spellcheck="false" />
        </label>
        <label class="set-row">
          <span class="set-label">模型</span>
          <input id="set-model" type="text" autocomplete="off" spellcheck="false" />
        </label>
      </details>

      <p class="note" id="set-msg"></p>

      <div class="sheet-actions">
        <button class="btn btn-quiet" id="set-cancel">关闭</button>
        <button class="btn btn-quiet" id="set-clear">清除</button>
        <button class="btn btn-seal" id="set-save">保存并测试</button>
      </div>
    </div>`;
  document.body.append(dialog);

  $("set-cancel").addEventListener("click", () => dialog.close());
  $("set-clear").addEventListener("click", async () => {
    await save({ apiKey: "", baseUrl: $("set-base").value.trim(), model: $("set-model").value.trim() });
  });
  $("set-save").addEventListener("click", async () => {
    const key = $("set-key").value.trim();
    const baseUrl = $("set-base").value.trim();
    const model = $("set-model").value.trim();
    // 输入框是空的、但本来就有 key（环境变量或者上次填的）→ 只更新地址，不动 key
    const patch = key || !lastStatus?.hasKey ? { apiKey: key } : {};
    if (baseUrl) patch.baseUrl = baseUrl;
    if (model) patch.model = model;
    await save(patch, true);
  });

  return dialog;
}

async function save(patch, test = false) {
  const msg = $("set-msg");
  msg.textContent = "保存中…";
  msg.className = "note";
  try {
    const r = await fetch("/api/settings", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(patch),
    });
    const s = await r.json();
    if (s.error) throw new Error(s.error);
    apply(s);

    if (!s.hasKey) { msg.textContent = "已清除。游戏会用离线匹配，仍然能玩。"; return; }
    if (!test) { msg.textContent = "已保存。"; return; }

    // 真正有价值的那一步：**当场验证 key 能不能用**。
    // 只存不验，等于把失败推迟到他第一次提问的时候。
    msg.textContent = "正在测试…";
    const t = await (await fetch("/api/settings/test", { method: "POST" })).json();
    if (t.ok) {
      msg.textContent = `可以用（${t.ms} 毫秒 · ${t.provider}）`;
      msg.className = "note ok";
    } else {
      msg.textContent = "连不上：" + t.error;
      msg.className = "note err";
    }
  } catch (err) {
    msg.textContent = "出错：" + (err.message || err);
    msg.className = "note err";
  }
}

function apply(s) {
  lastStatus = s;
  $("set-base").value = s.baseUrl || "";
  $("set-model").value = s.model || "";
  $("set-key").value = "";
  $("set-key").placeholder = s.hasKey ? "已设置（留空则不改动）" : "sk-...";
  $("set-keyhint").textContent = s.hasKey
    ? `当前：${s.keyHint}${s.fromEnv ? " · 来自环境变量，改这里不会覆盖它" : ""}`
    : "";
  $("set-state").textContent = s.hasKey
    ? "主持人走在线模型，回答更灵活。"
    : "现在用的是离线匹配：能玩，判定准确，但主持人只会做关键词匹配，"
      + "遇到绕一点的说法会答「无关」。填一个 API key 会明显变好。";
}

/** 打开面板。 */
export async function openSettings() {
  const d = ensureDialog();
  d.showModal();
  try {
    apply(await (await fetch("/api/settings")).json());
  } catch {
    $("set-state").textContent = "读不到设置。";
  }
}

/** 给顶栏用：当前引擎是什么。 */
export async function engineLabel() {
  try {
    const s = await (await fetch("/api/settings")).json();
    return s.engine === "llm" ? "在线主持人" : "离线主持人";
  } catch {
    return "";
  }
}
