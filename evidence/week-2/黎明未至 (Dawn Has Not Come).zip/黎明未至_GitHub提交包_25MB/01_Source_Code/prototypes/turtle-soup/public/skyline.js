/**
 * 黎明前的城。
 *
 * ── 上一版为什么像柱状图 ────────────────────────────────────────────────
 * 它是一条单层的路径：等宽的方块 + 三角顶，间隔均匀。那不是城，是柱状图。
 *
 * ── 顶级大厂做天际线的四条 ──────────────────────────────────────────────
 *   1. **纵深分层** —— 三到四层，越远越亮、反差越低（大气透视）。
 *      全部压成一层黑，再好看的轮廓也是贴纸。
 *   2. **不规则节奏** —— 成组的楼、留白、高低错落。等距排列 = 图表。
 *   3. **一个主塔** —— 必须有一样东西明显高于其他（教堂尖顶），
 *      视线才有落点，剪影才有"这是哪儿"。
 *   4. **几扇亮着的窗** —— 天亮之前，总有几户人家还没睡。
 *      这一笔最便宜，也最能让一座城"活着"。
 *
 * 三层各自是一个 SVG，由 app.js 叠起来，各自用不同的视差速度。
 */

/** 确定性随机：同一座城每次刷新一模一样（不能跳）。 */
function rng(seed) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const W = 1200;   // viewBox 宽
const H = 200;    // viewBox 高（底边对齐）

/**
 * 一层屋顶线。
 *
 * @param {number} seed
 * @param {object} o
 * @param {number} o.minH  最矮的楼
 * @param {number} o.maxH  最高（不含主塔）
 * @param {number} o.gap   楼间距的基准
 * @param {boolean} o.chimneys 画不画烟囱
 * @param {boolean} o.hero 这一层有没有主塔
 * @param {boolean} o.windows 亮不亮窗
 */
function layer(seed, { minH, maxH, gap, chimneys, hero, windows }) {
  const r = rng(seed);
  const d = [];          // 轮廓路径段
  const extras = [];     // 烟囱、亮窗

  // 主塔的位置：略偏左或偏右，不要正中 —— 正中太对称，像徽章不像城
  const heroX = (0.28 + r() * 0.44) * W;
  const heroHalf = 26 + r() * 16;

  let x = -20;
  while (x < W + 20) {
    // 成组：连着几栋高度接近的楼，然后留一个空档。
    // 均匀排布是图表，成组排布才是城。
    const groupN = 2 + Math.floor(r() * 4);
    const groupBase = minH + r() * (maxH - minH) * 0.55;

    for (let i = 0; i < groupN && x < W + 20; i++) {
      const bw = 26 + r() * 62;
      let bh = groupBase + r() * (maxH - groupBase);
      const isHero = hero && Math.abs(x + bw / 2 - heroX) < bw / 2 + heroHalf;

      if (isHero) bh = maxH + 34 + r() * 26;

      const top = H - bh;
      const roof = r();

      // 楼身
      d.push(`M${x.toFixed(1)} ${H} L${x.toFixed(1)} ${top.toFixed(1)}`);

      if (isHero) {
        // 主塔：尖顶 + 两侧小尖角，教堂钟楼的做法
        d.push(`L${(x - 5).toFixed(1)} ${top.toFixed(1)}`);
        d.push(`L${(x + bw / 2).toFixed(1)} ${(top - 46).toFixed(1)}`);
        d.push(`L${(x + bw + 5).toFixed(1)} ${top.toFixed(1)}`);
      } else if (roof < 0.34) {
        d.push(`L${(x + bw / 2).toFixed(1)} ${(top - 12 - r() * 14).toFixed(1)}`);
      } else if (roof < 0.52) {
        // 折顶（孟莎式）：先内收再上斜
        const inset = bw * 0.18;
        d.push(`L${(x + inset).toFixed(1)} ${(top - 6).toFixed(1)}`);
        d.push(`L${(x + bw - inset).toFixed(1)} ${(top - 6).toFixed(1)}`);
      }
      d.push(`L${(x + bw).toFixed(1)} ${top.toFixed(1)}`);
      d.push(`L${(x + bw).toFixed(1)} ${H}`);

      // 烟囱：高点，细，偶尔冒一点烟
      if (chimneys && r() < 0.45 && bh > minH + 8) {
        const cw = 5 + r() * 5;
        const cx = x + bw * (0.15 + r() * 0.7);
        const ch = 8 + r() * 16;
        const cy = top - ch;
        extras.push(`M${cx.toFixed(1)} ${cy.toFixed(1)} h${cw.toFixed(1)} v${ch.toFixed(1)} h${(-cw).toFixed(1)} Z`);
      }

      // 亮着的窗：只在最近的那层画，而且要稀疏 —— 满楼亮灯就成了夜景壁纸
      if (windows && !isHero && bw > 34 && bh > minH + 14 && r() < 0.5) {
        const n = 1 + Math.floor(r() * 3);
        for (let k = 0; k < n; k++) {
          const wx = x + 8 + r() * (bw - 18);
          const wy = top + 12 + r() * (bh - 30);
          if (wy > H - 14) continue;
          extras.push({ x: wx, y: wy, w: 4.5, h: 6.5 });
        }
      }

      x += bw;
    }
    x += gap * (0.5 + r() * 1.8);      // 空档本身也是随机的
  }

  return { outline: d.join(" ") + ` L${W + 20} ${H} Z`, extras };
}

/**
 * @param {object} o
 * @param {number} o.seed
 * @param {"far"|"mid"|"near"} o.depth
 * @param {string} o.fill
 * @param {string} [o.window]  亮窗的颜色（只有 near 层会用）
 */
export function skylineSvg({ seed, depth, fill, window: win }) {
  const CFG = {
    // 越远：越矮、越平、越少细节、颜色越接近天空（大气透视）
    far: { minH: 16, maxH: 40, gap: 22, chimneys: false, hero: false, windows: false, off: 101 },
    mid: { minH: 28, maxH: 74, gap: 30, chimneys: true, hero: false, windows: false, off: 137 },
    near: { minH: 40, maxH: 108, gap: 46, chimneys: true, hero: true, windows: true, off: 211 },
  }[depth];

  const { outline, extras } = layer(seed + CFG.off, CFG);
  const parts = [`<path d="${outline}" fill="${fill}"/>`];

  for (const e of extras) {
    if (typeof e === "string") {
      parts.push(`<path d="${e}" fill="${fill}"/>`);
    } else if (win) {
      parts.push(`<rect x="${e.x.toFixed(1)}" y="${e.y.toFixed(1)}" width="${e.w}" height="${e.h}"`
        + ` rx="0.6" fill="${win}" opacity="${(0.5 + (e.x % 7) / 20).toFixed(2)}"/>`);
    }
  }

  return `<svg viewBox="0 0 ${W} ${H}" xmlns="http://www.w3.org/2000/svg"`
    + ` preserveAspectRatio="none" aria-hidden="true">${parts.join("")}</svg>`;
}
