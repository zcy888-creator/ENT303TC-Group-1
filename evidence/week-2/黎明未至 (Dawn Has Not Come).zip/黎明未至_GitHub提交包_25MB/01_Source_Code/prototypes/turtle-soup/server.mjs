/**
 * 海龟汤 MVP server.
 *
 * This is the TRUST BOUNDARY. The canonical truth lives here and is never sent
 * to the browser until the player has committed to a final answer; if the case
 * JSON were served statically, anyone could open devtools and read the 汤底.
 *
 *   GET  /api/bootstrap           case surface + identity + host status
 *   POST /api/ask                 { question }        -> 是 / 否 / 无关 / 部分正确
 *   POST /api/ability             { args }            -> identity ability result
 *   POST /api/truth               { answer }          -> score, ending, full truth
 *
 * Session state (points, history, ability used, seen lists) is kept server-side
 * too, keyed by a session id, so the client cannot grant itself extra questions.
 *
 * Usage: node server.mjs          (PORT / HOST env override)
 */
import http from "node:http";
import { readFile, writeFile, mkdir, stat, readdir } from "node:fs/promises";
import path from "node:path";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";

import { createLlm } from "./server/llm.mjs";
import { writeSettings, effectiveEnv, settingsForClient } from "./server/settings.mjs";
import { answerQuestion } from "./server/host.mjs";
import { judgeAnswer } from "./server/judge.mjs";
import { useAbility, IDENTITIES, identityById } from "./server/abilities.mjs";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const PUBLIC = path.join(HERE, "public");
const CASES = path.join(HERE, "cases");

/**
 * The opening ritual, mounted into this server.
 *
 * fate-draw began life as a sibling prototype on its own port, which meant the
 * game was really two sites joined by a link: the draw lived at :4190 and the
 * cases at :4200. They are one game, so they are now one origin - the ritual is
 * served under /draw from here, and it hands back to / on the same origin.
 *
 * Its asset paths are absolute (/card-back.png, /card-layers/...), so those are
 * mapped too rather than rewriting the ritual's code.
 */
const FATE = path.join(HERE, "..", "fate-draw");
const CARD_ART = path.join(HERE, "..", "identity-cards");

function resolveRitual(rel) {
  if (rel === "/draw" || rel === "/draw/") return path.join(FATE, "index.html");
  if (rel.startsWith("/draw/")) {
    const rest = rel.slice("/draw/".length);
    if (rest.startsWith("src/") || rest.startsWith("public/") || rest.startsWith("node_modules/")) {
      return path.join(FATE, rest);
    }
    return null;
  }
  if (rel === "/card-back.png") return path.join(FATE, "public", "card-back.png");
  const m = rel.match(/^\/card-layers\/card-(\d{2})\/(.+)$/);
  if (m) return path.join(CARD_ART, `card-${m[1]}`, "web", "assets", m[2]);
  return null;
}
const PORT = Number(process.env.PORT || 4200);
const HOST = process.env.HOST || "127.0.0.1";

/**
 * LLM 适配器。
 *
 * `let` 而不是 `const`：玩家在界面里填了 key 之后要**当场生效**，不能要求他
 * 重启软件 —— 对一个玩游戏的人来说，"改完还要重启"就是"改了没用"。
 * 环境变量优先于本地设置文件（开发时行为不变），下游一个入口读。
 */
let llm = createLlm(effectiveEnv());
function reloadLlm() { llm = createLlm(effectiveEnv()); }

/* ------------------------------------------------------------------- cases -- */

const caseCache = new Map();
// A case id arrives straight from a query parameter (?case=...), so it must
// never be interpolated into a filesystem path unchecked: "?case=../../secret"
// would otherwise read any file on disk.
const CASE_ID_RE = /^[a-z0-9][a-z0-9-]{0,63}$/;

async function loadCase(id) {
  if (typeof id !== "string" || !CASE_ID_RE.test(id)) {
    throw Object.assign(new Error("unknown case"), { code: "ENOENT" });
  }
  if (caseCache.has(id)) return caseCache.get(id);
  const file = path.join(CASES, `${id}.json`);
  const data = JSON.parse(await readFile(file, "utf8"));
  data.evidence = data.evidence || [];
  caseCache.set(id, data);
  return data;
}

/**
 * The library listing. Metadata only - the surface and the truth are never
 * included, so browsing the archive cannot spoil a case.
 */
let caseIndex = null;
async function listCases() {
  if (caseIndex) return caseIndex;
  const files = (await readdir(CASES)).filter((f) => f.endsWith(".json") && f !== "index.json");
  const out = [];
  for (const f of files) {
    try {
      const c = JSON.parse(await readFile(path.join(CASES, f), "utf8"));
      out.push({
        id: c.id,
        number: c.number,
        codename: c.codename,
        title: c.title,
        titleEn: c.titleEn,
        difficulty: c.difficulty,
        difficultyStars: c.difficultyStars,
        estimatedQuestions: c.estimatedQuestions,
        tags: c.tags || [],
        coreMystery: c.coreMystery || "",
        clueCount: (c.clues || []).length,
        requiresCulturalKnowledge: !!c.requiresCulturalKnowledge,
      });
    } catch {
      // One malformed case must not take the whole library down.
    }
  }
  out.sort((a, b) => (a.number || 0) - (b.number || 0));
  caseIndex = out;
  return out;
}

const DEFAULT_CASE = process.env.TSG_CASE || "001-turtle-soup";

/* ---------------------------------------------------------------- sessions -- */

const STARTING_POINTS = Number(process.env.TSG_POINTS || 50);
const sessions = new Map();

function newSession(identityId, caseId) {
  const id = crypto.randomUUID();
  const s = {
    id, caseId,
    identityId,
    points: STARTING_POINTS,
    startingPoints: STARTING_POINTS,
    history: [],          // { n, question, verdict, note, engine, unlocked }
    abilityUsed: false,
    abilityResult: null,
    seen: { evidence: [], timeline: [], clue: [] },
    unlockedClues: [],    // ids of book pages the player has made legible
    final: null,          // { right, total, ending, graded }
    stage: "investigating",   // investigating | revealed
    result: null,
  };
  sessions.set(id, s);
  return s;
}

function publicCase(c) {
  // Everything the player is allowed to know BEFORE submitting.
  return {
    id: c.id,
    number: c.number,
    // The real title often gives the answer away (融化的雪人, 53辆自行车), so
    // during the investigation the case is known only by its codename. `title`
    // travels too, but the client must not paint it until the ending screen.
    codename: c.codename || c.title,
    title: c.title,
    titleEn: c.titleEn,
    difficulty: c.difficulty,
    difficultyStars: c.difficultyStars,
    estimatedQuestions: c.estimatedQuestions,
    tags: c.tags || [],
    requiresCulturalKnowledge: !!c.requiresCulturalKnowledge,
    surface: c.surface,
    // How many book pages exist. The TEXT of a locked page never travels - it
    // is the thing the player is trying to earn, so exposing it here would let
    // anyone read the whole case out of devtools on load.
    clueCount: (c.clues || []).length,
    // The three questions travel; which option is CORRECT does not. The client
    // renders them and posts indices back, and the answer never leaves here.
    finalQuestions: (c.finalQuestions || []).map((q) => ({
      id: q.id, question: q.question, options: q.options,
    })),
    characters: c.characters.map((ch) => ({ name: ch.name, identity: ch.identity, alive: ch.alive !== false })),
  };
}

const clip = (s, n) => (typeof s === "string" ? s.slice(0, n) : "");

function json(res, code, body) {
  const data = JSON.stringify(body);
  res.writeHead(code, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" });
  res.end(data);
}

async function readBody(req, limit = 32 * 1024) {
  let size = 0;
  const chunks = [];
  for await (const c of req) {
    size += c.length;
    if (size > limit) throw new Error("body too large");
    chunks.push(c);
  }
  if (!chunks.length) return {};
  try { return JSON.parse(Buffer.concat(chunks).toString("utf8")); }
  catch { throw new Error("invalid JSON body"); }
}

function sessionFor(req, res, body) {
  const sid = req.headers["x-session-id"] || body.sessionId;
  const s = sid ? sessions.get(sid) : null;
  if (!s) { json(res, 409, { error: "session expired or missing" }); return null; }
  return s;
}

/* ------------------------------------------------------------------ routes -- */

async function api(req, res, url) {
  const route = url.pathname;

  /**
   * ── 设置：让玩家在界面里填 key ──────────────────────────────────────────
   *
   * GET  返回**有没有 key**、以及 baseUrl/model 现在是什么。**绝不回 key 本身** ——
   *      浏览器能拿到的东西，玩家截图发出去就泄了。
   * POST 存下来并**当场重建 LLM 适配器**，不用重启软件。
   *
   * 存到 %APPDATA%，不存游戏目录：便携版可能被解压到只读的地方。
   */
  if (route === "/api/settings" && req.method === "GET") {
    return json(res, 200, { ...settingsForClient(), engine: llm.configured ? "llm" : "fallback" });
  }

  if (route === "/api/settings" && req.method === "POST") {
    let body;
    try {
      // readBody 内部已经 JSON.parse 过了，直接拿对象 —— 再 parse 一次会抛错
      body = await readBody(req);
    } catch {
      return json(res, 400, { error: "请求格式不对" });
    }
    const patch = {};
    if (typeof body.apiKey === "string") patch.apiKey = body.apiKey.trim();
    if (typeof body.baseUrl === "string") patch.baseUrl = body.baseUrl.trim();
    if (typeof body.model === "string") patch.model = body.model.trim();
    if (!writeSettings(patch)) {
      return json(res, 500, { error: "写不进设置文件，检查一下 %APPDATA% 的权限" });
    }
    reloadLlm();
    return json(res, 200, { ...settingsForClient(), engine: llm.configured ? "llm" : "fallback" });
  }

  /**
   * 试一下 key 到底能不能用。
   *
   * 光看"填了没有"没意义 —— 玩家最需要知道的是"填对了没有"。
   * 打一次最小的请求，把真实的报错原样带回去。
   */
  if (route === "/api/settings/test" && req.method === "POST") {
    if (!llm.configured) return json(res, 200, { ok: false, error: "还没填 key" });
    try {
      const t0 = Date.now();
      await llm.complete({ system: "只回一个字的'好'。", user: "在吗", maxTokens: 8 });
      return json(res, 200, { ok: true, ms: Date.now() - t0, provider: llm.provider });
    } catch (err) {
      return json(res, 200, { ok: false, error: String(err.message || err).slice(0, 300) });
    }
  }

  if (route === "/api/cases" && req.method === "GET") {
    // identities travel with the index so the archive can confirm which fate
    // the player drew before they pick a case.
    return json(res, 200, { cases: await listCases(), default: DEFAULT_CASE, identities: IDENTITIES });
  }

  if (route === "/api/bootstrap" && req.method === "GET") {
    const caseId = url.searchParams.get("case") || DEFAULT_CASE;
    let c;
    try {
      c = await loadCase(caseId);
    } catch {
      return json(res, 404, { error: `没有这个案件：${caseId}` });
    }
    const identityId = url.searchParams.get("identity") || "medium";
    const s = newSession(identityById(identityId).id, caseId);
    return json(res, 200, {
      sessionId: s.id,
      identity: identityById(s.identityId),
      identities: IDENTITIES,
      points: s.points,
      startingPoints: s.startingPoints,
      case: publicCase(c),
      host: {
        // The client is told which host is live so the UI never pretends.
        engine: llm.configured ? "llm" : "fallback",
        provider: llm.provider,
      },
    });
  }

  if (route === "/api/ask" && req.method === "POST") {
    const body = await readBody(req);
    const s = sessionFor(req, res, body); if (!s) return;
    if (s.stage !== "investigating") return json(res, 409, { error: "本局已结束，先开新的一局" });

    const question = clip(body.question, 400).trim();
    if (!question) return json(res, 400, { error: "问题不能为空" });
    if (s.points <= 0) {
      return json(res, 200, {
        verdict: null, exhausted: true, points: 0,
        message: "提问次数已用尽，只能进入最终审判了。",
      });
    }

    const c = await loadCase(s.caseId);
    const allClues = c.clues || [];
    const locked = allClues.filter((k) => !s.unlockedClues.includes(k.id));

    const out = await answerQuestion({
      caseData: c, question, history: s.history, llm, lockedClues: locked,
    });

    s.points -= 1;

    // The reward: a question that genuinely touched a sealed page makes that
    // page legible. This is what separates the game from a chat box - without
    // it, a correct question earns you the word "是" and nothing else.
    const revealed = [];
    if (out.unlock && !s.unlockedClues.includes(out.unlock)) {
      const k = allClues.find((x) => x.id === out.unlock);
      if (k) {
        s.unlockedClues.push(k.id);
        revealed.push({ id: k.id, page: k.page, text: k.text });
      }
    }

    const entry = {
      n: s.history.length + 1,
      question,
      verdict: out.verdict,
      note: out.note || "",
      engine: out.engine,
      degraded: !!out.degraded,
      unlocked: revealed.map((r) => r.id),
    };
    s.history.push(entry);

    return json(res, 200, {
      entry,
      points: s.points,
      exhausted: s.points <= 0,
      degraded: !!out.degraded,
      unlocked: revealed,
      cluesFound: s.unlockedClues.length,
      clueCount: allClues.length,
    });
  }

  if (route === "/api/ability" && req.method === "POST") {
    const body = await readBody(req);
    const s = sessionFor(req, res, body); if (!s) return;
    if (s.stage !== "investigating") return json(res, 409, { error: "本局已结束" });
    if (s.abilityUsed) return json(res, 409, { error: "本局的身份能力已经用过了", result: s.abilityResult });

    const c = await loadCase(s.caseId);
    const args = body.args && typeof body.args === "object" ? body.args : {};
    const r = await useAbility({
      identityId: s.identityId, caseData: c,
      args: { ...args, seen: s.seen.evidence.concat(s.seen.timeline, s.seen.clue) },
      history: s.history, llm,
    });
    if (!r.ok) return json(res, 200, { ok: false, error: r.error, options: r.options });

    s.abilityUsed = true;
    s.abilityResult = r;
    // remember what was surfaced so a repeat never hands out the same thing
    if (r.evidence) s.seen.evidence.push(r.evidence.id);
    if (r.node) s.seen.timeline.push(r.node.id);
    if (r.clue) s.seen.clue.push(r.clue.id);

    // Some abilities change your RESOURCES rather than hand you information -
    // the detective simply buys more questions. That is what makes an identity
    // matter for a whole run instead of one moment.
    if (r.grantPoints) s.points += r.grantPoints;
    // Others reach into the book and force a page open.
    if (r.unlockClue && !s.unlockedClues.includes(r.unlockClue.id)) {
      s.unlockedClues.push(r.unlockClue.id);
    }

    return json(res, 200, {
      ok: true, result: r, points: s.points,
      cluesFound: s.unlockedClues.length,
    });
  }

  if (route === "/api/final" && req.method === "POST") {
    const body = await readBody(req);
    const s = sessionFor(req, res, body); if (!s) return;
    if (s.stage !== "investigating") return json(res, 409, { error: "本局已结束，先开新的一局" });

    const c = await loadCase(s.caseId);
    const qs = c.finalQuestions || [];
    const answers = Array.isArray(body.answers) ? body.answers.map(Number) : [];
    if (qs.length && answers.length !== qs.length) {
      return json(res, 400, { error: `最终三问要全部作答（共 ${qs.length} 题）` });
    }

    const graded = qs.map((q, i) => ({
      id: q.id,
      question: q.question,
      options: q.options,
      answer: q.answer,
      picked: Number.isInteger(answers[i]) ? answers[i] : -1,
      correct: Number(answers[i]) === q.answer,
    }));
    const right = graded.filter((g) => g.correct).length;
    // 黎明已至 only when all three land. Anything less is 黎明未至 - but the
    // truth is revealed either way, because the payoff of 海龟汤 is finding out.
    const ending = qs.length > 0 && right === qs.length ? "dawn" : "night";

    // Optional extra: write the whole truth in your own words. This does not
    // gate the ending, it only rates how completely you actually got there.
    const written = clip(body.answer, 3000).trim();
    const judged = written.length >= 10
      ? await judgeAnswer({ caseData: c, answer: written, llm })
      : null;

    s.stage = "revealed";
    s.final = { right, total: qs.length, ending, graded };

    // Only NOW does the truth cross the wire.
    return json(res, 200, {
      result: {
        right, total: qs.length, ending, graded,
        cluesFound: s.unlockedClues.length,
        clueCount: (c.clues || []).length,
        questionsUsed: s.history.length,
        pointsLeft: s.points,
        written: judged,
      },
      truth: c.truth,
      surface: c.surface,
      codename: c.codename,
      title: c.title,
      endings: c.endings,
      timeline: c.timeline,
      characters: c.characters.map((ch) => ({ name: ch.name, identity: ch.identity })),
      keyHiddenFacts: c.keyHiddenFacts.map((f) => f.fact),
      clues: (c.clues || []).map((k) => ({ id: k.id, page: k.page, text: k.text })),
      pointsLeft: s.points,
      questionsUsed: s.history.length,
      history: s.history,
    });
  }

  if (route === "/api/truth" && req.method === "POST") {
    const body = await readBody(req);
    const s = sessionFor(req, res, body); if (!s) return;
    const answer = clip(body.answer, 3000).trim();
    if (answer.length < 10) return json(res, 400, { error: "把你的推理写得再具体一点（至少 10 个字）" });

    const c = await loadCase(s.caseId);
    const judged = await judgeAnswer({ caseData: c, answer, llm });
    s.stage = "revealed";
    s.result = judged;

    // Only NOW does the truth cross the wire.
    return json(res, 200, {
      result: judged,
      truth: c.truth,
      surface: c.surface,
      endings: c.endings,
      timeline: c.timeline,
      characters: c.characters.map((ch) => ({ name: ch.name, identity: ch.identity })),
      keyHiddenFacts: c.keyHiddenFacts.map((f) => f.fact),
      pointsLeft: s.points,
      questionsUsed: s.history.length,
      history: s.history,
    });
  }

  // ---------------------------------------------------------------- /api/shot --
  // Development-only frame capture.
  //
  // The ritual's art was authored while blind: headless Chrome cannot start in
  // this sandbox (it dies creating mojo named pipes), so the only camera that
  // exists is the player's own browser. /draw/?shots=1 renders the storyboard
  // offscreen and POSTs each frame here, and it lands on disk to be looked at.
  //
  // Off unless TSG_SHOTS=1, because a game that ships with an arbitrary
  // file-write endpoint is a game that ships a hole. The packaged build runs
  // without the flag, so this route is dead code in anything the player gets.
  if (route === "/api/shot" && req.method === "POST") {
    if (process.env.TSG_SHOTS !== "1") return json(res, 403, { error: "frame capture is off (start the server with TSG_SHOTS=1)" });
    const body = await readBody(req, 14 * 1024 * 1024);
    const m = /^data:image\/png;base64,([A-Za-z0-9+/=]+)$/.exec(String(body.data || ""));
    if (!m) return json(res, 400, { error: "expected a png data URL" });
    const png = Buffer.from(m[1], "base64");
    // Two fixed destinations only - never a caller-supplied path.
    const dir = body.where === "draw" ? path.join(FATE, "shots") : path.join(HERE, "shots");
    await mkdir(dir, { recursive: true });
    const tag = String(body.tag || "frame").replace(/[^A-Za-z0-9_-]/g, "").slice(0, 40) || "frame";
    const name = `live_${tag}_${Date.now()}.png`;
    await writeFile(path.join(dir, name), png);
    console.log(`  shot        : ${path.join(dir, name)} (${(png.length / 1024).toFixed(0)} KB)`);
    return json(res, 200, { ok: true, file: name, bytes: png.length });
  }

  return json(res, 404, { error: "unknown api route" });
}

/* ------------------------------------------------------------------ static -- */

const TYPES = {
  ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8",
  ".mjs": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8", ".png": "image/png",
  ".svg": "image/svg+xml", ".woff2": "font/woff2", ".ico": "image/x-icon",
};

http.createServer(async (req, res) => {
  const url = new URL(req.url, "http://localhost");
  try {
    if (url.pathname.startsWith("/api/")) return await api(req, res, url);

    let rel = decodeURIComponent(url.pathname);

    // Trailing slash matters here. The ritual's index.html loads
    // "./src/main.js", and "/draw" without the slash is treated as a FILE, so
    // every relative path resolved against the origin root (/src/main.js) and
    // the app never booted.
    if (rel === "/draw") {
      // Carry the query string over - a bare "/draw/" drops ?seed / ?t and the
      // ritual silently starts in live mode instead of the requested frame.
      res.writeHead(301, { Location: `/draw/${url.search || ""}` });
      return res.end();
    }

    // the ritual first, so /draw/ and its assets resolve before the archive
    const ritual = resolveRitual(rel);
    if (ritual) {
      const resolved = path.resolve(ritual);
      const allowed = [path.resolve(FATE), path.resolve(CARD_ART)];
      if (!allowed.some((a) => resolved.startsWith(a))) {
        res.writeHead(403); return res.end("Forbidden");
      }
      if ((await stat(resolved)).isDirectory()) return await serveFile(path.join(resolved, "index.html"), res);
      return await serveFile(resolved, res);
    }

    if (rel === "/") rel = "/index.html";
    const file = path.resolve(path.join(PUBLIC, rel));
    if (!file.startsWith(PUBLIC)) { res.writeHead(403); return res.end("Forbidden"); }
    if ((await stat(file)).isDirectory()) return await serveFile(path.join(file, "index.html"), res);
    return await serveFile(file, res);
  } catch (err) {
    if (url.pathname.startsWith("/api/")) return json(res, 500, { error: String(err.message || err) });
    res.writeHead(404); res.end("Not found");
  }
}).listen(PORT, HOST, () => {
  console.log(`海龟汤 MVP: http://${HOST}:${PORT}`);
  console.log(`  host engine : ${llm.configured ? "LLM · " + llm.provider : "OFFLINE fallback (set TSG_LLM_API_KEY to enable the real host)"}`);
  console.log(`  case        : ${DEFAULT_CASE}`);
});

async function serveFile(file, res) {
  const data = await readFile(file);
  res.writeHead(200, {
    "Content-Type": TYPES[path.extname(file)] || "application/octet-stream",
    "Cache-Control": "no-cache",
  });
  res.end(data);
}
