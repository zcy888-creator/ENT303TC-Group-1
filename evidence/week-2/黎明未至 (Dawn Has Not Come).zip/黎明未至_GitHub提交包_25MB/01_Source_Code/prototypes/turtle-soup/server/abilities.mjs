/**
 * Identity abilities.
 *
 * Server-side, because every one of them can surface truth and the client must
 * never be trusted with that.
 *
 * Each is a distinct MECHANIC, not a recoloured duplicate, so re-pointing them
 * later is a data change rather than a rewrite:
 *
 *   extra_questions - the detective simply buys more questions (+10)
 *   witness         - name a character, hear only what THAT character knew
 *   evidence        - surface one physical fact from the case's evidence list
 *   directions      - three bearings: the topic of three key facts, not answers
 *   recall          - mark the three past questions that actually moved the case
 *
 * The first is deliberately a RESOURCE change rather than an information
 * handout: an identity that alters how long you get to play changes the whole
 * run, where one that reveals a single fact is spent in a moment.
 *
 * All five are once per game.
 */

/**
 * `uiAccent` is the colour the ARCHIVE takes on when you arrive carrying this
 * fate. It is derived from the character's palette in
 * fate-draw/src/characters.js (violet / brass / ivory / blue / crimson) but
 * tuned to read as an accent on the archive's dark ground - the physician's
 * ivory, for instance, is a lovely light colour and a useless accent, so it
 * becomes a lit jade here.
 *
 * Without this the draw ended at the ritual: you picked a fate, and then the
 * case list looked identical no matter what you were carrying.
 */
export const IDENTITIES = [
  { id: "medium",     nameEn: "THE MEDIUM",     nameCn: "灵媒",   ability: "witness",         abilityCn: "亡灵低语", abilityEn: "WHISPER OF THE DEAD",    uiAccent: "#b98cff" },
  { id: "detective",  nameEn: "THE DETECTIVE",  nameCn: "侦探",   ability: "extra_questions", abilityCn: "延长审讯", abilityEn: "EXTENDED INTERROGATION", uiAccent: "#d9c07a" },
  { id: "physician",  nameEn: "THE PHYSICIAN",  nameCn: "医师",   ability: "evidence",        abilityCn: "冷光解剖", abilityEn: "COLD LIGHT AUTOPSY",     uiAccent: "#7fbfa0" },
  { id: "astrologer", nameEn: "THE ASTROLOGER", nameCn: "占星师", ability: "directions",      abilityCn: "三星定向", abilityEn: "THREE BEARINGS",         uiAccent: "#6fa8ff" },
  { id: "chronicler", nameEn: "THE CHRONICLER", nameCn: "记录者", ability: "recall",          abilityCn: "残章折角", abilityEn: "DOG-EARED PAGES",        uiAccent: "#e0a24f" },
];

export const identityById = (id) => IDENTITIES.find((i) => i.id === id) || IDENTITIES[0];

/* ------------------------------------------------------------------ helpers - */

/** Loose "did the player already establish this?" test, shared with the host. */
function bigrams(s) {
  const t = String(s).replace(/[^\u4e00-\u9fa5A-Za-z0-9]/g, "");
  const out = new Set();
  if (t.length === 1) out.add(t);
  for (let i = 0; i < t.length - 1; i++) out.add(t.slice(i, i + 2));
  return out;
}
function dice(a, b) {
  if (!a.size || !b.size) return 0;
  let n = 0;
  for (const x of a) if (b.has(x)) n++;
  return (2 * n) / (a.size + b.size);
}

/* --------------------------------------------------------------- abilities -- */

/**
 * @param {object} o
 * @param {string} o.identityId
 * @param {object} o.caseData
 * @param {object} o.args      ability-specific input from the player
 * @param {Array}  o.history   answered questions so far
 */
export async function useAbility({ identityId, caseData, args = {}, history = [], llm }) {
  const ident = identityById(identityId);

  switch (ident.ability) {
    /* ---- witness: one character speaks, bounded by what they knew -------- */
    case "witness": {
      const want = String(args.character || "").trim();
      const target = caseData.characters.find((c) => c.name === want)
        || caseData.characters.find((c) => want && (want.includes(c.name) || c.name.includes(want)));
      if (!target) {
        return { ok: false, error: `案件里没有叫「${want}」的角色`, options: caseData.characters.map((c) => c.name) };
      }
      const q = String(args.question || "").trim();
      if (!q) return { ok: false, error: "还需要一个要问他的问题" };

      // The whole point of this ability: the answer is limited to what that
      // character actually knew - it is a perspective, not the objective truth.
      const system = `你在扮演海龟汤案件里的一个角色。玩家通过"通灵"向你提问。

【铁律】
1. 你只能说出「你所知道的」范围内的事，用第一人称、口语、简短（不超过40字）
2. 你不知道的事情，就说你不知道。不要推测、不要脑补、不要编造
3. 你不知道标准汤底，你只知道你自己的经历和所见所闻
4. 不要提到"玩家""游戏""设定"这些词，就当作真的在对话

【你是谁】
${target.name}，${target.identity}
【你所知道的】
${target.knowledge}
【你不知道的】
${(target.unknown || []).join("；") || "（未列出，一律回答不知道）"}`;

      let reply = null;
      if (llm?.configured) {
        try {
          const { text } = await llm.complete({ system, user: q, maxTokens: 160, temperature: 0.5 });
          reply = text.trim().slice(0, 120);
        } catch (e) { /* fall through to the offline stub */ }
      }
      if (!reply) {
        // Offline stub. This must still respect the question: dumping the raw
        // knowledge field verbatim made "你为什么拔枪？" and "你叫什么名字？"
        // return the identical blob, which gives the game away for free and
        // makes the ability feel broken. So score the knowledge against the
        // question and answer only the part that is actually being asked about.
        const parts = String(target.knowledge || "")
          .split(/[。；;！!？?\n]+/).map((x) => x.trim()).filter(Boolean);
        const qg = bigrams(q);
        const scored = parts
          .map((p) => ({ p, s: dice(qg, bigrams(p)) }))
          .sort((a, b) => b.s - a.s);
        // what the character knew ABOUT is also a fair match target
        const tagScore = Math.max(0, ...(target.knowsAbout || []).map((t) => dice(qg, bigrams(t))));
        const strength = Math.max(tagScore, scored[0]?.s || 0);

        if (strength < 0.08) {
          reply = `（离线模式）${target.name}：这个我不知道。`;
        } else {
          const top = scored.filter((r) => r.s >= 0.08).slice(0, 2).map((r) => r.p);
          reply = `（离线模式）${target.name}：${(top.length ? top : parts.slice(0, 2)).join("。")}。`;
        }
      }
      return { ok: true, ability: ident.ability, title: `与 ${target.name} 的通话`, character: target.name, question: q, reply };
    }

    /* ---- extra_questions: buy more time in the room ---------------------- */
    // The most valuable kind of ability, because it changes the RESOURCE the
    // whole game is played with instead of handing over one fact. A player who
    // draws the detective plays a different, longer game.
    case "extra_questions": {
      const bonus = 10;
      return {
        ok: true, ability: ident.ability, title: "延长审讯",
        grantPoints: bonus,
        note: `你争取到了 ${bonus} 次额外的提问机会。`,
      };
    }

    /* ---- evidence: one physical fact from the case ----------------------- */
    case "evidence": {
      // An authored evidence[] is richer, but a case without one must not leave
      // the 医师 holding a dead ability for the whole game - which is exactly
      // what happened to 12 of the first 16 cases. Fall back to the case's
      // objects, which are already physical facts with a note attached.
      const authored = caseData.evidence || [];
      const list = authored.length
        ? authored
        : (caseData.objects || []).map((o, i) => ({
            id: "obj" + i,
            text: `${o.name}：${o.note || "与本案有关"}`,
            detail: "（本案未登记专门物证，这是现场留下的物件。）",
          }));
      if (!list.length) return { ok: false, error: "这个案件没有登记物证" };
      const asked = new Set(args.seen || []);
      const next = list.find((e) => !asked.has(e.id)) || list[list.length - 1];
      return { ok: true, ability: ident.ability, title: "冷光下的结论",
               evidence: { id: next.id, text: next.text, detail: next.detail || "" } };
    }

    /* ---- directions: three bearings, not three answers ------------------- */
    // A hint that names the TOPIC without giving the mechanism. Preferring the
    // heaviest components the player has not visibly engaged with means the
    // help lands where it is actually needed, not where they already are.
    case "directions": {
      const said = history.map((h) => h.question).join(" ");
      const engaged = (c) => (c.keywords || []).some((k) => said.includes(k));
      const ranked = caseData.requiredTruthComponents
        .slice()
        .sort((a, b) => (b.weight || 1) - (a.weight || 1));
      const fresh = ranked.filter((c) => !engaged(c));
      const pool = fresh.length >= 3 ? fresh : ranked;
      const dirs = pool.slice(0, 3).map((c, i) => ({
        id: c.id,
        label: ["方向一", "方向二", "方向三"][i],
        // Opening clause only - enough to aim at, not enough to answer.
        hint: c.text.length > 9 ? c.text.slice(0, 9) + "……" : c.text,
      }));
      return {
        ok: true, ability: ident.ability, title: "星盘上的三个方向",
        directions: dirs,
        note: "不要直接问这些句子，去想它们背后各自藏着什么。",
      };
    }

    /* ---- recall: mark the three questions that actually moved the case --- */
    // A long investigation runs 30-60 questions and players lose track of what
    // they learned. Rather than hand over new information, this gives back the
    // moments that mattered - which is its own kind of advantage.
    case "recall": {
      const rows = history.map((h) => ({
        n: h.n,
        question: h.question,
        verdict: h.verdict,
        unlocked: (h.unlocked || []).length,
      }));
      // Questions that opened a page are the ones worth re-reading; failing
      // that, the earliest, since they framed everything that came after.
      const ranked = rows.slice().sort((a, b) => (b.unlocked - a.unlocked) || (a.n - b.n));
      return {
        ok: true, ability: ident.ability, title: "残章上的三处折角",
        recalled: ranked.slice(0, 3),
        note: rows.length
          ? `你在 ${rows.length} 次提问里，这三处最值得重读。`
          : "还没有提问记录。",
      };
    }

    default:
      return { ok: false, error: "这个身份的能力还没实现" };
  }
}
