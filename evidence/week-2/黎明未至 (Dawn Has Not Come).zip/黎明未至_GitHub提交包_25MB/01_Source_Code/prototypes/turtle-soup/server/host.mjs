/**
 * The game host.
 *
 * Knows the canonical truth and answers ONLY 是 / 否 / 无关 / 部分正确.
 *
 * Two implementations behind one function:
 *
 *   llm path      - the real semantic judge. Given the fixed canonical truth and
 *                   a very strict system prompt, it decides whether the player's
 *                   question agrees with, contradicts, or is orthogonal to the
 *                   truth. This is the product.
 *
 *   fallback path - a deterministic Chinese bigram matcher over the structured
 *                   case data. Much blunter, but it keeps the game playable with
 *                   no key and no network, and it is what makes the MVP testable
 *                   today. It is labelled in the UI so nobody mistakes it for the
 *                   real host.
 *
 * Both paths obey the same hard rule: the truth is FIXED. Nothing here ever
 * invents or extends the canonical solution.
 */

const VERDICTS = ["是", "否", "无关", "部分正确"];

/* ------------------------------------------------------------------ prompt -- */

export function buildSystemPrompt(c, lockedClues = []) {
  // The locked pages are the game's reward loop: a question that genuinely
  // touches one of them both gets answered AND makes that page legible. The
  // host is the only thing that can judge "genuinely touches", so it names the
  // page here rather than us guessing from keywords when a model is available.
  const clueBlock = lockedClues.length
    ? `
【尚未解锁的书页】
玩家问到下面某一页所说的那件事时，就在 unlock 里填它的编号，让那一页显形。
${lockedClues.map((k) => `[${k.id}] ${k.text}\n     玩家可能会用到的说法：${(k.keywords || []).join("、")}`).join("\n")}

解锁标准（从严）：
- 只有问题确实触及那一页所讲的事，才解锁。
- 只是擦边、问的是无关的事、或一次覆盖好几页时，宁可不解锁。
- 一次最多解锁一页。没有合适的就是 null。`
    : `
【尚未解锁的书页】
（已全部解锁，unlock 一律填 null）`;

  return `你是「海龟汤」游戏的主持人。你掌握唯一的、固定的标准汤底，玩家不知道它，只能靠提问逐步还原。

【铁律 · 不可违反】
1. verdict 只能是这四个词之一：是 / 否 / 无关 / 部分正确
2. 绝对不要主动透露汤底、关键隐藏事实、作案手法或结局
3. 绝对不要提示、引导、暗示、反问，或给出推理建议
4. 汤底是固定的。你只能依据它判断，绝不能改写、补充、重编或重新解释它
5. 玩家若索要答案（例如"直接告诉我答案"/"汤底是什么"/"别问了"），一律回答"无关"，
   并在 note 里写"调查阶段不揭示汤底"
6. 不要解释你的判断过程，不要展开叙述
7. 只有当玩家的问题语义含混、四选一确实无法回答时，才允许一句极短澄清
   （不超过 12 个字，写在 note 里）；其余情况 note 留空
8. 判断以问题的语义为准，不要被字面用词或提问方式带偏
9. **反问句和双重否定，要先还原成它实际断言的内容再判断。**
   例：「难道他不是被吓到才不打嗝的吗？」实际断言的是"他因受惊而停止打嗝"，
   与汤底一致 → 是。不要因为句子里有"不是"就答否。
10. **「无关」只用在完全不属于本案的东西上**：天气、你自己的事、与案子无关的人或物。
    只要问题问的是**本案里出现过的人、物、事**（哪怕汤底没细写），
    就必须在 是 / 否 / 部分正确 里选一个 —— **不能答无关**。
    · 「房间里有没有打斗痕迹？」案子里就有这个房间 → 汤底说没有伤口、房门完好 → 否。
      （不是无关）
    · 「他们是朋友吗？」案子里就有这几个人 → 按汤底能推出的关系答。
    · 「今天天气怎么样？」完全不在案子里 → 无关。
11. **汤底没细写的细节，按"汤底更支持哪一种"来答；都不支持时答否。**
    不要因为"汤底没写"就答无关 —— 玩家问的是案子里的事，你答无关等于在说没听懂他的话，
    这比答错更让人恼火。
    例：「他有心脏病吗？」案子没提心脏病，但案子的解释是身高 → 答否。
12. 口语、错别字、句子不完整、指代不清，都不是答无关的理由 —— 见第 9 条。

【判定标准】
- 问题所述与汤底一致 → 是
- 与汤底矛盾 → 否
- 与真相无关（既不影响机制，也不构成线索） → 无关
- 问题里对了一半、错了一半，或只触及部分真相 → 部分正确

【提问方式不影响判定 · 五种常见问法】

A. 极短的问句（「水？」「牌？」「短了？」「他死了？」）
   玩家在**确认某个元素是否与本案有关**，不是在说废话。
   按那个元素本身判断 —— 它属于汤底就答是，与汤底矛盾就答否，确实无关才答无关。
   不要因为句子不完整、没有谓语，就一律答无关。

B. 一句话里好几个断言（用「然后」「而且」「但是」串起来的）
   全部断言都与汤底一致 → **是**。不要因为句子长、断言多就判部分正确 ——
   玩家已经全推对了，还告诉他"部分正确"会让人以为哪里错了。
   有对有错 → 部分正确。全部与汤底矛盾 → 否。

C. 反问句、双重否定、诱导式说法
   先还原成它**实际断言的内容**再判断。
   「难道他不是被吓到才不打嗝的吗？」断言的是"他因受惊而停止打嗝" → 是。
   「难道酒保不是想害他吗？」断言的是"酒保想害他"，与汤底矛盾 → 否。

D. 口语、错别字、语气词、省略主语
   按意思判断。玩家打错字、说得随便，不代表问题无效，不要因此答无关。

E. 玩家把整个汤底猜出来了，问「答案是不是……？」
   这是在**提出自己的解答**，不是索要答案 —— 海龟汤的玩法就是要确认推理。
   猜对了 → 是；猜错了 → 否；对一半 → 部分正确。
   只有**要求你直接把答案说出来**（「告诉我答案」「别问了直接说」「汤底是什么」）
   才答无关。

【输出】
只输出 JSON，不要任何多余文字：
{"verdict":"是|否|无关|部分正确","note":"","unlock":null}
${clueBlock}

【本局标准汤底 · 唯一事实来源】
${c.truth}

【关键隐藏事实（玩家需要自己问出来）】
${c.keyHiddenFacts.map((f) => `- ${f.fact}`).join("\n")}

【与真相无关的信息】
${c.irrelevantFacts.map((f) => `- ${f}`).join("\n")}

【常见错误猜想（这些都是错的，问到时应回答"否"）】
${(c.redHerrings || []).map((r) => `- ${r.trap}：${r.why}`).join("\n")}

【人物】
${c.characters.map((ch) => `- ${ch.name}（${ch.identity}）：${ch.knowledge}`).join("\n")}`;
}

/* ------------------------------------------------------------------- LLM ---- */

export async function answerWithLlm({ caseData, question, history, llm, lockedClues = [] }) {
  const recent = history.slice(-8).map((h) => `Q: ${h.question}\nA: ${h.verdict}`).join("\n");
  const user = `${recent ? `【最近的问答记录】\n${recent}\n\n` : ""}【玩家本次提问】\n${question}`;

  const { text } = await llm.complete({
    system: buildSystemPrompt(caseData, lockedClues),
    user,
    maxTokens: 160,
    temperature: 0.1,
    json: true,
  });

  let parsed = null;
  try {
    parsed = JSON.parse(text);
  } catch {
    // tolerate a model that wraps the JSON in prose
    const m = text.match(/\{[\s\S]*\}/);
    if (m) { try { parsed = JSON.parse(m[0]); } catch { /* fall through */ } }
  }
  if (!parsed || !VERDICTS.includes(parsed.verdict)) {
    throw new Error(`host returned an unusable verdict: ${String(text).slice(0, 120)}`);
  }
  // Never trust the model to invent a page id - it must be one we offered.
  const offerable = new Set(lockedClues.map((k) => k.id));
  return {
    verdict: parsed.verdict,
    note: typeof parsed.note === "string" ? parsed.note.trim().slice(0, 24) : "",
    unlock: offerable.has(parsed.unlock) ? parsed.unlock : null,
    engine: "llm",
  };
}

/* ---------------------------------------------------------------- clues ----- */

/**
 * Which locked page, if any, does this question unlock?
 *
 * Offline this is a keyword test, because that is all we have. It is
 * deliberately strict - unlocking a page is the game's main reward, and a
 * reveal that fires on a vague question is worth nothing. The LLM path judges
 * this semantically instead; this is the floor, not the target.
 */
export function matchClues({ caseData, question, locked }) {
  const q = String(question || "");
  if (!q) return [];
  const pool = locked || caseData.clues || [];
  const hits = [];
  for (const k of pool) {
    const kw = (k.keywords || []).filter((w) => w && q.includes(w));
    if (!kw.length) continue;
    // Longer matched phrases are stronger evidence than a stray two-character
    // word, so prefer the page whose keywords the question actually leans on.
    const weight = kw.reduce((s, w) => s + w.length, 0) + kw.length;
    hits.push({ id: k.id, weight });
  }
  hits.sort((a, b) => b.weight - a.weight);
  // At most two: a broad question can legitimately touch a pair of adjacent
  // facts, but a question that "unlocks five pages" is not a reward, it is a
  // giveaway.
  return hits.slice(0, 2).map((h) => h.id);
}

/* -------------------------------------------------------------- fallback ---- */

/** Character bigrams - a cheap stand-in for Chinese word segmentation. */
function bigrams(s) {
  const t = String(s).replace(/[^\u4e00-\u9fa5A-Za-z0-9]/g, "");
  const out = new Set();
  if (t.length === 1) out.add(t);
  for (let i = 0; i < t.length - 1; i++) out.add(t.slice(i, i + 2));
  return out;
}
function dice(a, b) {
  if (!a.size || !b.size) return 0;
  let inter = 0;
  for (const x of a) if (b.has(x)) inter++;
  return (2 * inter) / (a.size + b.size);
}

const REFUSAL = [
  /直接(告诉我|说)?(答案|汤底)/, /答案是什么/, /汤底是什么/, /别问了.*告诉我/,
  /告诉我真相/, /公布答案/, /直接揭晓/,
];

/**
 * Interrogative forms that LOOK like negations but are not.
 *
 * "男人是不是在打嗝？" is an ordinary yes/no question. The 不是 sitting inside
 * 是不是 is a question particle, not a negation - reading it as one flipped
 * every such question to 否. Same for 有没有 ("枪里有没有子弹？").
 *
 * These are stripped before polarity analysis so that the particles cannot be
 * mistaken for the speaker denying something.
 */
const INTERROGATIVE_G = /(是不是|是否|有没有|有没|能否|可否|难道)/g;

const NEG = /(不是|没有|不会|并非|不属于|不存在|未曾|不曾|不可能|不再|不|没)/;

/**
 * Is there a negation immediately in front of `term` inside `text`?
 *
 * This is the heart of the fix. A naive overlap matcher gets the subtle cases
 * exactly backwards: the fact reads "酒保拔枪不是威胁，而是故意吓他" and the
 * question asks "拔枪是为了威胁他吗". The right fact matches strongly, yet the
 * correct verdict is 否, because the fact negates the very term being asked
 * about. Comparing polarity per shared term catches that, where comparing the
 * whole sentence at once does not (the same sentence also contains the
 * un-negated "吓他", which is what the good question asks about).
 */
/**
 * 这是不是一个**是非问句**（"X 吗？""是不是 X？"）。
 *
 * 用来区分「男人死了」（陈述，可以直接判否）和「男人还活着吗？」（疑问，
 * 判否等于替他断言）。中文没有词形变化，只能看句末语气词和几个固定句式。
 */
const POLAR_Q = /(吗|麼|么|吧)\s*[？?]?\s*$|是不是|是否|有没有|会不会|能不能|算不算|属于不属于/;
function isPolarQuestion(text) {
  return POLAR_Q.test(String(text || "").trim());
}

function negBefore(text, term) {
  const i = text.indexOf(term);
  if (i < 0) return false;
  return NEG.test(text.slice(Math.max(0, i - 4), i));
}

export function answerWithFallback({ caseData, question }) {
  const q = String(question || "").trim();
  if (!q) return { verdict: "无关", note: "", engine: "fallback" };
  if (REFUSAL.some((r) => r.test(q))) {
    return { verdict: "无关", note: "调查阶段不揭示汤底", engine: "fallback" };
  }

  /**
   * 不是是非题的问题。
   *
   * 「男人的职业是什么？」「酒吧装修是什么风格？」这类问题**既不能肯定也不能否定**，
   * 硬判是或否都是错的 —— 它们本来就不是 yes/no。主持人只回答四个词，那么对这种
   * 问题唯一诚实的回答就是"无关"。
   *
   * 这一条必须排在最前面：让它先走，后面的模糊匹配才不会去硬凑一个答案。
   */
  if (/(什么|为什么|怎么|怎样|如何|谁|哪|多少|几时|多久)/.test(q)) {
    return { verdict: "无关", note: "", engine: "fallback" };
  }

  // Analysis runs on the question with its interrogative particles removed, so
  // that the 不是 inside 是不是 can never masquerade as a negation.
  const qn = q.replace(INTERROGATIVE_G, "") || q;
  const qg = bigrams(q);

  const claims = [];
  for (const f of caseData.keyHiddenFacts) {
    claims.push({ kind: "true", text: f.fact, weight: f.weight || 1, kg: bigrams(f.fact) });
  }
  for (const r of caseData.redHerrings || []) {
    claims.push({ kind: "false", text: r.trap, weight: 1.6, kg: bigrams(r.trap) });
  }
  for (const t of caseData.irrelevantFacts) {
    claims.push({ kind: "irrelevant", text: t, weight: 1, kg: bigrams(t) });
  }

  const scored = claims
    .map((c) => ({ ...c, s: dice(qg, c.kg) * c.weight }))
    .sort((a, b) => b.s - a.s);
  const best = scored[0];

  /**
   * 覆盖率 —— 这个问题有多少内容是本局"知道"的？
   *
   * 这是整个离线判定里最关键的一道闸，补的是一个大洞：
   *
   *   「男人死了」和真事实「男人被吓到，打嗝当场就停了」共有的 bigram 只有"男人"
   *   两个字，fuzzy 分数却是全场最高（0.43），于是被判成"是"。可这个问题断言的
   *   全部内容就是"死了"，而真相里男人活得好好的。
   *   「酒保杀人」同理 —— 只共用"酒保"，"杀人"完全没人管。
   *
   * 根因是它只看"重合了多少"，不看"问题里有多少是没人认领的"。一个只对上了主语、
   * 谓语在案子里根本不存在的问题，不是"一致"，是**案子里没有这回事**。
   *
   * 所以：先量问题里有多少内容词在全案词汇之外；
   *   超出得多 + 主语认得 → 谈的是本案的人，却断言了不存在的事 → 否
   *   超出得多 + 主语也不认得 → 压根在问别的 → 无关
   */
  const allText = claims.map((c) => c.text).join("") + String(caseData.truth || "");
  /**
   * ── 跨词垃圾 bigram 不能算数 ────────────────────────────────────────
   *
   * 中文 bigram 会跨词边界拼出没有意义的组合。「酒保想杀他」切出来是
   * 酒保 / 保想 / 想杀 / 杀他 —— 其中「保想」是"酒保"的尾巴接上"想"的头，
   * 案文里当然存在（凡是有"酒保想…"的句子都有）。
   *
   * 它让 known 从 1 变成 2，于是 `known.length < 2` 那道闸失效，
   * 「酒保是不是想杀他？」就被判成"是" —— 而酒保根本不想杀他。
   *
   * 所以：**紧跟在另一个已知 bigram 后面的，算它的延续，不单独计数。**
   * 上面那句于是只剩 known=1，闸门恢复。
   */
  const ordered = [...bigrams(qn)].filter((t) => t.length === 2);   // bigrams() 返回 Set，要先摊开
  const known = [];
  const unknown = [];
  for (let i = 0; i < ordered.length; i++) {
    const isKnown = allText.includes(ordered[i]);
    const contOfKnown = i > 0 && allText.includes(ordered[i - 1]);
    if (isKnown && !contOfKnown) known.push(ordered[i]);
    else if (!isKnown) unknown.push(ordered[i]);
  }

  // an explicit required-component keyword hit is strong evidence
  let compHit = null;
  for (const comp of caseData.requiredTruthComponents) {
    const kw = (comp.keywords || []).filter((k) => q.includes(k));
    if (kw.length) {
      const s = 0.35 + 0.15 * kw.length;
      if (!compHit || s > compHit.score) compHit = { text: comp.text, score: s };
    }
  }

  if (best.s < 0.16 && (!compHit || compHit.score < 0.35)) {
    return { verdict: "无关", note: "", engine: "fallback" };
  }

  // If the question is really about an off-topic detail, say so - this used to
  // fall through to 部分正确 whenever two claims scored similarly.
  if (best.kind === "irrelevant") {
    return { verdict: "无关", note: "", engine: "fallback" };
  }

  /**
   * 只对上了主语、其余内容在本案词汇之外 —— 这不是"一致"，是"案子里没这回事"。
   *
   * 「男人死了」：三个 bigram 里只有"男人"认得，"人死""死了"全在案外。
   * 「酒保杀人」同理。它们在模糊匹配里都能拿到最高分（因为"男人""酒保"是全案
   * 出现最多的词），于是被判成"是" —— 而真相里男人活得好好的。
   *
   * 判据不能用比例。实测：
   *   「男人死了」                       认得 1/3 = 0.33  → 应为 否
   *   「酒保拔枪是不是为了吓他，好让他停止打嗝？」 认得 5/14 = 0.36  → 应为 是
   * 比例几乎一样，分不开。真正分开它们的是**认得的绝对数量**：合法的长问题认得
   * 五个核心词（酒保/拔枪/吓他/打嗝/让他），而"男人死了"只认得一个主语。
   *
   * 所以判据是「认得少于 2 个，且案外词有 2 个以上」。放在无关判定**之后**，
   * 这样"问的是姓名职业装修"那类仍然走 无关，不会被这里截走。
   */
  if (known.length < 2 && unknown.length >= 2) {
    /**
     * ── 疑问句不能答「否」 ──────────────────────────────────────────────
     *
     * 这道闸对**陈述句**是对的：
     *   「男人死了」（陈述）→ 否   ✅ 他确实没死
     *
     * 但对**疑问句**它会造成一个更糟的错误：
     *   「男人还活着吗？」→ 否   ❌ 答"否"等于断言他死了
     *
     * 同一道闸，陈述句上是对的，疑问句上会**主动说一个假事实**。
     * 而疑问句恰恰是海龟汤里最常见的问法（实测「酒保是不是想杀他？」
     * 「男人还活着吗？」两个都栽在这里）。
     *
     * 所以分开：疑问句在本案词汇里找不到谓语时，只能说"无关" ——
     * 无关是"这条线我答不了"，否是"事情是反的"。前者不误导，后者会。
     */
    if (isPolarQuestion(qn)) {
      return { verdict: "无关", note: "", engine: "fallback" };
    }
    return { verdict: "否", note: "", engine: "fallback" };
  }

  // Compare the question against the matched claim term by term. A term whose
  // negation is flipped between the two means the question and the claim
  // disagree about that specific thing.
  const qTerms = [...new Set(bigrams(qn))].filter((t) => t.length === 2 && best.text.includes(t));
  let agree = 0, disagree = 0;
  for (const t of qTerms) {
    if (negBefore(qn, t) === negBefore(best.text, t)) agree++; else disagree++;
  }

  // `asserts` = the question affirms what the matched claim says.
  // A true fact affirmed is 是; a red herring affirmed is 否, and a red herring
  // correctly denied is 是 - the same comparison, read from either end.
  const asserts = disagree === 0;
  let verdict;
  if (!qTerms.length) {
    // 没有任何可比较的词 —— 这一条以前默认判"是"（只要最佳命中是真事实），
    // 那等于"看不懂就同意"。看不懂就该说无关。
    verdict = compHit ? "是" : "无关";
  } else {
    verdict = best.kind === "true" ? (asserts ? "是" : "否") : (asserts ? "否" : "是");
  }

  // genuinely mixed: a truth claim AND a false claim both land, and the
  // question is not already a clean denial of the top claim
  const second = scored[1];
  if (disagree === 0 && best.kind === "true" && second && second.kind === "false" &&
      best.s > 0.2 && second.s > 0.2 && Math.abs(best.s - second.s) < 0.12) {
    verdict = "部分正确";
  }

  return { verdict, note: "", engine: "fallback" };
}

/* ------------------------------------------------------------------ entry --- */

export async function answerQuestion({ caseData, question, history = [], llm, lockedClues = [] }) {
  let out;
  if (llm?.configured) {
    try {
      out = await answerWithLlm({ caseData, question, history, llm, lockedClues });
    } catch (err) {
      // Never let a model hiccup kill the session: degrade and say so.
      console.warn("[host] LLM failed, using fallback:", err.message);
      out = { ...answerWithFallback({ caseData, question }), degraded: true, error: err.message };
    }
  } else {
    out = answerWithFallback({ caseData, question });
  }

  // A real model judges the unlock semantically and its "no" is worth keeping,
  // so only the offline path falls back to keyword matching.
  if (out.engine !== "llm") {
    out.unlock = matchClues({ caseData, question, locked: lockedClues })[0] || null;
  }
  return out;
}
