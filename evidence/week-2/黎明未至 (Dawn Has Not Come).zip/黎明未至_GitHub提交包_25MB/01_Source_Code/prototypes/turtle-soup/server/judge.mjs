/**
 * The judge: scores the player's final reconstruction against the canonical
 * truth and picks the ending.
 *
 * Same two-path structure as the host. The score is built from weighted truth
 * components, so the numbers are explainable rather than a single opaque model
 * opinion - the model decides WHICH components were hit, our own weighting then
 * computes the score. That keeps the ending thresholds stable even if the model
 * is swapped.
 */

/** true if every heavy component landed and little was missed */
export const THRESHOLDS = { true: 85, good: 55 };

export function endingFor(score, hits, comps) {
  const heavy = comps.filter((c) => (c.weight || 1) >= 3);
  const heavyHit = heavy.filter((c) => hits.has(c.id)).length;
  const allHeavy = heavy.length > 0 && heavyHit === heavy.length;
  if (score >= THRESHOLDS.true && allHeavy) return "true";
  if (score >= THRESHOLDS.good) return "good";
  return "bad";
}

export function scoreFromHits(hits, comps, wrongClaims = []) {
  const total = comps.reduce((s, c) => s + (c.weight || 1), 0) || 1;
  const got = comps.reduce((s, c) => s + (hits.has(c.id) ? (c.weight || 1) : 0), 0);
  let score = Math.round((got / total) * 100);
  // falling for a planted trap costs you, but cannot push below zero
  score = Math.max(0, score - Math.min(20, wrongClaims.length * 6));
  // 踩中三条以上错误猜想 = 方向整个错了。词面命中再多也不能算还原成功 ——
  // 错误猜想的用词本来就大量重叠真相，不封顶的话"越会瞎猜分越高"。
  if (wrongClaims.length >= 3) score = Math.min(score, 28);
  return score;
}

/* ------------------------------------------------------------------- LLM ---- */

const JUDGE_SYSTEM = `你是海龟汤游戏的裁判。玩家提交了他对真相的还原，你要对照标准汤底，判断他命中了哪些「必需真相组件」。

【判定原则】
- 语义等价即算命中，不要求用词一致。玩家用自己的话把机制说对了就算命中。
- 部分说对、方向对但不完整，不算命中该条。
- 只依据标准汤底判断，不要因为玩家写得长或写得漂亮就放宽。

【两条硬规则 —— 先判这两条，再逐条看组件】

A. **如果玩家的还原与标准汤底实质一致**（用词可以完全不同、顺序可以不同、详略可以不同），
   那就是全部命中，hits 里要包含每一个组件，wrongClaims 留空。
   玩家明明把汤底说对了却拿不到满分，是这局游戏最伤的体验。

B. **如果玩家的还原与标准汤底相矛盾**（说的事根本不是案子里发生的），
   与矛盾点相关的组件**一律不算命中**，并在 wrongClaims 里列出他说错的关键点。
   特别注意：玩家如果说出的正是**本案的错误猜想** —— 把真相归因于案子里不存在的
   人、动机、手法或结局 —— 那是完全没命中，不是"部分命中"。
   **一份由错误猜想拼成的答案，一个组件都不能给。**

【输出】只输出 JSON，不要多余文字：
{"hits":["组件id"],"wrongClaims":["玩家说错的关键点，最多3条"],"comment":"一句话点评，不超过40字"}`;

export async function judgeWithLlm({ caseData, answer, llm }) {
  const comps = [
    ...caseData.requiredTruthComponents.map((c) => `[${c.id}] ${c.text}（权重${c.weight}）`),
    ...(caseData.optionalComponents || []).map((c) => `[${c.id}] ${c.text}（可选，权重${c.weight}）`),
  ].join("\n");

  const user = `【标准汤底】\n${caseData.truth}\n\n【必需真相组件】\n${comps}\n\n【玩家提交的还原】\n${answer}`;

  const { text } = await llm.complete({
    system: JUDGE_SYSTEM, user, maxTokens: 400, temperature: 0.1, json: true,
  });

  let parsed = null;
  try { parsed = JSON.parse(text); } catch {
    const m = text.match(/\{[\s\S]*\}/);
    if (m) { try { parsed = JSON.parse(m[0]); } catch { /* fall through */ } }
  }
  if (!parsed || !Array.isArray(parsed.hits)) {
    throw new Error("judge returned unusable JSON: " + String(text).slice(0, 120));
  }
  return {
    hits: parsed.hits.filter((id) => typeof id === "string"),
    wrongClaims: (parsed.wrongClaims || []).filter((s) => typeof s === "string").slice(0, 3),
    comment: String(parsed.comment || "").slice(0, 60),
    engine: "llm",
  };
}

/* -------------------------------------------------------------- fallback ---- */

/** 汉字 bigram。离线判官没有语义能力，只能靠字面重合度近似。 */
function bigrams(s) {
  const t = String(s).replace(/[^\u4e00-\u9fa5A-Za-z0-9]/g, "");
  const out = new Set();
  if (t.length === 1) out.add(t);
  for (let i = 0; i < t.length - 1; i++) out.add(t.slice(i, i + 2));
  return out;
}
function dice(a, b) {
  if (!a.size || !b.size) return 0;
  let inter = 0;
  for (const x of a) if (b.has(x)) inter++;
  return (2 * inter) / (a.size + b.size);
}

export function judgeWithFallback({ caseData, answer }) {
  const text = String(answer || "");
  const hits = [];
  const comps = [...caseData.requiredTruthComponents, ...(caseData.optionalComponents || [])];
  for (const c of comps) {
    if ((c.keywords || []).some((k) => text.includes(k))) hits.push(c.id);
  }

  /**
   * 踩中预埋的错误猜想要扣分。
   *
   * 这里原来是**永远返回空数组** —— 于是离线模式下，一份由错误猜想拼成的答案
   * 能拿到满分和"完全正确"结局（实测 021/025/032/044 四条都这样）。
   * 那等于整个评分失去意义：玩家越会瞎猜，分越高。
   *
   * 离线没有语义能力，但字面重合度够用：玩家的还原如果和某条预埋猜想大面积
   * 撞词，基本就是踩进去了。
   */
  const bg = bigrams(text);
  const wrongClaims = [];
  for (const r of caseData.redHerrings || []) {
    if (dice(bg, bigrams(r.trap)) > 0.26) wrongClaims.push(r.trap);
  }

  return { hits, wrongClaims, comment: "", engine: "fallback" };
}

/* ------------------------------------------------------------------ entry --- */

export async function judgeAnswer({ caseData, answer, llm }) {
  const comps = [...caseData.requiredTruthComponents, ...(caseData.optionalComponents || [])];
  let raw;
  if (llm?.configured) {
    try {
      raw = await judgeWithLlm({ caseData, answer, llm });
    } catch (err) {
      console.warn("[judge] LLM failed, using fallback:", err.message);
      raw = { ...judgeWithFallback({ caseData, answer }), degraded: true, error: err.message };
    }
  } else {
    raw = judgeWithFallback({ caseData, answer });
  }

  const validIds = new Set(comps.map((c) => c.id));
  const hitSet = new Set(raw.hits.filter((id) => validIds.has(id)));

  // Score on REQUIRED components only. Optional ones are colour, not
  // requirements. Counting them in the denominator meant a fully correct
  // reconstruction capped below 100 whenever it did not happen to name some
  // detail the case had marked optional - so a perfect answer could miss
  // TRUE END. Optional hits are still reported below for the ending screen.
  const score = scoreFromHits(hitSet, caseData.requiredTruthComponents, raw.wrongClaims);

  const detail = comps.map((c) => ({
    id: c.id,
    text: c.text,
    weight: c.weight || 1,
    required: caseData.requiredTruthComponents.includes(c),
    hit: hitSet.has(c.id),
  }));

  return {
    score,
    ending: endingFor(score, hitSet, caseData.requiredTruthComponents),
    hits: detail.filter((d) => d.hit),
    missing: detail.filter((d) => !d.hit && d.required),
    wrongClaims: raw.wrongClaims,
    comment: raw.comment,
    engine: raw.engine,
    degraded: !!raw.degraded,
  };
}
