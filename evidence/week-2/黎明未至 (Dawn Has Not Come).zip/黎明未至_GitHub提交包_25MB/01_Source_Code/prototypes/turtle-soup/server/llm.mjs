/**
 * LLM provider adapter.
 *
 * Server-side only. The API key never reaches the browser: the client talks to
 * our own /api/* routes and this module is what actually calls the model.
 *
 * Works against any OpenAI-compatible /chat/completions endpoint. Configure via
 * environment variables so the key is not written into a tracked file:
 *
 *   TSG_LLM_API_KEY    required to enable the LLM path
 *   TSG_LLM_BASE_URL   default https://api.openai.com/v1
 *   TSG_LLM_MODEL      default gpt-4o-mini
 *   TSG_LLM_TIMEOUT    ms, default 30000
 *
 * When no key is present `configured` is false and callers fall back to the
 * deterministic engine - the game stays playable offline, just with a much
 * blunter host.
 */

const DEFAULTS = {
  baseUrl: "https://api.openai.com/v1",
  model: "gpt-4o-mini",
  timeout: 30000,
};

export function createLlm(env = process.env) {
  const apiKey = env.TSG_LLM_API_KEY || "";
  const baseUrl = (env.TSG_LLM_BASE_URL || DEFAULTS.baseUrl).replace(/\/+$/, "");
  const model = env.TSG_LLM_MODEL || DEFAULTS.model;
  const timeout = Number(env.TSG_LLM_TIMEOUT || DEFAULTS.timeout);

  return {
    configured: apiKey.length > 0,
    model,
    baseUrl,
    /** Never expose this to a client. */
    get provider() {
      return apiKey ? `${new URL(baseUrl).host} · ${model}` : "offline";
    },

    /**
     * One completion. Returns { text } or throws. Callers must handle failure -
     * a flaky model should degrade to the fallback, not break the game.
     */
    async complete({ system, user, maxTokens = 300, temperature = 0.2, json = false }) {
      if (!apiKey) throw new Error("LLM not configured");

      const body = {
        model,
        temperature,
        max_tokens: maxTokens,
        messages: [
          { role: "system", content: system },
          { role: "user", content: user },
        ],
      };
      if (json) body.response_format = { type: "json_object" };

      const ctl = new AbortController();
      const timer = setTimeout(() => ctl.abort(), timeout);
      try {
        const res = await fetch(`${baseUrl}/chat/completions`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${apiKey}`,
          },
          body: JSON.stringify(body),
          signal: ctl.signal,
        });
        if (!res.ok) {
          const detail = await res.text().catch(() => "");
          throw new Error(`LLM ${res.status}: ${detail.slice(0, 200)}`);
        }
        const data = await res.json();
        const text = data?.choices?.[0]?.message?.content;
        if (typeof text !== "string") throw new Error("LLM returned no content");
        return { text, usage: data.usage || null };
      } finally {
        clearTimeout(timer);
      }
    },
  };
}
