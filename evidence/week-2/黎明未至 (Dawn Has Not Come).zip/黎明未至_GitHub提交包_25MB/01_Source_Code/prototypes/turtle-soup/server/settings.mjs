/**
 * 本地设置。
 *
 * ── 为什么要有这个 ──────────────────────────────────────────────────────
 * 原来 key 只能靠环境变量传。对开发者没问题，但**把这个游戏发给朋友玩，
 * 让他去「Win 键搜环境变量 → 用户变量 → 新建三条」是不合理的** ——
 * 那不是玩游戏的人该做的事。
 *
 * 所以在软件里放一个输入口，填完直接生效，不用重启。
 *
 * ── 存在哪 ──────────────────────────────────────────────────────────────
 * `%APPDATA%\黎明未至\config.json`。
 *
 * **不存在游戏目录里**：便携版可能被解压到 Program Files 或者只读的 U 盘，
 * 那里写不进去。APPDATA 一定可写，而且换一个版本的包，设置还在。
 *
 * ── 安全 ────────────────────────────────────────────────────────────────
 * 明文存在本机。这是本地软件的常规做法（和浏览器存的密码、编辑器存的 token
 * 一个级别），但要说清楚：**能读这个文件的人就能拿到 key**。
 * 所以接口只回"有没有 key"，绝不把 key 本身回给浏览器。
 */
import { readFileSync, writeFileSync, mkdirSync, existsSync } from "node:fs";
import path from "node:path";
import os from "node:os";

const DIR = path.join(
  process.env.APPDATA || path.join(os.homedir(), ".config"),
  "黎明未至",
);
const FILE = path.join(DIR, "config.json");

const EMPTY = { apiKey: "", baseUrl: "", model: "" };

/** 读设置。文件不存在、坏了、或者字段类型不对，一律当空 —— 绝不让它把启动搞崩。 */
export function readSettings() {
  try {
    if (!existsSync(FILE)) return { ...EMPTY };
    const raw = JSON.parse(readFileSync(FILE, "utf8"));
    const str = (v) => (typeof v === "string" ? v.trim() : "");
    return {
      apiKey: str(raw.apiKey),
      baseUrl: str(raw.baseUrl),
      model: str(raw.model),
    };
  } catch {
    return { ...EMPTY };
  }
}

/** 写设置。返回 true/false，失败不抛 —— 调用方只需要知道成没成。 */
export function writeSettings(patch) {
  try {
    mkdirSync(DIR, { recursive: true });
    const next = { ...readSettings(), ...patch };
    writeFileSync(FILE, JSON.stringify(next, null, 2), "utf8");
    return true;
  } catch {
    return false;
  }
}

/**
 * 环境变量优先于文件。
 *
 * 这样开发时（key 在 env 里）行为完全不变；而玩家填在界面里的值也存在同一个
 * 对象里，下游 createLlm 一个入口读，不用改它。
 *
 * **默认值必须是 DeepSeek，不能是 OpenAI。** 界面只让玩家填一个 key（这是
 * 最省事的填法），如果此时 baseUrl 落到 createLlm 自己的默认值
 * `https://api.openai.com/v1`，那在国内就是连不上 —— 玩家会觉得"填了没用"。
 * 实测过：只填 key 时的报错就是 `fetch failed`。
 */
const DEFAULT_BASE = "https://api.deepseek.com/v1";
const DEFAULT_MODEL = "deepseek-chat";

export function effectiveEnv(base = process.env) {
  const s = readSettings();
  return {
    ...base,
    TSG_LLM_API_KEY: base.TSG_LLM_API_KEY || s.apiKey || "",
    TSG_LLM_BASE_URL: base.TSG_LLM_BASE_URL || s.baseUrl || DEFAULT_BASE,
    TSG_LLM_MODEL: base.TSG_LLM_MODEL || s.model || DEFAULT_MODEL,
  };
}

/** 给界面看的：**不回 key 本身**，只说有没有、以及后两项目前是什么。 */
export function settingsForClient(fromEnv = process.env) {
  const s = readSettings();
  const key = fromEnv.TSG_LLM_API_KEY || s.apiKey || "";
  return {
    hasKey: key.length > 0,
    // 只露头尾，方便玩家确认"填进去的是不是我以为的那个"
    keyHint: key.length > 10 ? `${key.slice(0, 6)}…${key.slice(-4)}` : (key ? "已设置" : ""),
    baseUrl: fromEnv.TSG_LLM_BASE_URL || s.baseUrl || "https://api.deepseek.com/v1",
    model: fromEnv.TSG_LLM_MODEL || s.model || "deepseek-chat",
    // 环境变量是"上方锁定"的，界面要如实告诉玩家：改了也没用
    fromEnv: !!(fromEnv.TSG_LLM_API_KEY && !s.apiKey),
    path: FILE,
  };
}
