# Identity-card assets

This folder contains the lightweight review assets for all five identity cards:

- `card.glb`: 3D card model
- `lineart.png`: line-art layer
- `text.png`: text layer

The high-resolution `background.png` and `subject.png` layers are excluded from this under-25-MB submission package. They remain in the complete portable build.
