# 黎明未至 Week 2 GitHub 提交包

本文件夹已按 GitHub 网页单文件 25 MB 限制整理，可直接压缩后上传。

## 提交内容

- `01_Source_Code`：核心源代码、44 个案件、服务端主持与判定逻辑、抽卡界面、启动脚本，以及 5 张身份卡的轻量模型和图层。
- `02_3D_Card_Assets`：5 张身份卡的 `card.glb`、线稿和文字图层，便于导师单独检查视觉资产。
- `03_Week2_Documents`：填写后的 Week 2 Student Weekly Progress Entry、Evidence Register 和 AI Use Record。

## 为控制体积而排除的内容

- `node.exe`（约 87 MB）
- `prototypes/fate-draw/node_modules`
- 5 张 `background.png` 和 5 张 `subject.png` 高分辨率分层图（合计约 65.6 MB）
- `card-back.old.png`
- 完整免安装 ZIP

这些文件体积较大，不适合普通 GitHub 网页上传。完整可运行的免安装版本应保留在本地，或作为 GitHub Release 附件单独提交。

## 提交前需要人工补充

打开 `03_Week2_Documents/Thursday Afternoon_Group 1_Week 2.xlsx`，补充 Route、出席成员、缺席成员和 Evidence-hub link，并在团队核验后勾选声明。

